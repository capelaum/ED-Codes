/***************************/
/* Exemplo de uso de fwide */
/***************************/

#include <stdio.h>
#include <wchar.h>

void Orientacao(const char *intro, FILE *stream)
{
   int orientacao;

   orientacao = fwide(stream, 0);

   if (orientacao < 0)
      printf( "\n%s\n\tO stream e' orientado por byte.\n",
              intro );
   else if (orientacao > 0)
      printf( "%s\n\tO stream e' orientado por largura.\n",
              intro );
   else
      printf( "%s\n\tO stream nao tem orientacao.\n",
              intro );
}

int main(void)
{
   FILE *stream;

   stream = fopen("Arq.dat","w");

   Orientacao("Apos a abertura do arquivo:", stream);

      /* Torna o stream orientado por byte */
   fwide(stream, -1);
   Orientacao("Apos chamada fwide(stream, -1):", stream);

      /* Tenta tornar o stream orientado por largura */
   fwide(stream,  1);
   Orientacao("Apos chamada fwide(stream,  1):", stream);

   fclose(stream);

   stream = fopen("Arq.dat","w");

   Orientacao("Apos reabertura do arquivo:", stream);

   fwprintf(stream, L"um string");

   Orientacao("Apos chamar fwprintf()", stream);

   fclose(stream);

   return 0;
}
