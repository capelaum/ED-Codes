/******************************/
/* Exemplo de uso de vswscanf */
/******************************/

#include <stdio.h>
#include <wchar.h>
#include <stdarg.h>

/****
 * Fun��o LeEmStream(): L� dados formatados no string
 *                      especificado usando vswscanf()
 ****/

int LeEmString(const wchar_t *s, const wchar_t *formato, ...)
{
   int     nValoresAtribuidos;
   va_list args;

   va_start(args, formato);

   nValoresAtribuidos = vswscanf(s, formato, args);

   va_end(args);

   return nValoresAtribuidos;
}

int main(void)
{
   int     umInt, nValoresLidos;
   float   umFloat;
   char    umChar;
   wchar_t entrada[] = L"12 3.1415 X algo mais";

   nValoresLidos = LeEmString( entrada, L"%d %f %c",
                               &umInt, &umFloat, &umChar );

   printf( "\nString onde foi feita a leitura: \n\t%ls",
           entrada );

   if (nValoresLidos == EOF) {
      printf("Ocorreu um erro de leitura");
      return 1;
   }

   printf( "\n\nNumero de valores lidos e atribuidos: %d",
           nValoresLidos );

   if (3 == nValoresLidos) {
      printf( "\n\nValores lidos:\n \t%d, %f e %c",
              umInt, umFloat, umChar );
   }

   return 0;
}
