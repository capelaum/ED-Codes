/******************************/
/* Exemplo de uso de vfwscanf */
/******************************/

#include <stdio.h>
#include <wchar.h>
#include <stdarg.h>

/****
 * Fun��o LeEmStream(): L� dados formatados no stream
 *                      especificado usando vfwscanf()
 ****/

int LeEmStream(FILE *stream, const wchar_t *formato, ...)
{
   int     nValoresAtribuidos;
   va_list args;

   va_start(args, formato);

   nValoresAtribuidos = vfwscanf(stream, formato, args);

   va_end(args);

   return nValoresAtribuidos;
}

int main(void)
{
   int   umInt, nValoresLidos;
   float umFloat;
   char  umChar;

   printf("Digite um inteiro, um real e um caractere:\n");

   nValoresLidos = LeEmStream( stdin, L"%d %f %c",
                               &umInt, &umFloat, &umChar );

   if (nValoresLidos != EOF)
      printf( "Numero de valores lidos e atribuidos: %d",
              nValoresLidos );
   else
      printf("Ocorreu um erro de leitura");

   return 0;
}
