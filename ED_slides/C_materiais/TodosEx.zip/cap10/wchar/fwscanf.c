/*****************************/
/* Exemplo de uso de fwscanf */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   int   umInt, nValoresLidos = 0;
   FILE  *arquivo;

   arquivo = fopen("Arq1.dat", "rt");

   if (!arquivo) {
      printf("Nao foi possivel abrir o arquivo");
      return 1;
   }

   nValoresLidos = fwscanf(arquivo, L"%d", &umInt);

   if (nValoresLidos != EOF)
      printf("O valor lido foi: %d", umInt);
   else
      printf("Nao foi lido nenhum valor");

   fclose(arquivo);

   return 0;
}


