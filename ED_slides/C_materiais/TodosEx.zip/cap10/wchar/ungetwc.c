/**************************************************/
/* Exemplo de uso de ungetwc, putwchar e getwchar */
/**************************************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   int  c;

   ungetwc(L'A', stdin);

   wprintf(L"Caractere inserido em stdin: ");
   putwchar(getwchar());

   return 0;
}
