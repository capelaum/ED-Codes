/*******************************/
/* Exemplo de uso de vswprintf */
/*******************************/

#include <stdio.h>
#include <wchar.h>
#include <stdarg.h>

#define MAX 80

/****
 * Fun��o EscreveEmArray(): escreve dados formatados no
 *                          array de caracteres extensos
 *                          especificado usando vswprintf()
 ****/

int EscreveEmArray(wchar_t ar[], const wchar_t *formato, ...)
{
   va_list argumentos;
   int     retorno;

   va_start(argumentos, formato);

   retorno = vswprintf(ar, MAX, formato, argumentos);

   va_end(argumentos);

   return retorno;
}

int main(void)
{
   wchar_t array[MAX];
   int     umInteiro = 33;
   float   umFloat = 44.5;
   wchar_t umString[MAX] = L"Isto e' um teste";

   EscreveEmArray( array, L"%d %f %ls",
                   umInteiro, umFloat, umString );

   printf("Conteudo do array: %ls\n", array);

   return 0;
}
