/*****************************/
/* Exemplo de uso de swscanf */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   int     umInt, nValoresLidos;
   float   umFloat;
   char    umChar;
   wchar_t entrada[] = L"12 3.1415 X algo mais";

   nValoresLidos = swscanf( entrada, L"%d %f %c",
                            &umInt, &umFloat, &umChar );

   printf( "\nString onde foi feita a leitura: \n\t%ls",
           entrada );
   printf( "\n\nNumero de valores lidos e atribuidos: %d",
           nValoresLidos );

   if (3 == nValoresLidos) {
      printf( "\n\nValores lidos:\n \t%d, %f e %c",
              umInt, umFloat, umChar );
   }

   return 0;
}
