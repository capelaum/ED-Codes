/**************************************/
/* Exemplo de uso de wprintf e wscanf */
/**************************************/

#include <stdio.h>
#include <wchar.h>

int main( void )
{
   int     umInt, resultado;
   float   umFloat;
   char    umChar, str[80];
   wchar_t umLChar, strL[80];

   printf( "Digite um inteiro, um real e um "
           "caractere (nesta ordem): " );

   resultado = wscanf( L"%d %f %c", &umInt,
                       &umFloat, &umChar );

   printf( "Numero de valores lidos e atribuidos: %d\n",
           resultado );

      /* A chamada de wprintf() a seguir poder� n�o */
      /* imprimir nada porque o stream stdout tem   */
      /* orienta��o monobyte devido �s chamadas     */
      /* anteriores de printf().                    */
   if (resultado == 3)
      wprintf( L"\nValores lidos e atribuidos:\n\t%d "
               L"\n\t%f \n\t%c \n",
               umInt, umFloat, umChar );

   return 0;
}

/***

Resultado do programa no Linux:

Digite um inteiro, um real e um caractere (nesta ordem): 25 3.14c
Numero de valores lidos e atribuidos: 3

***/
