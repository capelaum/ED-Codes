/******************************/
/* Exemplo de uso de fgetws() */
/******************************/

#include <stdio.h>
#include <wchar.h>

#define TAM_ARRAY 80

int main()
{
   FILE    *stream;
   wchar_t  ar[TAM_ARRAY];
   wchar_t *p;

   stream = fopen("TesteExtenso.txt", "r");

   if (!stream)
      perror("Abrindo arquivo de entrada");

   p = fgetws(ar, sizeof(ar), stream);

   if (!p)
      perror("Lendo arquivo de entrada");
   else
      wprintf(L"\nString lido: \"%s\"", p);

   return 0;
}
