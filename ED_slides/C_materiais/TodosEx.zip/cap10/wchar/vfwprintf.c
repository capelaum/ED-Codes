/*******************************/
/* Exemplo de uso de vfwprintf */
/*******************************/

#include <stdio.h>
#include <wchar.h>
#include <stdarg.h>

/****
 * Fun��o EscreveEmStream(): escreve dados formatados no
 *                           stream especificado usando
 *                           vfwprintf()
 ****/

int EscreveEmStream(FILE *stream, const wchar_t *formato, ...)
{
   va_list  argumentos;
   int      retorno;

   va_start(argumentos, formato);

   retorno = vfwprintf(stream, formato, argumentos);

   va_end(argumentos);

   return retorno;
}

int main(void)
{
   FILE *stream;
   int 	 umInteiro = 30;
   float umFloat = 7.45;
   char  umString[80] = "Teste";

   stream = tmpfile();	/* Cria um arquivo tempor�rio */

   if (!stream) {
      perror("Arquivo temporario nao pode ser criado.");
      return 1;
   }

   EscreveEmStream( stream, L"%d %f %s",
                    umInteiro, umFloat, umString );

   rewind(stream);

   fscanf( stream,"%d %f %s",
           &umInteiro, &umFloat, umString );

   printf("%d %f %s\n", umInteiro, umFloat, umString);

   fclose(stream);

   return 0;
}
