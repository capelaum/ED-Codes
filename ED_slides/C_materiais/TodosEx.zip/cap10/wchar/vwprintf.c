/******************************/
/* Exemplo de uso de vwprintf */
/******************************/

#include <stdio.h>
#include <wchar.h>
#include <stdarg.h>

int Imprime(const wchar_t *formato, ...)
{
   va_list argumentos;
   int     retorno;

   va_start(argumentos, formato);

   retorno = vwprintf(formato, argumentos);

   va_end(argumentos);

   return retorno;
}

int main()
{
   int      umInteiro = 32;
   float    umFloat = 44.9;
   wchar_t *umString = L"Isto e' um teste";

   Imprime(L"%d %f %ls\n",umInteiro, umFloat, umString);

   return 0;
}
