/*****************************/
/* Exemplo de uso de fgetwc */
/*****************************/

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <errno.h>

int main(void)
{
   FILE    *stream;
   wint_t   cExtenso;

   if (!(stream = fopen("Dados.txt", "r"))) {
      printf( "Nao foi possivel abrir o arquivo:"
              " \"Dados.dat\"\n" );
      return 1;
   }

   errno = 0;

   while ((cExtenso = fgetwc(stream)) != WEOF)
      printf("Caractere extenso lido = %lc\n", cExtenso);

   if (errno == EILSEQ) {
      printf("Encontrado um caractere extenso invalido.\n");
      return 1;
   }

   fclose(stream);

   return 0;
}
