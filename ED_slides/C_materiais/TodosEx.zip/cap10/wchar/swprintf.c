/***********************/
/* Exemplo de swprintf */
/***********************/

#include <stdio.h>
#include <wchar.h>

#define MAX 80

int main(void)
{
   wchar_t  str[MAX];
   int      umInt = 32, nCarEscritos = 0;
   double   umDouble = 6.35;
   wchar_t  *umString = L"trivial";
   wchar_t  umChar = L'X';
   wchar_t  *formato = L"umInt = %d, umDouble = %f, "
                       L"umString = %ls, umChar = %lc";

   nCarEscritos = swprintf( str, MAX, formato, umInt,
                            umDouble, umString, umChar );

   printf( "String:\n\t%ls \n\nNumero de caracteres "
           "escritos: %d\n", str, nCarEscritos );

   return 0;
}
