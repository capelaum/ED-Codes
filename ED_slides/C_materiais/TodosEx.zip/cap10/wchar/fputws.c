/****************************/
/* Exemplo de uso de fputws */
/****************************/

#include <stdio.h>
#include <wchar.h>
#include <errno.h>

int main(void)
{
   FILE    *stream;
   wchar_t *strExtenso = L"Isto e' um teste.";

   if (!(stream = fopen("Arq.dat", "w"))) {
      fprintf(stderr, "Nao foi possivel abrir arquivo.\n");
      return 1;
   }

   errno = 0;

   if ( fputws(strExtenso, stream) == -1 ) {
      fprintf( stderr, "Nao foi possivel completar"
               " a operacao.\n");

      if (errno == EILSEQ)
         fprintf( stderr, "Foi encontrado um caractere"
                  " extenso invalido.\n" );

      return 1;
   }

   fclose(stream);

   return 0;
}
