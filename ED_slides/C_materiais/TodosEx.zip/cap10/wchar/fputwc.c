/****************************/
/* Exemplo de uso de fputwc */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   FILE     *arquivo;
   wchar_t  c = L'C';

   arquivo = fopen("Arq2.txt", "w");

   if ( fputwc(c, arquivo) == WEOF ) {
      printf("Erro ao tentar escrever no arquivo");
      return 1;
   } else
      printf("O caractere %lc foi escrito no arquivo", c);

   fclose(arquivo);

   return 0;
}
