/********************************/
/* Exemplo de uso de fwprintf() */
/********************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#define LOCALE_BR "pt_BR.utf8"

int main()
{
   wchar_t palavraLocal[] = L"Cora\u00E7\u00E3o";
   char    palavraSemAcento[]= "Coracao";
   char   *localidade;

   localidade = setlocale(LC_ALL, LOCALE_BR);

   if (!localidade)
      fprintf( stderr, "Nao foi possivel alterar a "
                       "localidade para %s.\n"
                       "A localidade corrente e' %s.\n",
                       localidade, setlocale(LC_ALL, NULL));

   fwprintf( stdout, L"Palavra: %ls\n"
                      "Palavra sem acento: %s\n",
             palavraLocal, palavraSemAcento );

   return 0;
}
