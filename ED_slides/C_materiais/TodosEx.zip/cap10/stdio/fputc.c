/***************************/
/* Exemplo de uso de fputc */
/***************************/

#include <stdio.h>

int main(void)
{
   FILE *stream;
   char *str = "Isto e' um teste.";

      /* Abre Arq1.txt para escrita */
   if ( !(stream = fopen("Arq1.txt", "w")) ) {
      fprintf(stderr, "Arquivo nao foi aberto");
      return 1;
   }

      /* Escreve cada caractere do */
      /* string 'str' em Arq1.txt  */
   while (*str)
      fputc(*str++, stream);

   fclose(stream);

   return 0;
}
