/*****************************/
/* Exemplo de uso de ftell() */
/*****************************/

#include <stdio.h>
#include <string.h>

#define MAX_LINHA 256
#define NOME_ARQ  "Teste.txt"

void ConstroiArqTeste()
{
   FILE *stream;
   char *conteudo[] = { "bola", "bala", "bela",
                        "balde", "bula", "bilhar" };
   int  i, nElementos = sizeof(conteudo)/sizeof(conteudo[0]);

   if ( !(stream = fopen(NOME_ARQ, "w")) )
      return;

   for (i = 0; i < nElementos; ++i)
      fprintf(stream, "%s\n", conteudo[i]);

   fclose(stream);
}

int main(int argc, char **argv)
{
   FILE  *stream;
   long   posicao = 0L;
   char   linha[MAX_LINHA];
   char  *p, palavra[MAX_LINHA];
   int    c, numLinha = 0;

   ConstroiArqTeste();

   printf("\nDigite a palavra a ser procurada: ");
   p = fgets(palavra, MAX_LINHA, stdin);

   if (!p && *p != '\n') {
      fprintf(stderr, "\nEntrada incorreta. Bye.\n");
      return 1;
   }

      /* Se o caractere de quebra de linha */
      /* foi inclu�do no string, remove-o  */
   if (palavra[strlen(palavra) - 1] == '\n')
      palavra[strlen(palavra) - 1] = '\0';

   if ( !(stream = fopen(NOME_ARQ, "r")) ) {
      fprintf(stderr, "\nNao foi possivel abrir o arquivo\n");
       return 1;
   }

   do {
           /* Marca o inicio da linha corrente */
      if ( (posicao = ftell(stream)) == -1L ) {
         fprintf( stderr, "\nNao foi possivel obter"
                  " a posicao no arquivo\n" );
         return 1;
      }

      numLinha++;

          /* L� a proxima linha do arquivo */
      if (!fgets(linha, MAX_LINHA, stream))
         break;
   } while (!strstr(linha, palavra));

         /* Ou a palavra foi encontrada ou fim de arquivo */
   if ( feof( stream )) {
      fprintf( stderr, "\nNao foi possivel encontrar "
               "\"%s\" em %s\n", palavra, NOME_ARQ );
      rewind(stream); /* Volta ao in�cio do arquivo */
   } else {
      printf( "\nA palavra \"%s\" foi encontrada "
              "na linha %d do arquivo \"%s\"\n",
              palavra, numLinha, NOME_ARQ );

         /* Move o apontador de arquivo para   */
         /* o inicio da linha contendo a chave */
      fseek( stream, posicao, 0 );
   }

      /* Se a palavra foi encontrada, imprime o */
      /* arquivo a partir da linha que cont�m a */
      /* palavra. Caso contr�rio, imprime todo  */
      /* conte�do do arquivo em stdout.         */

   printf( "\nConteudo do arquivo a partir de seu inicio "
           "ou da palavra encontrada:\n\n" );

   while((c = fgetc(stream)) != EOF)
      putchar(c);

   fclose(stream);

   return 0;
}
