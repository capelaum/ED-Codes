/*****************************/
/* Exemplo de uso de fseek() */
/*****************************/

#include <stdio.h>

typedef struct {
   long    ID;
   double  valor;
 } tRegistro;

void CriaArquivoDeRegistros()
{
   tRegistro registros[] = { {32L, -2.5},
                             {56L, 4.23},
                             {22L, -0.34},
                             {123L, 5.44},
                             {13L, 7.22} };
   FILE *stream;

   if ( !(stream = fopen("Registros.dat", "wb")) ) {
      perror("Nao foi possivel criar arquivo de registros");
      return;
   }

   fwrite( registros, sizeof(tRegistro),
           sizeof(registros)/sizeof(registros[0]), stream );

   fclose(stream);
}

int main()
{
   FILE      *stream;
   tRegistro  umRegistro;
   long       chave = 123L; /* Valor de ID a ser procurado */

   CriaArquivoDeRegistros();

   if ( !(stream = fopen("Registros.dat", "rb")) )
      perror("Nao foi possivel abrir arquivo de registros");
   else
      do { /* Procura registro com ID = chave */
         if (fread(&umRegistro.ID, sizeof(long), 1, stream) < 1) {
            fprintf( stderr, "Registro com ID %ld nao encontrado\n",
                     chave );
            break;
         } else /* Salta o resto do registro */
            if (fseek( stream, sizeof(tRegistro) - sizeof(long),
                       SEEK_CUR )) {
               perror("fseek() falhou");
               break;
		    }
      } while (umRegistro.ID != chave);

   if (umRegistro.ID == chave)
      printf("\nA chave %ld foi encontrada\n", chave);

   return 0;
}
