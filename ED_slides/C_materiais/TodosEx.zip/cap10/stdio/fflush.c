/**************************************************
 * Exemplo de fflush(): Sem o uso de  fflush(), o *
 *  programa a seguir poderia n�o imprimir a      *
 *  mensagem: "Antes da divisao".                 *
 **************************************************/

#include <stdio.h>

int main()
{
   int i = 1, j = 0;

   printf("Antes da divisao");
   fflush(stdout);

      /* Divis�o proposital por zero */
   i = i / j;

   printf("\nDepois da divisao\n");

   return 0;
}

/***

Resultado do programa no Linux:

Sem fflus():

Floating point exception

Com fflus():

Antes da divisao
Floating point exception

***/
