/***************************/
/* Exemplo de uso de scanf */
/***************************/

#include <stdio.h>

int main()
{
   int    inteiro;
   float  real;
   int    nValoresLidos, c;

      /* Apresenta um prompt inicial para o usu�rio */
   printf("\nDigite um numero inteiro "
          "seguido de um numero real: " );

      /* Garante que o usu�rio recebe a mensagem */
   fflush(stdout);

      /* Permanece no la�o at� que o usu�rio */
      /* digite os dados corretamente.       */
   while(1) {
      nValoresLidos = scanf("%d %f", &inteiro, &real);

      if (2 == nValoresLidos)
         break; /* Usu�rio digitou corretamente */

      if (1 == nValoresLidos) /* Um prompt mais elaborado */
         printf( "\nO segundo valor digitado esta' "
                 "incorreto. Digite os dois valores "
                 "novamente: " );
      else if (0 == nValoresLidos) /* Um prompt mais elaborado */
         printf( "\nOs dois valores digitados estao "
                 "incorretos. Digite-os novamente: " );
      else { /* S� existem as tr�s possibilidades acima */
         fprintf( stderr, "\nEste programa contem um bug "
                  "nao identificado." );
         return 1;
      }

         /* Limpa o buffer de entrada. Se  */
         /* isto n�o for feito, o programa */
         /* entra num la�o sem fim.        */
      while ( (c = getchar()) != '\n' && c != EOF )
         ; /* Intecionalmente vazio */
   }

   printf( "\nOs valores introduzidos foram: %d e %f\n",
           inteiro, real );

   return 0;
}
