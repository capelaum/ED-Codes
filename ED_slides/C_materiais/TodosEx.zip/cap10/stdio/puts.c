/**************************/
/* Exemplo de uso de puts */
/**************************/

#include <stdio.h>

int main(void)
{
   char str[]= "Isto e' um teste.";

      /* Imprime o string no meio de sa�da padr�o */
   puts(str);

   return 0;
}
