/*****************************/
/* Exemplo de uso de getchar */
/*****************************/

#include <stdio.h>

int main(void)
{
   int c;

   printf("Digite uma frase: ");

         /* Imprime a frase caractere por      */
         /* caractere at� encontrar '\n'ou EOF */
   while (c != '\n' && c != EOF) {
      c = getchar();
      putchar(c);
   }

   putchar('^');
   putchar('\n');
   putchar('|');
   printf("\n\nEsta foi a frase que voce digitou\n");

   return 0;
}
