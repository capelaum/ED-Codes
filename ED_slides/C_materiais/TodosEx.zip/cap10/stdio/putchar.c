/*****************************/
/* Exemplo de uso de putchar */
/*****************************/

#include <stdio.h>
#include <limits.h>
#include <ctype.h>

int main(void)
{
   int c;
    
      /* Imprime todas as letras do      */
      /* conjunto de caracteres corrente */
   for(c = 0; c <= CHAR_MAX; ++c) 
      if (isalpha(c))
         putchar(c);

   return 0;
}
