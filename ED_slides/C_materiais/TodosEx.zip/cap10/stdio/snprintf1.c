/********************************/
/* Exemplo 1 de uso de snprintf */
/********************************/

#include <stdio.h>

#define MAX 50

int main()
{
   char    ar[MAX];
   double  x = -123.45,
           y = 67.89,
           z = 123.01,
           resultado;
   int     carEscritos = 0;

   resultado = x * y + z;

   carEscritos = snprintf( ar, MAX, "Usando os valores %f, %f"
                           " e %f, o resultado foi %f.\n",
                           x, y, z, resultado );

#ifdef TESTE
   printf("\nValor retornado = %d\n\n", carEscritos);
#endif

   printf("Conteudo do array:\n\t\"%s\"", ar);

   fflush(stdout);

   if ( carEscritos >= MAX )
      fprintf( stderr, "\n\nO string resultante foi truncado:\n\t"
               "%d caracteres nao foram escritos no array\n",
               carEscritos - MAX + 1 );

   return 0;
}

/***************** Resultado do programa *****************

Valor retornado = 85

Conteudo do array:
	"Usando os valores -123.450000, 67.890000 e 123.0"

O string resultante foi truncado:
	36 caracteres nao foram escritos no array

**********************************************************/
