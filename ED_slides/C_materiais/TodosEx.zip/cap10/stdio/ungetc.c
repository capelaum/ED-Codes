/******************************/
/* Exemplo de uso de ungetc() */
/******************************/

#include <stdio.h>

#define MAX_DIGITOS 20

int main()
{
   FILE *stream;
   int   c, i = 0;
   char  digitos[MAX_DIGITOS + 1];

      /* Abre arquivo para escrita e leitura */
   if ( !(stream = fopen("Arq1.txt", "w+")) ) {
      fprintf(stderr, "\nNao foi possivel abrir o arquivo\n");
      return 1;
   }

      /* Escreve um string alfanum�rico no arquivo */
   fprintf(stream, "123245abcd");

   rewind(stream); /* Volta ao in�cio do stream */

      /* Coleta os digitos que se encontram no in�cio do  */
      /* arquivo. Se algum caractere que n�o � d�gito for */
      /* lido, ele ser� devolvido ao stream. O n�mero de  */
      /* d�gitos lidos � limitado a MAX_DIGITOS.          */

   for (i = 0; i < MAX_DIGITOS; ++i) {
      c = getc(stream);
      if (isdigit(c))
         digitos[i] = c;
      else
         break;
   }

   digitos[i] = '\0'; /* Termina o string num�rico */

      /* O n�mero m�ximo de d�gitos foi lido ou */
      /* um caractere que n�o � d�gito foi lido */
      /* ou o final do arquivo foi atingido ou  */
      /* ocorreu um erro de leitura.            */

   if (ferror(stream)) {
      fprintf(stderr, "\nOcorreu um erro de leitura no arquivo\n");
      return 1;
   }

         /* Se um caractere que n�o � d�gito */
         /* foi lido, devolve-o ao stream.   */
   if (!isdigit(c) && c != EOF)
      if (ungetc(c, stream) == EOF) {
	     fprintf(stderr, "\nA funcao ungetc() falhou.\n");
	     return 1;
	  }

#ifdef TESTE
   printf("\nUltimo caractere lido: %c", c);
   printf("\nCaractere lido no arquivo: %c", getc(stream));
#endif

   printf("\nDigitos lidos no inicio do arquivo: %s\n", digitos);

   fclose(stream);

   return 0;
}
