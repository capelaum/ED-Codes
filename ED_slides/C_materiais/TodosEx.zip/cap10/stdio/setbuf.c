/****************************/
/* Exemplo de uso de setbuf */
/****************************/

#include <stdio.h>

int main()
{
   char   buffer[BUFSIZ];
   FILE  *stream1, *stream2;

   stream1 = fopen("Arq1.txt","w");
   stream2 = fopen("Arq2.txt","w");

      /* stream1 ter� buffer */
   setbuf(stream1, buffer);
   fputs( "Alguma coisa escrita em \"Arq1.txt\"",
          stream1 );
   fflush(stream1);

      /* stream2 n�o ter� buffer */
   setbuf(stream2, NULL);
   fputs( "Alguma coisa escrita em \"Arq2.txt\"",
          stream2 );

   fclose(stream1);
   fclose(stream2);

   return 0;
}
