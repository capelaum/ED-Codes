#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#define TAMANHO 80

/****
 *
 * Fun��o Acrescenta(): acrescenta um string formatado
 *                      ao final de outro string usando
 *                      a fun��o vsprintf()
 *
 * Argumentos: str (entrada/sa�da) - string que ter� outro
 *                                   acrescentado
 *             formato (entrada) - string de formata��o
 *             ... (entrada) - dados que ser�o formatados
 *                             pelo string de formata��o
 *
 * Retorno: ponteiro para str
 *
 ****/

char *Acrescenta(char *str, const char *formato, ...)
{
   va_list args;

   if (str && formato) {
      va_start(args, formato);
      vsprintf(str + strlen(str), formato, args);
      va_end(args);
   }

   return str;
}

int main(void)
{
   char str[TAMANHO + 1] = "\nValor digitado: ";
   int numero, teste;

   printf("\nDigite um numero inteiro: ");
   teste = scanf("%d", &numero);

   if (!teste) {
      printf("\nVoce nao digitou um numero inteiro.\n");
      return 1;
   }

   Acrescenta(str, "%d.\n", numero);

   puts(str);

   return 0;
}
