/****************************/
/* Exemplo de uso de fscanf */
/****************************/

#include <stdio.h>

int main(void)
{
   char  string[20];
   int   umInt, nValoresLidos;
   FILE  *stream;

      /* Tenta abrir o arquivo */
   if (!(stream = fopen("Arq1.txt", "w+"))) {
      printf("Nao foi possivel abrir o arquivo");
      return 1;
   }

      /* Imprime um string e um inteiro no arquivo */
   fprintf(stream, "String 125");

   rewind(stream); /* Volta ao in�cio do stream */

   nValoresLidos = fscanf( stream, "%20s %d",
                           string, &umInt );

   if (nValoresLidos == 2)
      printf("O valor lido foi: %d", umInt);
   else
      printf("Nao foi lido nenhum valor inteiro");

   fclose(stream);

   return 0;
}

