/****************************/
/* Exemplo de uso de fwrite */
/****************************/

#include <stdio.h>

#define TAM_ARRAY(ar) sizeof(ar)/sizeof(ar[0])

int main(void)
{
   FILE *stream;
   int arrayInt[] = {1, 2, 3, 4, 5, 6, 7, 8, 9},
       arrayIntLido[9],
       i;

         /* Abre Arq1.bin para escrita */
   if ( !(stream = fopen("Arq1.bin", "wb")) ) {
      fprintf(stderr, "Arquivo nao pode ser aberto");
      return 1;
   }

         /* Escreve o array 'arrayInt' em Arq1.bin */
   fwrite( arrayInt, sizeof(arrayInt[0]),
           TAM_ARRAY(arrayInt), stream );

         /* Reabre Arq1.bin; agora, para leitura */
   if ( !freopen("Arq1.bin", "rb", stream) ) {
      fprintf(stderr, "Arquivo nao pode ser reaberto");
      return 1;
   }

         /* L� o array no arquivo Arq1.bin */
   fread( arrayIntLido, sizeof(arrayInt[0]),
          TAM_ARRAY(arrayInt), stream );

   printf("\nArray lido no arquivo: { ");

         /* Exibe os elementos do array em stdout */
   for(i = 0; i < 8; ++i)
      printf("%d, ", arrayIntLido[i]);

   printf("%d }\n", arrayIntLido[i]); /* �ltimo elemento */
   
   fclose(stream);

   return 0;
}
