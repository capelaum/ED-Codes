/*******************************/
/* Exemplo de uso de fprintf() */
/*******************************/

#include <stdio.h>
#include <time.h>

int main()
{
   FILE  *stream;
   time_t sec;

   stream = fopen("Arq1.txt", "a");

   if (stream) {
      time(&sec);
      fprintf( stream, "\nUltima atualizacao deste arquivo: %.24s",
               ctime(&sec) );
   }

   return 0;
}
