/****************************/
/* Exemplo de uso de remove */
/****************************/

#include <stdio.h>

int main(int argc, char *argv[])
{
   if (argc != 2) {
      printf( "\nErro: este programa deve ser "
              "usado assim:\n\n\t%s "
              "<arquivo-a-ser-apagado>\n", argv[0]);
      return 1;
   }

         /* Exclui o arquivo */
    if(remove(argv[1]))
        printf( "\nOcorreu um erro ao tentar remover "
                "o arquivo \"%s\"\n", argv[1] );
    else
        printf("\nArquivo \"%s\" foi removido\n", argv[1]);

    return 0;
}
