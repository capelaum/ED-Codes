/***************************/
/* Exemplo de uso de fread */
/***************************/

#include <string.h>
#include <stdio.h>

#define MAX  20

int main(void)
{
   FILE  *stream;
   char   str[] = "Isto e' um teste.";
   char   ar[MAX];
   size_t caracteresLidos;
   int    i;

      /* Abre arquivo para leitura e escrita */
   if ( !(stream = fopen("Arq1.txt", "w+")) ) {
      fprintf(stderr, "Arquivo nao pode ser aberto.\n");
      return 1;
   }

      /* Escreve string no arquivo, limitando */
      /* o n�mero de caracters escritos a MAX */
   fprintf(stream, "%.*s", MAX, str);

      /* Volta ao in�cio do arquivo */
   rewind(stream);

   caracteresLidos = fread(ar, 1, MAX, stream);

   printf( "\nNumero de caracteres lidos: %d\n", 
           caracteresLidos );
   
   printf( "\nCaracteres lidos: \"");
   
      /* Imprime os caracteres lidos no arquivo */
   for (i = 0; i < caracteresLidos; ++i)
      putchar(ar[i]);

   printf("\"\n");
   
   fclose(stream);

   return 0;
}
