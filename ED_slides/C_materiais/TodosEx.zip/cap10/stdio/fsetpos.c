/*******************************/
/* Exemplo de uso de fsetpos() */
/*******************************/

#include <stdio.h>

#define MAX_LINHA 256

int main()
{
   FILE   *stream;
   fpos_t  marca;
   char   *p, linha[MAX_LINHA];
   int     i, c;

   if ( !(stream = fopen("Teste.txt", "r+")) ) {
      fprintf(stderr, "\nNao foi possivel abrir arquivo\n");
      return 1;
   }

      /* Salta tr�s linhas no arquivo */
   for (i = 0; i < 3; ++i)
      fgets(linha, MAX_LINHA, stream);

      /* Guarda a posi��o corrente */
   if (fgetpos(stream, &marca)) {
      perror("\nGuardando posicao no arquivo");
      return 1;
   }

      /* Imprime o conte�do do arquivo na */
      /* tela a partir da quarta linha    */
   printf( "\nConteudo do arquivo a partir "
           "da quarta linha:\n\n" );

   while((c = fgetc(stream)) != EOF)
      putchar(c);

      /* Retorna � posi��o guardada */
   if (fsetpos(stream, &marca)) {
      perror("\nRestaurando posicao no arquivo");
      return 1;
   }

      /* Redireciona a entrada  */
      /* padr�o para um arquivo */
   freopen("TesteCopia.txt", "w", stdout);

      /* Imprime o conte�do do arquivo em */
      /* arquivo a partir da quarta linha */
   printf( "Conteudo do arquivo a partir "
           "da quarta linha:\n\n" );

   while((c = fgetc(stream)) != EOF)
      putchar(c);

   fclose(stream);

   return 0;
}
