/****************************/
/* Exemplo de uso de feof() */
/****************************/

#include <stdio.h>

int main(void)
{
   FILE *stream;
   int   c;

   if (!(stream = fopen("Arq1.txt", "r"))) {
      printf("\nArquivo nao pode ser aberto\n");
      return 1;
   }

      /* L� e imprime na tela os caracteres do arquivo */
   while ( (c = fgetc(stream)) != EOF )
      putchar(c);

      /* Se o final do arquivo n�o foi atingido   */
      /* depois de fgetc() retornar EOF, � porque */
      /* ocorreu um erro de leitura.              */
   if (!feof(stream))
      printf("\nOcorreu um erro de leitura no arquivo\n");

   fclose(stream);

   return 0;
}
