/*********************/
/* Exemplo de sscanf */
/*********************/

#include <stdio.h>
#include <string.h>

/****
 *
 * Fun��o ConverteDataParaISO(): converte um string de data
 *                               no formato usado pela
 *                               macro __DATE__ para o
 *                               formato padr�o ISO
 *
 * Exemplo: "Sep 16 1992" � convertida em "1992-09-16"
 *
 * Argumentos: strConversao (sa�da) - a data no formato ISO
 *             data (entrada) - a data no formato da macro
 *                              __DATE__
 *
 * Retorno: ponteiro para um string contendo a data no
 *          formato ISO
 *
 ****/

char *ConverteDataParaISO(char *strConversao, const char *data)
{
   char *meses_DATE[12] = { "Jan", "Feb", "Mar", /* Meses no */
                            "Apr", "May", "Jun", /* formato  */
                            "Jul", "Aug", "Sep", /* __DATE__ */
                            "Oct", "Nov", "Dec" };
   char  strMes[4], /* Strings que cont�m o m�s, ... */
         strDia[3], /* o dia e ...                   */
         strAno[5]; /* o ano no formato __DATE__     */
   int   i;

      /* Separa a data em strings */
      /* contendo dia, m�s e ano  */
   sscanf(data, "%s %s %s", strMes, strDia, strAno);

      /* Encontra o m�s e insere sua ordem (1-12) no string */
   for ( i = 0 ; i < 12; ++i) {
      if (!strcmp(strMes, meses_DATE[i])) {
         sprintf(strMes, "%0.2i", i + 1 );
         break;
      }
   }

        /* A fun��o deveria verificar se a data � */
        /* v�lida antes de prosseguir, mas, neste */
        /* exemplo, isto n�o � importante.        */

         /* Combina data, mes e ano no   */
         /* stringque cont�m a convers�o */
   sprintf( strConversao, "%04.4s/%02.2s/%02.2s",
            strAno, strMes, strDia );

   return strConversao;
}

/****
 *
 * Fun��o main(): imprime a data de compila��o
 *                deste arquivo no formato ISO
 *
 ****/

int main(void)
{
   char  dataISO[11];

   printf( "\nA data de compilacao no formato ISO e': %s\n",
           ConverteDataParaISO(dataISO, __DATE__) );

   return 0;
}
