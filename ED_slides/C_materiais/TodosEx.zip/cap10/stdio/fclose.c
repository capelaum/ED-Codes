#include <stdio.h>

int main(void)
{
   FILE *stream;
   char  str[] = "Este e' um arquivo de texto";

   stream = fopen("Arq1.txt", "w");

      /* Testa se arquivo foi aberto */
   if (!stream) {
      fprintf(stderr, "Arquivo nao pode ser aberto");
      return 1;
   }

      /* Escreve conte�do do string no arquivo */
   fprintf(stream, "%s", str);

      /* Se fclose() retornar um valor diferente */
      /* de zero ocorreu algum erro na tentativa */
      /* de fechamento do arquivo.               */
   if (fclose(stream)) {
      printf("O arquivo nao pode ser corretamente fechado.");
      return 1;
   }

   return 0;
}
