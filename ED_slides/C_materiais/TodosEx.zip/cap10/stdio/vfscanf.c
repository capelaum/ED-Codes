/*****************************/
/* Exemplo de uso de vfscanf */
/*****************************/

#include <stdio.h>
#include <stdarg.h>

/****
 *
 * Fun��o LeDadosLinha(): l� dados formatados de acordo com
 *                        um string de formata��o na n-�sima
 *                        linha de um arquivo-texto
 *
 * Argumentos: arquivo (entrada) - nome do arquivo
 *             n (entrada) - �ndice da linha (come�ando em 1)
 *             formato (entrada) - string de formata��o
 *             ... (sa�da) - endere�os de vari�veis que ter�o
 *                           valores atribu�dos
 *
 * Retorno: n�mero de vari�veis que tiveram valores atribu�dos
 *
 ****/

int LeDadosLinha( const char *arquivo, unsigned n,
                  char *formato, ... )
{
   int      nValoresAtribuidos;
   va_list  args;
   FILE    *stream;
   int      caractere;
   unsigned i;

   if (!(stream = fopen(arquivo, "r")))
      return 0;

   if (!n) { /* Indexa��o de linhas come�a em 1 */
      fclose(stream);
      return 1;
   }

      /* L� e descarta linhas at� atingir */
      /* a n-�sima linha do arquivo       */
   for (i = 1; i < n; ++i) {
      do {
         caractere = getc(stream);
      } while ((caractere != '\n') && (caractere != EOF));

      if (caractere == EOF) { /* Final do arquivo atingido */
         fclose(stream);      /* antes da linha desejada   */
         return 0;
      }
   }

      /* Neste ponto, o apontador de posi��o do arquivo   */
      /* aponta para o in�cio da linha desejada. A fun��o */
      /* vfscanf() � chamada para completar o servi�o.    */

   va_start(args, formato);
   nValoresAtribuidos = vfscanf(stream, formato, args);
   va_end(args);

   fclose(stream);

   return nValoresAtribuidos;
}

/****
 *
 * Fun��o main(): testa a fun��o LeDadosLinha()
 *
 ****/

int main(void)
{
   int   umInt, nValoresLidos;
   float umFloat;
   char  umChar;

   nValoresLidos = LeDadosLinha( "Arq2.txt", 5, "%f %d %c",
                                 &umFloat, &umInt, &umChar );

   printf( "\nNumero de valores lidos e atribuidos: %d",
           nValoresLidos );

   if (nValoresLidos == 3)
      printf( "\nValores lidos: %f %d %c\n",
              umFloat, umInt, umChar );

   return 0;
}
