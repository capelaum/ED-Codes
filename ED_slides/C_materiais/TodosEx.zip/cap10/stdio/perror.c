/******************************/
/* Exemplo de uso de perror() */
/******************************/

#include <stdio.h>
#include <errno.h>

#define MAX_MSG 255 /* Tamanho m�ximo da mensagem */

int main(int argc, char** argv)
{
   char   msg[MAX_MSG] = "";
   FILE  *stream;

   if (!( stream = fopen( "ArqInexistente", "r" ))) {
      snprintf( msg, MAX_MSG,
                "\nFuncao %s, arquivo %s, \nlinha %d",
                __func__, __FILE__, __LINE__ );

      perror(msg);

      return 1;
   }

   return 0;
}
