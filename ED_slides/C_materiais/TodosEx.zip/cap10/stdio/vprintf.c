/*****************************/
/* Exemplo de uso de vprintf */
/*****************************/

#include <stdio.h>
#include <stdarg.h>

int SaidaFormatada(char *formato, ...)
{
   va_list 	         argumentos;
   int 		         retorno;
   const char *const msg = "\nResultado: ";

   printf(msg);

   va_start(argumentos, formato);
   retorno = vprintf(formato, argumentos);
   va_end(argumentos);

   return retorno;
}

int main()
{
   int    umInteiro = 32;
   float  umFloat = -4.9;

   SaidaFormatada("%d %f\n", umInteiro, umFloat);

   return 0;
}
