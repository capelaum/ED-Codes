/**************************/
/* Exemplo de uso de getc */
/**************************/

#include <stdio.h>

int main(int argc, char *argv[])
{
   FILE *stream;
   char c;

   if (2 != argc) {
      printf( "\nEste programa deve ser usado assim:\n"
              " %s <nome do arquivo texto>\n", argv[0]);
      return 1;
   }

      /* Tenta abrir para leitura o arquivo cujo  */
      /* nome foi introduzido na linha de comando */
   stream = fopen(argv[1],"r");

   if (!stream) {
      printf("Nao foi possivel abrir o arquivo\n");
      return 1;
   }

      /* Imprime o conte�do do arquivo at� */
      /* que seu final seja atringido      */
   while((c = getc(stream))!= EOF)
      printf("%c", c);

   fclose(stream);

   return 0;
}

