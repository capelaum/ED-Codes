/***
 *
 * Exemplo de uso de rewind()
 *
 * Este exemplo imprime o conte�do de um
 * arquivo-texto duas vezes: na primeira vez,
 * cada caractere � convertido para min�scula
 * e, na segunda vez, cada caractere � convertido
 * para mai�scula.
 *
 ***/

#include <stdio.h>

int main(int argc, char** argv)
{
   FILE *stream;
   int   c;

   if ( !(stream = fopen("Teste.txt", "r")) ) {
      fprintf(stderr, "\nNao foi possivel abrir arquivo\n");
      return 1;
   }

   printf("\nConteudo do arquivo em letras minusculas:\n" );

   while ((c = fgetc(stream)) != EOF)
      putchar(tolower(c));

   rewind( stream );

   printf("\nConteudo do arquivo em letras maiusculas:\n" );

   while ((c = fgetc(stream)) != EOF)
      putchar(toupper(c));

   fclose( stream );

   return 0;
}
