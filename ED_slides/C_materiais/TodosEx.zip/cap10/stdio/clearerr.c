/***************************************/
/* Exemplo de uso de ferror & clearerr */
/***************************************/

#include <stdio.h>

int main(void)
{
   FILE *stream;

      /* Abre o arquivo somente para leitura */
   if (!(stream = fopen("Arq1.txt","r"))) {
      fprintf(stderr, "\nNao foi possivel abrir arquivo\n");
      return 1;
   }

      /* Gera uma condi��o de erro    */
      /* tentando escrever no arquivo */
    fputc('c',stream);

      /* Verifica se h� alguma sinaliza��o */
      /* de erro para o arquivo           */
   if(ferror(stream)) {
      printf("\nOcorreu um erro de escrita\n");
         /* Zera indicadores de erro e de EOF */
      clearerr(stream);
   }

   fclose(stream);

   return 0;
}
