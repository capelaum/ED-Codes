/***************************/
/* Exemplo de uso de fputs */
/***************************/

#include <stdio.h>

int main(void)
{
   FILE  *stream;

      /* Abre Arq1.txt para escrita */
   stream = fopen("Arq1.txt","w");

   if (stream) { /* Abertura foi OK */
          /* A frase ser� escrita em Arq1.txt */
      fputs("\"O mar e' azul.\"", stream);
   } else { /* Arquivo n�o foi aberto */
          /* A frase ser� escrita na sa�da */
          /* padr�o de mensagens de erro   */
      fputs("O arquivo nao pode ser aberto.", stderr);
      return 1;
   }

   fclose(stream);

   return 0;
}
