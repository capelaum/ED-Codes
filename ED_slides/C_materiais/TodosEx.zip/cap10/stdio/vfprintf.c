#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

/****
 *
 * Fun��o AbortaComMensagem(): apresenta uma mensagem de erro
 *                             e aborta o programa
 *
 * Argumentos: formato (entrada) - string de formata��o da
 *                                 mensagem a ser impressa
 *             ... (entrada) - componentes da mensagem de erro
 *
 * Retorno: Nada
 *
 ****/

void AbortaComMensagem(char *formato, ...)
{
   va_list argumentos;

   va_start(argumentos, formato) ;
   vfprintf(stderr, formato, argumentos);
   fputc('\n', stderr);

   exit(1);
}

main()
{
   int x = 1, y = -1;

   if (x != y)
      AbortaComMensagem( "\nOs valores de x (%d) e y (%d) "
                         "deveriam ser iguais", x, y );

   return 0;
}
