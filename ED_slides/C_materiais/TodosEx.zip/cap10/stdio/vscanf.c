/****************************/
/* Exemplo de uso de vscanf */
/****************************/

#include <stdio.h>
#include <stdarg.h>

/****
 *
 * Fun��o LeituraComPrompt(): incorpora apresenta��o de prompt
 *                            com entrada de dados em stdin
 *
 * Argumentos: prompt (entrada) - a mensagem a ser apresentada
 *                                ao usu�rio em stdout
 *             formato (entrada) - string de formata��o
 *             ... (sa�da) - endere�os de vari�veis
 *
 * Retorno: o mesmo que scanf()
 *
 ****/

int LeituraComPrompt( const char *prompt,
                      const char *formato, ... )
{
   int     nValoresAtribuidos;
   va_list args;

      /* Apresenta o prompt para o usu�rio */
   printf(prompt);
   fflush(stdout);

      /* Delega a tarefa restante para vscanf() */
   va_start(args, formato);
   nValoresAtribuidos = vscanf(formato, args);
   va_end(args);

   return nValoresAtribuidos;
}

int main(void)
{
   int   umInt, nValores;
   float umFloat;

   nValores = LeituraComPrompt( "\nDigite um inteiro e "
                                "um real: ", "%d %f",
                                &umInt, &umFloat );

   printf( "Numero de valores lidos e atribuidos: %d\n",
           nValores );

   return 0;
}
