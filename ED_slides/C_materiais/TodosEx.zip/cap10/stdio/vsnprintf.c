/*******************************/
/* Exemplo de uso de vsnprintf */
/*******************************/

#include <stdarg.h>
#include <stdio.h>

#define TAM_ARRAY 20

void ArmazenaSaida(const char *str, const char *formato, ...)
{
   va_list args;
   int     n;

   va_start(args, formato);

   n = vsnprintf(str, TAM_ARRAY, formato, args);

   if (n >= TAM_ARRAY)
      fprintf( stderr, "\nO tamanho do array deveria ser:"
               " %d\n", n );

   va_end(args);
}


int main(void)
{
   char string[TAM_ARRAY];
   char formato[] = "%s  %s  %s\n";

   ArmazenaSaida( string, formato, "Janeiro", "Fevereiro",
                  "Marco" );

   printf("\nMeses de verao:  %s\n\n", string);

   return 0;
}

/*** Resultado do programa quando executado no Linux ***

O tamanho do array deveria ser: 26

Meses de verao:  Janeiro  Fevereiro


********************************************************/
