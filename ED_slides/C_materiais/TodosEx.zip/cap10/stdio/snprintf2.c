/********************************/
/* Exemplo 2 de uso de snprintf */
/********************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
   char   *ar;
   double  x = -123.45,
           y = 67.89,
           z = 123.01,
           resultado;
   int     carEscritos = 0;
   char   *formato = "Usando os valores %f, %f"
                     " e %f,\no resultado foi %f.";

   resultado = x * y + z;

      /* Calcula o espa�o necess�rio     */
      /* para conter o string resultante */
   carEscritos = snprintf( NULL, 0, formato,
                           x, y, z, resultado );

   ar = malloc(carEscritos + 1);

   carEscritos = snprintf( ar, carEscritos + 1, formato,
                           x, y, z, resultado );

#ifdef TESTE
   printf("\nValor retornado = %d\n\n", carEscritos);
#endif

   printf("Conteudo do array:\n\"%s\"\n", ar);

#ifdef TESTE
   printf( "\nComprimento do string no array = %d\n\n", 
           strlen(ar) );
#endif

   return 0;
}

/**************** Resultado do programa ****************

Valor retornado = 84

Conteudo do array:
"Usando os valores -123.450000, 67.890000 e 123.010000,
o resultado foi -8258.010500."

Comprimento do string no array = 84

********************************************************/
