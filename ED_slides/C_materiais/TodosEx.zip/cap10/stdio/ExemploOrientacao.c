/* Exemplos de Orienta��o de Streams */

#include <stdio.h>
#include <wchar.h>

int main()
{
      /* Ap�s a chamada de printf() a seguir a     */
      /* orienta��o de stdout passa a ser por byte */
   printf("\nEste string sera impresso.\n");

      /* A fun��o wprintf() requer que a    */
      /* orienta��o de stdout seja extensa. */
      /* Usar a fun��o fwide() n�o resolve! */
   wprintf(L"\nEste string NAO sera impresso.\n");

      /* Apesar de tipicamente usarem o mesmo meio,      */
      /* stdout e stderr s�o streams diferentes. Como    */
      /* stderr est� sendo usado pela primeira vez por   */
      /* fwprintf(), este stream ter� orienta��o extensa */
   fwprintf(stderr, L"\nImpresso sem problemas.\n");

   return 0;
}

