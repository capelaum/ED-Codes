/*********************************************/
/* Exemplo de uso de fgets(): Imprime o      */
/*         conte�do do pr�prio arquivo-fonte */
/*********************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define TAM_ARRAY 256

int main(int argc, char *argv[])
{
   FILE *stream;
   char  linha[TAM_ARRAY];
   int   contador = 0;
   char *nomeArqFonte, *nomeExec, *p;

      /* O primeiro argumento na linha de       */
      /* comando � o nome do arquivo execut�vel */
   nomeExec = argv[0];

      /* Verifica se o arquivo tem extens�o (DOS/Windows) */
   if (p = strchr(nomeExec, '.')) /* Arquivo tem extens�o */
      *p = '\0';      /* Remove a extens�o */

      /* Determina o prov�vel nome do arquivo-fonte */
   nomeArqFonte = malloc(strlen(nomeExec) + 3);
   nomeArqFonte = strcat(nomeExec, ".c");

   if (!(stream = fopen(nomeArqFonte, "r"))) {
      fprintf( stderr,
               "\nNao foi possivel encontrar arquivo-fonte" );
      return 1;
   }

   printf("\nConteudo do arquivo fonte:\n\n");

   while (fgets(linha, TAM_ARRAY, stream)) {
         linha[ strlen(linha) - 1 ] = '\0'; /* Remove '\n' */
         printf("Linha %3d: %s\n", ++contador, linha);
   }

      /* Se fgets() retorna NULL, ocorreu um erro */
      /* ou o final do arquivo foi encontrado     */
   if (!feof(stream)) { /* Ocorreu um erro */
      fprintf( stderr,
               "\nOcorreu um erro lendo o arquivo-fonte" );
      return 1;
   }

   printf("\nTotal de linhas no arquivo-fonte: %d\n", contador);

   return 0;
}
