/****************************/
/* Exemplo de uso de tmpnam */
/****************************/

#include <stdio.h>

int main()
{
   char  nome[L_tmpnam];
   FILE *stream,
        *streamTmp;
   int   c;

      /* Abre arquivo principal */
   if (!(stream = fopen("Arq1.txt", "r"))) {
      fprintf(stderr, "\nNao foi possivel abrir arquivo\n");
      return 1;
   }

      /* Determina nome de arquivo tempor�rio */
   tmpnam(nome);

#ifdef TESTE
   printf("\nNome do arquivo temporario: %s\n", nome);
#endif

      /* Abre arquivo tempor�rio */
   if (!(streamTmp = fopen(nome, "w+"))) {
      fprintf( stderr, "\nNao foi possivel abrir"
               " arquivo temporario\n" );
      return 1;
   }

   while ((c = fgetc(stream)) != EOF)
      if (fputc(c, streamTmp) == EOF)
         break;

   fclose(stream);

      /* O conte�do armazenado no arquivo tempor�rio  */
      /* seria processado aqui. Neste exemplo, ocorre */
      /* apenas a impress�o deste conte�do na tela.   */

   rewind(streamTmp);

   printf("\nConteudo do arquivo temporario:\n\n");
   
   while((c = fgetc(streamTmp)) != EOF)
      putchar(c);

   fclose(streamTmp);

      /* Arquivos tempor�rios como o criado aqui */
      /* n�o s�o removidos automaticamente. �    */
      /* preciso remov�-lo explicitamente.       */
   if (remove(nome))
      printf("\n\nNao foi possivel remover arquivo temporario\n");
   else
      printf("\n\nArquivo temporario foi removido\n");

   return 0;
}
