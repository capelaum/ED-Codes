/*****************************/
/* Exemplo de uso de setvbuf */
/*****************************/

#include <stdio.h>

#define TAM_BUFFER 20 /* Um buffer bem pequeno  */
                      /* para testar o programa */

int main ()
{
   char   buffer[TAM_BUFFER];
   FILE  *stream;
   char  *msg = "\nExamine o conteudo do arquivo "
                "\"Arq1.txt\", feche-o e digite "
                "[ENTER] para continuar";

   stream = fopen("Arq1.txt","w");

      /* O stream ter� buffering de linha */
   if(setvbuf(stream, buffer, _IOLBF, TAM_BUFFER)) {
      printf("Nao foi possivel estabelecer buffer\n");
      return 1;
   }

      /* O string a seguir ser� escrito */
      /* no buffer e n�o no arquivo     */
   fputs("Teste", stream);

   printf("%s", msg);
   getchar();

      /* O conte�do do buffer ser� enviado para o */
      /* arquivo juntamente com o caractere '\n' */
   fputc('\n', stream);

   printf("%s", msg);
   getchar();

   fputs( "Parte destes caracteres serao enviados ao "
          "arquivo apos excederem o tamanho do buffer.",
          stream);

   printf("%s", msg);
   getchar();

   fclose (stream);

   printf("%s", msg);
   printf("\nO programa sera' encerrado.");
   getchar();

   return 0;
}
