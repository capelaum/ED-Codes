/*****************************/
/* Exemplo de uso de freopen */
/*****************************/

#include <stdio.h>

int main(void)
{
   FILE *stream;
   char  c;

         /* Associa 'stream' com Arq1.txt */
   stream = fopen("Arq1.txt", "w");

         /* fprintf() escrever� em Arq1.txt */
   fprintf(stream, "Texto escrito em Arq1.txt\n");

         /* Associa 'stream' com Arq2.txt */
   stream = freopen("Arq2.txt", "w", stream);

         /* fprintf() escrever� em Arq2.txt */
   fprintf(stream, "Texto escrito em Arq2.txt\n");

         /* Associa Arq3.txt com stdout */
   freopen("Arq3.txt", "w", stdout);

         /* printf() escrever� em Arq3.txt */
   printf("Texto escrito em Arq3.txt");

         /* Associa Arq1.txt com stdin */
   freopen("Arq1.txt", "r", stdin);

         /* scanf() ler� um caractere em Arq1.txt */
   scanf("%c",&c);

        /* Imprime caractere lido em stderr */
   fprintf(stderr, "Carctere lido: %c\n", c);

   fclose(stream);

   return 0;
}
