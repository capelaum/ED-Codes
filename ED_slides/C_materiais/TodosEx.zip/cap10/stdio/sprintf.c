#include <stdio.h>
#include <string.h>

/****
 *
 * Fun��o HoraPadrao(): converte uma hora no formato da macro
 *                      __TIME__ para o formato HHMMSS.
 *
 * Exemplo: "10:49:31" � transformada em "104931"
 *
 * Par�metros: hora (entrada) - string no formato da macro
 *                              __TIME__ (HH:MM:SS)
 *             horaPadrao (sa�da) - string no formato HHMMSS
 *
 * Retorno: a hora no formato HHMMSS ou NULL, se ocorrer erro
 *
 ****/

char *HoraPadrao(char *horaPadrao, const char *hora)
{
   char  strAux[12]; /* String auxiliar de convers�o */
   char  h[3],  /* Hora     */
         m[3],  /* Minutos  */
         s[3];  /* Segundos */
   int   teste;

   teste = sscanf(hora, "%2s %*c %2s %*c %2s", h, m, s);

   if (teste != 3)
      return NULL;

      /* Divide o string em horas, minutos e segundos */
   sprintf(horaPadrao, "%s%s%s", h,m,s);

   return horaPadrao;
}

int main(void)
{
   char str[7];

   printf( "\nHora de compilacao no formato HH:MM:SS: %s",
           __TIME__ );
   printf( "\nHora de compilacao no formato HHMMSS: %s\n",
           HoraPadrao(str, __TIME__) );

   return 0;
}
