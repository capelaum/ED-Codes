/**************************/
/* Exemplo de uso de gets */
/**************************/

#include <stdio.h>

int main(void)
{
   char string[80]; /* Nunca � suficiente para gets() */

   printf("\nIntroduza um string: ");

      /* E se o usu�rio digitar   */
      /* mais de 80 caracteres??? */
   gets(string);

   printf("\nO string introduzido foi: \"%s\"\n", string);

   return 0;
}
