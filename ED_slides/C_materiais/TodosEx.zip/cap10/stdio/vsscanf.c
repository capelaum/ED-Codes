/*****************************/
/* Exemplo de uso de vsscanf */
/*****************************/

#include <stdio.h>
#include <stdarg.h>

int LeituraEmString(const char *s, const char *formato, ...)
{
   int     nValoresAtribuidos;
   va_list args;

   printf("\nString onde sera' feita a leitura: %s\n", s);

   va_start(args, formato);
   nValoresAtribuidos = vsscanf(s, formato, args);
   va_end(args);

   return nValoresAtribuidos;
}

int main(void)
{
   int   umInt, nValoresLidos;
   float umFloat;
   char  entrada[] = "12 3.1415 X algo mais";

   nValoresLidos = LeituraEmString( entrada, "%d %f",
                                    &umInt, &umFloat );

   printf( "\nNumero de valores lidos e atribuidos: %d",
           nValoresLidos );

   if (2 == nValoresLidos)
      printf( "\n\nValores lidos: %d e %f\n",
              umInt, umFloat );

   return 0;
}
