/*******************************/
/* Exemplo de uso de tmpfile() */
/*******************************/

#include <stdio.h>

int main()
{
   FILE *stream,
        *streamTmp;
   int   c;

   if (!(stream = fopen("Arq1.txt", "r"))) {
      fprintf( stderr, "\nNao foi possivel abrir arquivo\n");
      return 1;
   }

   if (!(streamTmp = tmpfile())) {
      fprintf( stderr,
               "\nNao foi possivel abrir arquivo temporario\n");
      return 1;
   }

   while ((c = fgetc(stream)) != EOF)
      if (fputc(c, streamTmp) == EOF)
         break;

   fclose(stream);

      /* O conte�do armazenado no arquivo tempor�rio  */
      /* seria processado aqui. Neste exemplo, ocorre */
      /* apenas a impress�o deste conte�do na tela.   */

   rewind(streamTmp);

   while((c = fgetc(streamTmp)) != EOF)
      putchar(c);

   fclose(streamTmp);

   return 0;
}
