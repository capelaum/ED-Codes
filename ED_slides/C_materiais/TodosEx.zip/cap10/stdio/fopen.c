/***************************/
/* Exemplo de uso de fopen */
/***************************/

#include <stdio.h>

int main(void)
{
   FILE *stream;

      /* Abre o arquivo para escrita */
   stream = fopen("Arq1.txt","r");

      /* Verifica se a abertura do */
      /* arquivo ocorreu sem erros */
   if (stream == NULL) {
      printf("O arquivo Arq1.txt nao pode ser aberto.");
      return 1;
   }

   fclose(stream); /* Fecha o arquivo */

   return 0;
}
