/****************************/
/* Exemplo de uso de rename */
/****************************/

#include <stdio.h>

int main(int argc, char *argv[])
{
   if (argc != 3) {
      printf( "\nErro: este programa deve "
              "ser usado assim:\n\n\t%s"
              " <nome-atual> <novo-nome>\n", argv[0] );
      return 1;
   }

         /* Renomea o arquivo */
    if(rename(argv[1], argv[2]))
        printf( "\nOcorreu um erro ao tentar "
                "renomear o arquivo \"%s\"\n", argv[2] );
    else
        printf( "\nO arquivo \"%s\" foi renomeado "
                "para \"%s\"\n", argv[1], argv[2] );

    return 0;
}
