/***********************************************************/
/* Execute o programa abaixo para conhecer os valores das  */
/* macros (constantes) definidas no arquivo limits.h.      */
/***********************************************************/

#include <stdio.h>
#include <limits.h>

int main()
{
   printf("Numero de bits utilizados para representar "
          "um valor do tipo char: %d\n", CHAR_BIT);
   printf("Maior valor permitido para o tipo char: %d\n",
           CHAR_MAX);
   printf("Menor valor permitido para o tipo char: %d\n",
           CHAR_MIN);
   printf("Maior valor para o tipo int: %d\n",
           INT_MAX);
   printf("Menor valor para o tipo int: %d\n",
           INT_MIN);
   printf("Maior valor para o tipo long long: %lli "
           "(C99)\n", LLONG_MAX); /* (C99) */
   printf("Menor valor para o tipo long long: %lli "
           "(C99)\n", LLONG_MIN); /* (C99) */
   printf("Maior valor para o tipo long: %ld\n",
           LONG_MAX);
   printf("Menor valor para o tipo long: %ld\n",
           LONG_MIN);
   printf("Maior numero de bytes que podem constituir "
          "um caractere multibyte: %d\n", MB_LEN_MAX);
   printf("Maior valor para o tipo signed char: %d\n",
           SCHAR_MAX);
   printf("Menor valor para o tipo signed char: %d\n",
           SCHAR_MIN);
   printf("Maior valor para o tipo short: %d\n",
           SHRT_MAX);
   printf("Menor valor para o tipo short: %d\n",
           SHRT_MIN);
   printf("Maior valor para o tipo unsigned char: %d\n",
           UCHAR_MAX);
   printf("Maior valor para o tipo unsigned int: %u\n",
           UINT_MAX);
   printf("Maior valor para o tipo unsigned long long: "
           "%llu (C99)\n", ULLONG_MAX); /* (C99) */
   printf("Maior valor para o tipo unsigned long: "
           "%lu\n", ULONG_MAX);
   printf("Maior valor para o tipo unsigned short: "
           "%hu\n", USHRT_MAX);

   return 0;
}


