/*************************/
/* Exemplo de uso de div */
/*************************/

#include <stdlib.h>
#include <stdio.h>

int main(void)
{
   int   num = 10, den = 3;
   div_t res = div(10, 3);

   printf( "numerador = %d, denominador =  %d\n",
           num, den );
   printf( "quociente = %d, resto =  %d\n",
           res.quot, res.rem );

   return 0;
}
