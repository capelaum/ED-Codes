/***************************/
/* Exemplo de uso de llabs */
/***************************/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main()
{
     /* Se o valor LLONG_MIN fosse usado, ocorreria  */
     /* overflow pois n�o h� valor do tipo long long */
     /*  que possa conter o resultado. Neste caso, o */
     /* valor retornado por labs() seria LLONG_MIN,  */
     /* que � um valor negativo.                     */
   printf( "Valor absoluto de %lld = %lld\n",
           LLONG_MIN, llabs(LLONG_MIN) );

   return 0;
}

/*

Resultado do programa:

Valor absoluto de -9223372036854775808 = -9223372036854775808

*/
