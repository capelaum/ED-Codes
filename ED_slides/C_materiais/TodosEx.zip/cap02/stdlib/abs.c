/*************************/
/* Exemplo de uso de abs */
/*************************/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   printf("abs(-10) = %d\n", abs(-10));

   return 0;
}
