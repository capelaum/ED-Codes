/**************************/
/* Exemplo de uso de ldiv */
/**************************/

#include <stdlib.h>
#include <stdio.h>

int main ()
{
   int    quantia = -1234;
   char   moeda[] = "R$";
   char   sinal;
   ldiv_t reaisComCentavos;

   if (quantia > 0)
      sinal = '+';
   else if (quantia < 0)
      sinal = '-';
   else
      sinal = ' ';

   reaisComCentavos = ldiv(abs(quantia), 100);

   printf( "\nSeu saldo e' %c%s%ld.%2ld\n",
            sinal, moeda, reaisComCentavos.quot,
            reaisComCentavos.rem );

   return 0;
}

/***
 *
 * Resultado do programa:
 *
 * Seu saldo e' -R$12.34
 *
 ***/
