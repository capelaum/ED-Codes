/**************************/
/* Exemplo de uso de labs */
/**************************/

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int main()
{
      /* Se o valor LONG_MIN for usado, ocorrer� */
      /* overflow pois n�o h� valor do tipo long */
      /* int que possa conter o resultado. Neste */
      /* caso, o valor retornado por labs() ser� */
      /* LONG_MIN, que � um valor negativo.      */
   printf( "Valor absoluto de %ld = %ld\n",
           LONG_MIN + 1, labs(LONG_MIN + 1) );

   return 0;
}

/*

Resultado do programa:

Valor absoluto de -2147483647 = 2147483647

*/
