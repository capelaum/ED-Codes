/*******************************/
/* Exemplo de uso de strtoumax */
/*******************************/

#include <inttypes.h>
#include <stdio.h>
#include <errno.h>

int main(void)
{
   intmax_t  umIntMax;
   char     *string = "123487866480098445567abc",
            *resto;

   umIntMax = strtoumax(string, &resto, 0);

   printf("String original: \"%s\"\n", string);
   printf( "\nValor convertido para intmax_t: %"
           PRIuMAX "\n", umIntMax );
   printf( "\nResto do string original que nao "
           "foi convertido: \"%s\"\n", resto);

   if (errno == ERANGE)
      printf("\nO valor convertido e' grande demais\n");

   return 0;
}

/*

Resultado do programa no Linux:

String original: "123487866480098445567abc"

Valor convertido para intmax_t: 18446744073709551615

Resto do string original que nao foi convertido: "abc"

O valor convertido e' grande demais

*/


