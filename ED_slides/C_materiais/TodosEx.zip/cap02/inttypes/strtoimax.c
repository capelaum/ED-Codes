/*******************************/
/* Exemplo de uso de strtoimax */
/*******************************/

#include <inttypes.h>
#include <stdio.h>
#include <errno.h>

int main(void)
{
   intmax_t umIntMax = 0;
   char    *string = "-123487866480098445567abc",
           *resto;

   umIntMax = strtoimax(string, &resto, 0);

   printf("String original: \"%s\"\n", string);
   printf("\nValor convertido para intmax_t: %"
          PRIdMAX "\n", umIntMax);
   printf("\nResto do string original que nao foi "
          "convertido: \"%s\"\n", resto);

   if (errno == ERANGE)
      printf("\nO valor convertido e' demasiadamente "
             "grande ou pequeno\n");

   return 0;
}

/*

Resultado do programa no Linux:

String original: "-123487866480098445567abc"

Valor convertido para intmax_t: -9223372036854775808

Resto do string original que nao foi convertido: "abc"

O valor convertido e' demasiadamente grande ou pequeno

*/

