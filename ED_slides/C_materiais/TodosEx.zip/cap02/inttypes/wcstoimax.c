/*******************************/
/* Exemplo de uso de wcstoimax */
/*******************************/

#include <stdio.h>
#include <inttypes.h>
#include <wchar.h>

int main()
{
   intmax_t  im;
   wchar_t   *string = L"-1234567abc", *resto;

   im = wcstoimax(string, &resto, 0);

   printf("String original: \"%ls\"\n", string);
   printf( "\nValor convertido para intmax_t: %"
           PRIdMAX "\n", im );
   printf( "\nResto do string original que nao "
           "foi convertido: \"%ls\"\n", resto );

   return 0;
}
/*

Resultado do programa no Linux:

String original: "-1234567abc"

Valor convertido para intmax_t: -1234567

Resto do string original que nao foi convertido: "abc"

*/

