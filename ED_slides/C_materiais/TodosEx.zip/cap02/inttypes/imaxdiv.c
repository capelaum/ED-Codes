/*****************************/
/* Exemplo de uso de imaxdiv */
/*****************************/

#include <inttypes.h>
#include <stdio.h>

int main(void)
{
   intmax_t   numerador = INTMAX_MAX,
              denominador = 5;
   imaxdiv_t  resultado;

   resultado = imaxdiv(numerador, denominador);

   printf("numerador = %" PRIdMAX ", denominador =  %"
          PRIdMAX "\n", numerador, denominador );
   printf("quociente = %" PRIdMAX ", resto =  %"
          PRIdMAX "\n", resultado.quot, resultado.rem);

   return 0;
}

/*

Resultado do programa no Linux:

numerador = 9223372036854775807, denominador =  5
quociente = 1844674407370955161, resto =  2

*/

