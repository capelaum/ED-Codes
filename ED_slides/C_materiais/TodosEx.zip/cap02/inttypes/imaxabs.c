/*****************************/
/* Exemplo de uso de imaxabs */
/*****************************/

#include <inttypes.h>
#include <stdio.h>

int main(void)
{
   intmax_t x = INTMAX_MIN/5;

   printf( "Valor absoluto de %" PRIdMAX ": %" PRIdMAX,
           x, imaxabs(x) );

   putchar('\n');

   return 0;
}

/*

Resultado do programa no Linux:

Valor absoluto de -1844674407370955161: 1844674407370955161

*/

