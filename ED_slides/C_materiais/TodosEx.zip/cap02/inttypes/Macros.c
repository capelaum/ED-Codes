﻿/******************************/
/* Exemplos de uso de macros  */
/* especificadoras de formato */
/******************************/

#include <inttypes.h>
#include <stdio.h>

int main(void)
{
   uint32_t umInt = UINT32_MAX;
   intmax_t outroInt = INTMAX_MIN/5;

        /* Uso incorreto de macro    */
        /* especificadora de formato */
   printf("PRIu32\n", umInt);

        /* Correção da última instrução */
   printf("%" PRIu32 "\n", umInt);

        /* Não é necessário o uso de espaços em  */
        /* branco na última instrução, mas o uso */
        /* destes pode melhorar a legibilidade.  */
   printf("%"PRIu32"\n", umInt);

        /* Outro uso incorreto de macro */
        /* especificadora de formato    */
   printf("Valor de outroInt = %PRIdMAX\n", outroInt);

        /* Correção da última instrução */
   printf( "Valor de outroInt = %" PRIdMAX "\n",
           outroInt );

   return 0;
}

/*

O compilador gcc emite a seguinte mensagem:

Macros.c:28: warning: unknown conversion type character ‘P’ in format

********************************************

Resultado do programa no Linux:

PRIu32
4294967295
4294967295
Valor de outroInt = %PRIdMAX
Valor de outroInt = -1844674407370955161

*/

