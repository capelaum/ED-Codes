/*******************************/
/* Exemplo de uso de wcstoumax */
/*******************************/

#include <stdio.h>
#include <inttypes.h>
#include <wchar.h>

int main()
{
   uintmax_t  uim;
   wchar_t    *string = L"1234567abc", *resto;

   uim = wcstoumax(string, &resto, 0);

   printf("String original: \"%ls\"\n", string);
   printf( "\nValor convertido para uintmax_t: %"
           PRIuMAX "\n", uim );
   printf( "\nResto do string original que nao "
           "foi convertido: \"%ls\"\n", resto );

   return 0;
}
/*

Resultado do programa no Linux:

String original: "1234567abc"

Valor convertido para uintmax_t: 1234567

Resto do string original que nao foi convertido: "abc"

*/

