/*****************************/
/* Exemplo de uso de wcsncat */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t destino[80] = L"Isto e'";
   wchar_t *origem = L" um teste apenas.";

   printf("String original: \n\t \"%ls\"\n", destino);
   printf( "\nString que contem os caracteres "
           "a ser concatenados: "
           "\n\t \"%ls\"\n", origem );

   wcsncat(destino, origem, 9);

   printf( "\nString original apos a concatenacao "
           "usando wcsncat(destino, origem, 9): "
           "\n\t \"%ls\"\n", destino );

   return 0;
}

