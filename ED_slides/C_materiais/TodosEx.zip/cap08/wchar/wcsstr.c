/****************************/
/* Exemplo de uso de wcsstr */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   wchar_t *strExt1 = L"Apenas um string extenso";
   wchar_t *strExt2 = L"str";
   wchar_t *pResultado;

   pResultado = wcsstr(strExt1, strExt2);

   if (pResultado)
      printf( "A primeira ocorrencia de \"%ls\" em "
              "\"%ls\" comeca em: \n\t \"%ls\"\n",
              strExt2, strExt1, pResultado );
   else
      printf("O string \"%ls\" nao ocorre em \"%ls\"\n",
             strExt2, strExt1);

   return 0;
}
