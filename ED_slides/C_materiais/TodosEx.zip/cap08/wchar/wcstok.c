/****************************/
/* Exemplo de uso de wcstok */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t string[] = L"Este e' um string com 7 tokens.";
   wchar_t separadores[] = L" .";
   wchar_t *token, *p;
   int     i = 0;

   printf( "O string a ser separado em tokens e': "
           "\n\t\"%ls\"\n", string) ;

   printf("\nOs tokens sao:\n\n");

   token = wcstok(string, separadores, &p);

   while (token) {
      printf("\tToken %d: \"%ls\"\n", ++i, token);
      token = wcstok(NULL, separadores, &p);
   }

   printf( "\n\nString original alterado por wcstok():"
           " \n\t\"%ls\"\n", string );

   return 0;
}
/*

Resultado do programa:

O string a ser separado em tokens e':
	"Este e' um string com 7 tokens."

Os tokens sao:

	Token 1: "Este"
	Token 2: "e'"
	Token 3: "um"
	Token 4: "string"
	Token 5: "com"
	Token 6: "7"
	Token 7: "tokens"


String original alterado por wcstok():
	"Este"

*/
