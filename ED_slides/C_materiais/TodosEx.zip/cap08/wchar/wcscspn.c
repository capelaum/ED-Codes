/*****************************/
/* Exemplo de uso de wcscspn */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t  *strExt1 = L"Isto e' um teste";
   wchar_t  *strExt2 = L"AHbe";
   size_t    intersecao;

   intersecao = wcscspn(strExt1, strExt2);

   printf( "Os strings \"%ls\" e \"%ls\" se "
           "interceptam no caractere '%lc'\n",
           strExt1, strExt2, strExt1[intersecao]);

   return 0;
}
