/***************************/
/* Exemplo de uso de btowc */
/***************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#define MAIOR_CARACTERE   255
#define PORTUGUES_BRASIL "pt_BR.utf8" /* Linux */

int main(void)
{
   wint_t ce;   /* Armazena um caractere extenso */
   int    cmb;  /* Armazena um caractere multibyte */

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   for (cmb = 0; cmb <= MAIOR_CARACTERE; ++cmb) {
      ce = btowc(cmb);

      if (ce == WEOF)
         printf( "%#04x nao e' um caractere multibyte "
                 "de um byte valido\n", cmb );
      else
         printf( "Caractere extenso correspondente a "
                 "%#04x: %#06x\n", cmb, ce );
   }

   ce = btowc(EOF);

   printf("O caractere multibyte e' EOF.\n");
   printf( "Representacao do caractere extenso WEOF: "
           "%#06x\n", ce );

   return 0;
}
