/****************************/
/* Exemplo de uso de wcsspn */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   wchar_t  *str1 = L"ABCDEFGHIJH";
   wchar_t  *str2 = L"DCFAB";
   size_t   posicao;

   posicao = wcsspn(str1, str2);

   printf( "\nPrimeiro caractere de '%ls' que "
           "nao esta em '%ls': %c\n",
		   str1, str2, str1[posicao] );

   return 0;
}
