/***************************/
/* Exemplo de uso de wctob */
/***************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#define PORTUGUES_BRASIL "pt_BR.utf8"

int main(void)
{
   wint_t cExtenso1 = L'U',
          cExtenso2 = L'\u00E3'; /* '�' */

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }


   printf( "'%lc' %spode ser representado por "
           "um caractere multibyte de um byte\n",
           cExtenso1,
           wctob(cExtenso1) != EOF ? "" : "NAO " );

   printf( "'%lc' %spode ser representado por "
           "um caractere multibyte de um byte\n",
           cExtenso2,
           wctob(cExtenso2) != EOF ? "" : "NAO " );

   return 0;
}

/*

Resultado do programa:

'U' pode ser representado por um caractere multibyte de um byte
'�' NAO pode ser representado por um caractere multibyte de um byte

*/

