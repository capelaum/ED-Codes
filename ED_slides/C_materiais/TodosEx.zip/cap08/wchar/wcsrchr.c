/*****************************/
/* Exemplo de uso de wcsrchr */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t *str = L"Apenas um string extenso";
   wchar_t c = L's';

   printf( "O restante de \"%ls\" comecando com a "
           "ultima \nocorrencia do caractere \'%lc\'"
           " e' \"%ls\"", str, c, wcsrchr(str, c) );

   return 0;
}

