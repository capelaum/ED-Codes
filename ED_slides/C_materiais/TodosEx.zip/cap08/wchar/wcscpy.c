/*****************************/
/* Exemplo de uso de wcscpy */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t destino[80];

   wcscpy(destino, L"Um string extenso");
   printf("Resultado da copia: \"%ls\"\n", destino);

   return 0;
}

