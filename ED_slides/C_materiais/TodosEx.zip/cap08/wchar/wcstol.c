/****************************/
/* Exemplo de uso de wcstol */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   long    li;
   wchar_t *string = L"-1234567abc",
           *resto;

   li = wcstol(string, &resto, 0);

   printf("String original: \"%ls\"\n", string);
   printf( "\nValor convertido para long int: %ld\n",
           li );
   printf( "\nResto do string original que nao foi "
           "convertido: \"%ls\"\n", resto );

   return 0;
}

