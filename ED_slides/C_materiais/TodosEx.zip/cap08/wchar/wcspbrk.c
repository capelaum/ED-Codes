/*****************************/
/* Exemplo de uso de wcspbrk */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t *strExt1 = L"Apenas um string";
   wchar_t *strExt2 = L"Teste";
   wchar_t *pOcorrencia;

   pOcorrencia = wcspbrk(strExt1, strExt2);

   if (pOcorrencia)
      printf( "Dentre os caracteres em \"%ls\", \n'%lc'"
              " e' o primeiro caractere a aparecer em "
              "\n\"%ls\"\n", strExt2, *pOcorrencia,
              strExt1 );
   else
      printf("Nao existe caractere em \"%ls\" que "
             "apareca em \"%ls\"\n", strExt2, strExt1);

   return 0;
}

