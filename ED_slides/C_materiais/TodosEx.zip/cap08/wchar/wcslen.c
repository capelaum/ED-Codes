/******************************/
/* Exemplo de uso de wcslen() */
/******************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   FILE     *stream;
   wchar_t   strExtenso[] = L"Isto e' um teste.";
   wchar_t   arExtenso[80];
   wchar_t  *retorno;

      /*Abre arquivo para leitura e escrita */
   if(!(stream = fopen("Arq1.txt", "w+"))) {
      fprintf(stderr, "Arquivo nao pode ser aberto");
      return 1;
   }

           /* Escreve string extenso no arquivo */
   fputws(strExtenso, stream);

   rewind(stream); /* Volta ao in�cio do arquivo */

         /* Tenta ler string extenso no arquivo */
   retorno = fgetws( arExtenso, wcslen(strExtenso) + 1,
                     stream );

   if (!retorno) {
      fprintf( stderr,
               "Ocorreu um erro durante a leitura\n" );
      return 1;
   }

   wprintf(L"\nString lido no arquivo: %ls", arExtenso);
   wprintf( L"\nTamanho do string lido: %d\n",
            wcslen(arExtenso) );

   fclose(stream);

   return 0;
}
