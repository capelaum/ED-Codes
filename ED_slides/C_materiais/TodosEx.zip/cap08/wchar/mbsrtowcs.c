/*******************************/
/* Exemplo de uso de mbsrtowcs */
/*******************************/

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>
#include <string.h>

#define TAMANHO        100
#define LOCALIDADE_BR  "pt_BR.utf8"

int main(void)
{
   char        strMB1[] = "Cora\u00E7\u00E3o"; /* "Cora��o" */
   char        strMB2[] = "A\u00E7\u00E3o"; /* "A��o" */
   const char  *pmbs1 = strMB1;
   const char  *pmbs2 = strMB2;
   mbstate_t   estado1, estado2;
   wchar_t     strExtenso1[TAMANHO],
               strExtenso2[TAMANHO];

      /* Inicia estados de convers�o */
   memset(&estado1, 0, sizeof(estado1));
   memset(&estado2, 0, sizeof(estado2));

   if (!setlocale(LC_ALL, LOCALIDADE_BR)) {
      printf("Nao foi possivel alterar localidade.\n");
      return EXIT_FAILURE;
   }

   mbsrtowcs(strExtenso1, &pmbs1, TAMANHO, &estado1);
   mbsrtowcs(strExtenso2, &pmbs2, TAMANHO, &estado2);

   printf( "\nPrimeiro string extenso: \"%ls\"",
           strExtenso1 );
   printf( "\nSegundo string extenso: \"%ls\"\n",
           strExtenso2);

   return EXIT_SUCCESS;
}
/*

Resultado do programa:

Primeiro string extenso: "Cora��o"
Segundo string extenso: "A��o"

*/
