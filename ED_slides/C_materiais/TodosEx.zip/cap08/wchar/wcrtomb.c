/*****************************/
/* Exemplo de uso de wcrtomb */
/*****************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>
#include <stdlib.h>

#define PORTUGUES_BRASIL "pt_BR.utf8" /* Linux */

int main(void)
{
   size_t     n, i;
   mbstate_t  estado;
   char       carMB[MB_CUR_MAX];
   wchar_t    carExtenso = L'\u00c7'; /* '�' */

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

      /* Inicia estado de convers�o */
   memset(&estado, 0, sizeof(estado));

      /* O uso da vari�vel 'estado' neste caso */
      /* n�o � necess�rio. Pode-se chamar a    */
      /* wcrtomb() simplesmente assim:         */
      /* n = wcrtomb(carMB, carExtenso, NULL); */

   n = wcrtomb(carMB, carExtenso, &estado);

   if (n != (size_t)-1) {
      printf("\nCaractere extenso: '%lc'",carExtenso);
      printf( "\nBytes no caractere multibyte "
              "convertido: " );
      for (i = 0; i < n; ++i)
         printf("%#x ", (unsigned char) *carMB++);
         putchar('\n');
   } else
      printf("O caractere extenso e' invalido.\n");

   return 0;
}

/*

Resultado do programa:

Caractere extenso: '�'
Bytes no caratere multibyte convertido: 0xc3 0x87

*/

