/*****************************/
/* Exemplo de uso de wmemcpy */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t s1[80],
           s2[] = L"Apenas um string extenso";

   wmemcpy(s1, s2, 20);

   printf( "\ns2 = %ls \ns1 apos a chamada"
           " wmemcpy(s1, s2, 20) = %ls\n", s2, s1 );

   return 0;
}

