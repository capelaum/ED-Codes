/*****************************/
/* Exemplo de uso de wcscoll */
/*****************************/

#include <wchar.h>
#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

#define PORTUGUES_BRASIL "pt_BR.utf8"
#define TAM_ARRAY(ar) sizeof(ar)/sizeof(ar[0])

/****
 *
 * Fun��o Compara_wcscmp(): fun��o de cola��o baseada em
 *                          wcscmp() que ser� usada com
 *                          qsort()
 *
 * Argumentos: a, b (entrada) - elementos que ser�o
 *                              comparados
 *
 * Retorno: semelhante ao retorno de wcscmp()
 *
 ****/
int Compara_wcscmp(const void *a, const void *b)
{
   return wcscmp(*(wchar_t **)a, *(wchar_t **)b);
}

/****
 *
 * Fun��o Compara_wcscoll(): fun��o de cola��o baseada
 *                           em wcscoll() que ser� usada
 *                           com qsort()
 *
 * Argumentos: a, b (entrada) - elementos que ser�o
 *                              comparados
 *
 * Retorno: semelhante ao retorno de wcscoll()
 *
 ****/
int Compara_wcscoll(const void *a, const void *b)
{
   return wcscoll(*(wchar_t **)a, *(wchar_t **)b);
}

int main(void)
{
   char          *localidade;
   size_t         i, nElementos;
   const wchar_t *garotas[] = {
                                L"M\u00E9rcia",
                                L"Marta",
                                L"M\u00E1rcia",
                                L"Mirtes",
                                L"Marcela",
                                L"\u00C9rica",
                                L"\u00C1lvara",
                              };

   localidade = setlocale(LC_ALL, PORTUGUES_BRASIL);
   if (!localidade) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   printf("\nLocalidade corrente: %s\n", localidade);

   nElementos = TAM_ARRAY(garotas);

   printf("\nLista original: \n\t");
   for (i = 0; i < nElementos; ++i)
      printf("%ls ", garotas[i]);

   qsort( (void *)garotas, nElementos,
          sizeof(garotas[0]), Compara_wcscmp );

   printf("\n\nLista ordenada usando wcscmp():\n\t");
   for (i = 0; i < nElementos; ++i)
      printf("%ls ", garotas[i]);

   qsort( (void *)garotas, nElementos,
          sizeof(garotas[0]), Compara_wcscoll );

   printf("\n\nLista ordenada usando wcscoll():\n\t");
   for (i = 0; i < nElementos; ++i)
      printf("%ls ", garotas[i]);

   putchar('\n');

   return 0;
}

/*

Resultado da execu��o do programa:

Localidade corrente: pt_BR.utf8

Lista original:
	M�rcia Marta M�rcia Mirtes Marcela �rica �lvara

Lista ordenada usando wcscmp():
	Marcela Marta Mirtes M�rcia M�rcia �lvara �rica

Lista ordenada usando wcscoll():
	�lvara �rica Marcela M�rcia Marta M�rcia Mirtes

*/

