/******************************/
/* Exemplo de uso de wcsftime */
/******************************/

#include <stdio.h>
#include <wchar.h>
#include <time.h>
#include <locale.h>

#define MAX 80
#define PT_BR_WIN_XP "Portuguese_Brazil.850"
#define PT_BR_LINUX  "pt_BR.utf8"


int main(void)
{
   struct tm *agora;
   time_t     segundos;
   wchar_t    strExt[MAX];
   char      *local = PT_BR_LINUX;

   if (!setlocale(LC_ALL, local)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   time(&segundos);
   agora = localtime(&segundos);

   wcsftime( strExt, MAX,
             L"Passam %M minutos das %I horas (%z) "
             "%A, %B %d 20%y", agora );

   printf("%ls\n",strExt);

   return 0;
}

/*

Resultado da execu��o do programa no Windows XP:

Passam 22 minutos das 03 horas (Hora oficial do Brasil) sexta-feira, janeiro 16

**********************************************************

Resultado da execu��o do programa no Linux Ubuntu 8.10:

Passam 24 minutos das 03 horas (-0300) sexta, janeiro 16 2009

*/

