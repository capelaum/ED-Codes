/****************************/
/* Exemplo de uso de wcstod */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   double   d;
   wchar_t *str = L"51.2 + alguma coisa",
           *final;

   d = wcstod(str, &final );

   printf( "O string \"%ls\" foi convertido"
           " em %f\n", str, d);
   printf( "O string \"%ls\" nao fez parte "
           "da conversao\n", final );

   return 0;
}

