/*****************************/
/* Exemplo de uso de mbsinit */
/*****************************/

#include <stdio.h>
#include <wchar.h>
#include <stdlib.h>
#include <string.h>

int main(void)
{
   char      *str = "ABC";
   mbstate_t  estado;
   wchar_t    cExtenso;
   int        n;

      /* Inicia estado de convers�o */
   memset(&estado, 0, sizeof(estado));

      /* Converte o primeiro caractere */
      /* multibyte do string           */
   n = mbrtowc(&cExtenso, str, MB_CUR_MAX, &estado);

      /* Verifica se estado corrente de */
      /* convers�o ainda � o inicial    */
   if (mbsinit(&estado))
      printf("Ainda em estado inicial de conversao\n");
   else
      printf("O estado de conversao foi alterado\n");

   return 0;
}

/*

Resultado da executa��o do programa:

Ainda em estado inicial de conversao

*/