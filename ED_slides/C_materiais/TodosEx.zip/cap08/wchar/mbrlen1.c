/****************************/
/* Exemplo de uso de mbrlen */
/****************************/

#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>
#include <locale.h>

#define LOCALE_BR "pt_BR.utf8" /* Linux */

int main( void )
{
   size_t     nCar = 0, comp = 0;
   mbstate_t  estado;
   char       *localidade, *aux;
   const char *str = "A vida s\u00F3 pode ser entendida"
                     " olhando-se para tr\u00E1s, mas "
                     "s\u00F3 pode ser vivida olhando-"
                     "se para a frente. (An\u00F4nimo)";

   localidade = setlocale(LC_ALL, LOCALE_BR);

   if (!localidade)
      printf("Nao foi possivel alterar a localidade.");

      /* Inicia estado de convers�o */
   memset(&estado, 0, sizeof(estado));

   aux = str;

   while ((comp = mbrlen(str, MB_CUR_MAX, &estado)) != 0
           && comp != (size_t)-1 && comp != (size_t)-2
           && comp != (size_t)-3) {
      str += comp;
      nCar++;
   }

   printf("%s\nComprimento do string: %d\n", aux, nCar);

   return 0;
}

/*

Resultado do programa:

A vida s� pode ser entendida olhando-se para tr�s, mas s� pode ser vivida olhando-se para a frente. (An�nimo)
Comprimento do string: 109

*/
