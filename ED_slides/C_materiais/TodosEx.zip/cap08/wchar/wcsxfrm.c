/*****************************/
/* Exemplo de uso de wcsxfrm */
/*****************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>

      /* Linux */
/* #define PORTUGUES_BRASIL "pt_BR.utf8" */
      /* Windows XP */
#define PORTUGUES_BRASIL "Portuguese_Brazil.850"

int main()
{
   wchar_t   *origem1 = L"M\u00E1rcia";
   wchar_t   *origem2 = L"Mirtes";
   wchar_t   destino1[40];
   wchar_t   destino2[40];
   int       comparacao;

   /***** Usando localidade padr�o "C" *****/

   if (!setlocale(LC_ALL, "C")) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   printf("\nUsando a localidade padrao \"C\":\n\t");

   comparacao = wcscmp(origem1, origem2);

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   printf( "O string \"%ls\" %s o string \"%ls\"\n",
           origem1,
           (comparacao <= 0) ? "precede" : "sucede",
           origem2 );

   /**** Usando localidade Portugu�s do Brasil ****/

   printf( "\nUsando a localidade \"%s\":\n\t",
           PORTUGUES_BRASIL );

   wcsxfrm(destino1, origem1, wcslen(origem1));
   wcsxfrm(destino2, origem2, wcslen(origem2));

   comparacao = wcscmp(destino1, destino2);

   printf( "O string \"%ls\" %s o string \"%ls\"\n\n",
           origem1,
           (comparacao <= 0) ? "precede" : "sucede",
           origem2 );

   return 0;
}

/*

Resultado do programa executado no Windows XP:

Usando a localidade padrao "C":
        O string "M�rcia" sucede o string "Mirtes"

Usando a localidade "Portuguese_Brazil.850":
        O string "M�rcia" precede o string "Mirtes"

*/