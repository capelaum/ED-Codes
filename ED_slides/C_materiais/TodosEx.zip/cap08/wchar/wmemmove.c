/******************************/
/* Exemplo de uso de wmemmove */
/******************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t s[] = L"Apenas um string extenso";

   printf( "String ANTES da chamada de wmemmove "
           "= %ls\n", s);
   printf( "\nString DEPOIS da chamada de wmemmove "
           "= %ls\n", wmemmove(s, s + 5, 10 ) );

   return 0;
}

