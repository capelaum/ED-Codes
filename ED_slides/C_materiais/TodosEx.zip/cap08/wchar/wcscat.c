/****************************/
/* Exemplo de uso de wcscat */
/****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t destino[80] = L"Isto e' ";
   wchar_t *origem = L"apenas um teste.";

   printf("String original: \n\t \"%ls\"\n", destino);
   printf( "\nString que contem os caracteres a ser"
           " concatenados: \n\t \"%ls\"\n", origem);

   wcscat(destino, origem);

   printf( "\nString original apos a concatenacao "
           "usando wcscat(destino, origem): \n\t "
           "\"%ls\"\n", destino );

   return 0;
}

