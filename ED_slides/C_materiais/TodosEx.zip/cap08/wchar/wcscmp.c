/****************************/
/* Exemplo de uso de wcscmp */
/****************************/

#include <wchar.h>
#include <stdio.h>

int main(void)
{
   wchar_t strExt1[] = L"Isto e' um teste";
   wchar_t strExt2[] = L"Isto nao e' um teste";
   int     comparacao;

   comparacao = wcscmp(strExt1, strExt2);

   if (comparacao < 0)
      printf( "\"%ls\" e' menor do \"%ls\"\n",
              strExt1, strExt2 );
   else if (comparacao > 0)
      printf( "\"%ls\" e' maior do \"%ls\"\n",
              strExt1, strExt2 );
   else
      printf("Os strings sao iguais\n");

   return 0;
}
