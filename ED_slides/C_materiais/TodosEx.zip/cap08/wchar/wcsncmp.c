/*****************************/
/* Exemplo de uso de wcsncmp */
/*****************************/

#include <wchar.h>
#include <stdio.h>

int main(void)
{
   wchar_t string1[] = L"Isto e' um teste";
   wchar_t string2[] = L"Isto e' um teste tambem";
   int     comparacao;

   comparacao = wcsncmp(string1, string2, 5);

   printf("Usando wcsncmp(string1, string2, 5):\n");

   if (comparacao < 0)
      printf( "\"%ls\" e' menor do \"%ls\"\n",
              string1, string2 );
   else if (comparacao > 0)
      printf( "\"%ls\" e' maior do \"%ls\"\n",
              string1, string2 );
   else
      printf("Os strings sao iguais\n");

   comparacao = wcsncmp(string1, string2, 18);

   printf("\nUsando wcsncmp(string1, string2, 18):\n");

   if (comparacao < 0)
      printf( "\"%ls\" e' menor do \"%ls\"\n",
              string1, string2 );
   else if (comparacao > 0)
      printf( "\"%ls\" e' maior do \"%ls\"\n",
              string1, string2 );
   else
      printf("Os strings sao iguais\n");

   return 0;
}
