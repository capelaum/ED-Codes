/*****************************/
/* Exemplo de uso de wmemcmp */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t s1[] = L"ABCDEFG",
           s2[] = L"ABCDXYZ";

   printf(" s1 = %ls\n s2 = %ls\n wmemcmp(s1, s2, 4) = "
          "%d\n wmemcmp(s1, s2, 7) = %d\n", s1, s2,
          wmemcmp(s1, s2, 4), wmemcmp(s1, s2, 7));

   return 0;
}

/*

Resultado do programa executado no Windows XP:

s1 = ABCDEFG
s2 = ABCDXYZ
wmemcmp(s1, s2, 4) = 0
wmemcmp(s1, s2, 7) = -19

*/
