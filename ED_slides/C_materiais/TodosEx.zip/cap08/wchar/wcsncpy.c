/*****************************/
/* Exemplo de uso de wcsncpy */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t destino[80];

   wcsncpy(destino, L"Pequeno", 10);
   printf( "String destino apos chamada de "
           "wcsncpy(destino, L\"Pequeno\", 10):"
           "\n\t \"%ls\"\n", destino );

   wcsncpy(destino, L"Um string grande", 10);

   printf("String destino apos chamada de "
          "wcsncpy(destino, L\"Um string grande\", 10):"
          "\n\t \"%ls\"\n", destino);

   return 0;
}

