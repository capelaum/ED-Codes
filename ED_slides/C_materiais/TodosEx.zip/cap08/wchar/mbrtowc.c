#include <stdio.h>
#include <wchar.h>
#include <stdlib.h>
#include <locale.h>
#include <string.h>
#include <wctype.h>

#define PORTUGUES_BRASIL "pt_BR.utf8"

/****
 *
 * Fun��o StrMBParaExtenso(): retorna um string extenso
 *                            equivalente a um dado
 *                            string multibyte em
 *                            mai�sculas
 *
 * Argumentos: s (entrada) - o string multibyte a ser
 *                           convertido
 *
 * Retorno: ponteiro para o string convertido,
 *          se for poss�vel a convers�o; NULL,
 *          em caso contr�rio
 *
 ****/

wchar_t *StrMBParaExtenso(const char *s)
{
   size_t    nc; /* N�mero de caracteres resultantes */
   wchar_t  *strExtenso, *p, tmp;
   mbstate_t estado;
   size_t    nBytes;

      /* Na pior hip�tese, o n�mero de caracteres  */
      /* extensos ser� igual ao n�mero de bytes no */
      /* string multibyte (i.e., cada caractere    */
      /* multibyte ocupa exatamente um byte).      */
   nc = strlen(s);
   strExtenso = malloc ((nc + 1)*sizeof(wchar_t));

      /* Inicial o estado de convers�o */
   memset(&estado, '\0', sizeof (estado));

      /* Guarda o in�cio do string extenso */
   p = strExtenso;

   while ((nBytes = mbrtowc(&tmp, s, nc, &estado)) > 0){
      if (nBytes >= (size_t)-2) /* Caractere inv�lido */
         return NULL;

      *strExtenso++ = towupper(tmp);
      nc -= nBytes;
      s += nBytes;
   }

   *strExtenso++ = L'\0'; /* Termina o string extenso */

      /* p aponta para o in�cio do string convertido */
   return p;
}

int main()
{
   wchar_t *strExtenso;
   char    *strMB = "A\u00E7\u00E3o"; /* "A��o" */

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   wprintf(L"\nString multibyte: %s", strMB);

   strExtenso = StrMBParaExtenso(strMB);

   if (strExtenso)
      wprintf( L"\nString extenso convertido: %ls\n",
               strExtenso );
   else
      wprintf(L"\nNao foi possivel converter string\n");

   return 0;
}

/*

Resultado da execu��o do programa:

String multibyte: A��o
String extenso convertido: A��O

*/

