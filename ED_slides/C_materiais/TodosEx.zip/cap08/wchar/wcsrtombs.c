/*******************************/
/* Exemplo de uso de wcsrtombs */
/*******************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>
#include <string.h>

#define MAX_BYTES        50
#define PORTUGUES_BRASIL "pt_BR.utf8"

int main(void)
{
   char      strMB[MAX_BYTES];
   wchar_t   *strExt = L"Eu \u2665 JP";
   wchar_t   *p;
   size_t    nBytes;

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   p = strExt; /* Guarda in�cio do string extenso */

   nBytes = wcsrtombs( strMB, (const wchar_t **)&p,
                       MAX_BYTES, NULL );

   printf("\nString extenso original: \"%ls\"", strExt);
   printf("\n%d bytes foram convertidos", nBytes);
   printf("\nO string convertido e': \"%s\"\n", strMB);

   printf("\n-----------------------------------\n");

        /* Reinicia o array strMB */
   memset(strMB, '\0', sizeof(strMB));

      /* O valor de p foi alterado na  */
      /* chamada da fun��o wcsrtombs() */
   p = strExt;

       /* Converte apenas 5 caracteres */
   nBytes = wcsrtombs( strMB, (const wchar_t **)&p,
                       5, NULL);

   printf("\nString extenso original: \"%ls\"", strExt);
   printf("\n%d bytes foram convertidos", nBytes);
   printf("\nO string convertido e': \"%s\"\n", strMB);

   return 0;
}

/*

Resultado do programa:

String extenso original: "Eu ? JP"
9 bytes foram convertidos
O string convertido e': "Eu ? JP"

-----------------------------------

String extenso original: "Eu ? JP"
3 bytes foram convertidos
O string convertido e': "Eu "

*/

