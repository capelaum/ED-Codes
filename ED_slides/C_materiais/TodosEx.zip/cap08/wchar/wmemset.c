/*****************************/
/* Exemplo de uso de wmemset */
/*****************************/

#include <wchar.h>
#include <stdio.h>

int main(void)
{
    wchar_t array[] = L"Isto e' um teste.";

    printf( "Array antes de chamar wmemset(): %ls\n",
            array );

    wmemset(array, L'*', wcslen(array) - 1);

    printf( "Array depois de chamar wmemset(): %ls\n",
            array );

    return 0;
}

