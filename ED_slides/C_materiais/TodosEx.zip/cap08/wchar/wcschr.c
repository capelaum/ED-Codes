﻿/****************************/
/* Exemplo de uso de wcschr */
/****************************/

#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#define PORTUGUES_BRASIL "pt_BR.utf8"

int main()
{
   wchar_t *strExt = L"Cora\u00E7\u00E3o";
   wchar_t cExt = L'a';

   if (!setlocale(LC_ALL, PORTUGUES_BRASIL)) {
      printf("Nao foi possivel alterar a localidade\n");
      return 1;
   }

   printf( "O restante de \"%ls\" comecando com a "
           "primeira ocorrencia de '%lc' é \"%ls\"\n",
           strExt, cExt, wcschr(strExt, cExt) );

   return 0;
}
/*

Resultado do programa:

O restante de "Coração" comecando com a primeira ocorrencia de 'a' é "ação"

*/
