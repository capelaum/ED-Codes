/*****************************/
/* Exemplo de uso de wcstoul */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   unsigned long  ul;
   wchar_t       *string = L"1234567abc",
                 *resto;

   ul = wcstoul(string, &resto, 0);

   printf("String original: \"%ls\"\n", string);
   printf( "\nValor convertido para long int: %ld\n",
           ul );
   printf( "\nResto do string original que nao foi "
           "convertido: \"%ls\"\n", resto );

   return 0;
}
