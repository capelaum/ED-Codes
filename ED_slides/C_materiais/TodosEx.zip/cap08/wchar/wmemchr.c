/*****************************/
/* Exemplo de uso de wmemchr */
/*****************************/

#include <stdio.h>
#include <wchar.h>

int main()
{
   wchar_t *s = L"Apenas um string extenso";

   printf( "O que resta de \"%ls\" a partir do "
           "caractere 'r' e' \"%ls\"", s,
           wmemchr(s, 'r', 16) );

   return 0;
}

