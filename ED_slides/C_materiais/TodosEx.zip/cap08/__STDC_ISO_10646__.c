/**********************************************/
/* Exemplo de uso da macro __STDC_ISO_10646__ */
/**********************************************/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   printf("sizeof(wchar_t) = %u\n", sizeof(wchar_t));

#ifdef __STDC_ISO_10646__
   printf("A macro __STDC_ISO_10646__ e' definida\n");
#else
   printf("A macro __STDC_ISO_10646__ NAO e' definida\n");
#endif

   return 0;
}

/*

***** Resultado do programa no Linux *****

sizeof(wchar_t) = 4
A macro __STDC_ISO_10646__ e' definida


**** Resultado do programa no Windows ****

sizeof(wchar_t) = 2
A macro __STDC_ISO_10646__ NAO e' definida

*/

