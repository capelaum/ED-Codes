/************************************/
/* Exemplo de uso de mblen e wctomb */
/************************************/

#include <locale.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

#define LOCALE_BR "pt_BR.utf8" /* Linux */

int main(void)
{
   char   *localidade;
   char    cm[MB_LEN_MAX + 1];
   wchar_t ce = L'\u263A'; /* White Smiling Face */
   int     n;

   localidade = setlocale(LC_ALL, LOCALE_BR);

   if (!localidade) {
      fprintf( stderr, "Nao foi possivel "
               "alterar a localidade\n" );
      return 1;
   }

   printf("A localidade %s e' %s estado\n", localidade,
          mblen(NULL, MB_CUR_MAX) ? "COM" : "SEM" );

   n = wctomb(cm, ce);
   printf("Numero de caracteres convertidos: %d\n", n);

   n = mblen(cm, MB_CUR_MAX);

      /* Transforma o caractere multibyte num */
      /* string multibyte com um caractere    */
   cm[n] = '\0';

   printf("Caractere multibyte: %s\n", cm);

   printf("Tamanho do caractere multibyte: %d\n", n);

   return 0;
}

/**

Resultado do programa no Linux:

A localidade pt_BR.utf8 e' SEM estado
Numero de caracteres convertidos: 3
Caractere multibyte: ☺ [smilling face]
Tamanho do caractere multibyte: 3

**/

