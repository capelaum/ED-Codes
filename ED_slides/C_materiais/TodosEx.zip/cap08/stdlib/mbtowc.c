/*****************************/
/* Exemplo de uso de mbtowc */
/*****************************/

#include <locale.h>
#include <stdlib.h>
#include <wchar.h>
#include <stdio.h>

#define LOCALE_BR  "pt_BR.utf8" /* Linux */

int main()
{
   char    *localidade;
   wchar_t  carExtenso;
   int      n;

   localidade = setlocale(LC_ALL, LOCALE_BR);

   if (!localidade) {
      wprintf(L"\nNao pude alterar a localidade\n");
      return 1;
   }

   wprintf( L"\nA localidade corrente e': %s",
            localidade);

   wprintf( L"\nA codificacao corrente e' %s estado\n",
            mbtowc(NULL, NULL, 0) ? "com" : "sem");

      /* \u00E7 � '�' em UCN */
   n = mbtowc(&carExtenso, "\u00E7", MB_CUR_MAX);

   if (-1 != n)
      wprintf( L"\nCaractere extenso convertido: %lc\n",
               carExtenso );
   else
      fprintf( stderr, "\nO caractere e' invalido na "
               "localidade corrente\n");

   wprintf(L"\n------------------------------------\n");

   localidade = setlocale(LC_ALL, "C");

   if (!localidade) {
      wprintf(L"\nNao pude alterar a localidade\n");
      return 1;
   }

   wprintf( L"\nA localidade corrente e': %s\n",
            localidade );

   wprintf( L"\nA codificacao corrente e' %s estado\n",
            mbtowc(NULL, NULL, 0) ? "com" : "sem");

      /* \u00E7 � '�' em UCN */
   n = mbtowc(&carExtenso, "\u00E7", MB_CUR_MAX);

   if (-1 != n)
      wprintf( L"\nCaractere extenso convertido: %lc\n",
               carExtenso );
   else
      fprintf( stderr, "\nO caractere e' invalido na "
               "localidade corrente\n");

   return 0;
}

/*

Resultado do programa:

A localidade corrente e': pt_BR.utf8
A codificacao corrente e' sem estado
Caractere extenso convertido: �

------------------------------------

A localidade corrente e': C
A codificacao corrente e' sem estado
O caractere e' invalido na localidade corrente

*/
