#include <locale.h>
#include <stdlib.h>
#include <wchar.h>
#include <stdio.h>

#define LOCALE_BR  "pt_BR.utf8" /* Linux Ubuntu 8.10 */

/****
 *
 * Fun��o MultibyteParaExtenso(): converte um string
 *                               multibyte na localidade
 *                               corrente em caracteres
 *                               extensos
 *
 * Argumentos: str (entrada) - o string multibyte que
 *                             ser� convertido
 *
 * Retorno: ponteiro para o string convertido ou
 *          NULL se a convers�o n�o for poss�vel
 *
 * Nota: O string a ser convertido deve ser compat�vel
 *       com a localidade corrente.
 *
 ****/
wchar_t *MultibyteParaExtenso(char * str)
{
   wchar_t *ptr;
   size_t   nCars;

      /* Usa-se NULL como primeiro argumento */
      /* para calcular o espa�o necess�rio   */
   nCars = mbstowcs(NULL, str, 0);

      /* Se a fun��o mbstowcs() retorna (size_t)-1 */
      /* � porque ocorreu um erro na codifica��o.  */
   if (nCars == (size_t) -1)
      return NULL;

#ifdef TESTE
   wprintf( L"\nNumero de caracteres extensos no "
            "resultado: %d\n", nCars );
#endif

      /* Aloca o espa�o necess�rio. O retorno */
      /* de mbstowcs() n�o inclui o caractere */
      /* terminal L'\0'.                      */
   ptr = malloc((nCars + 1)*sizeof(wchar_t));

   if (!ptr) /* Espa�o n�o foi alocado */
      return NULL;

      /* Copia o resultado da convers�o */
      /* no espa�o alocado              */
   mbstowcs(ptr, str, nCars);

   ptr[nCars] = L'\0'; /* Termina o string extenso */

      /* Deve-se liberar o espa�o apontado por  */
      /* ptr quando ele n�o for mais necess�rio */
   return ptr;
}

int main()
{
   char    *localidade;
   wchar_t *str;

   localidade = setlocale(LC_ALL, LOCALE_BR);

   if (!localidade) {
      wprintf(L"\nNao pude alterar a localidade\n");
      return 1;
   }

   wprintf( L"\nA localidade corrente e': %s",
           localidade );

      /* O string � "A��o" em UCN */
   str = MultibyteParaExtenso("A\u00E7\u00E3o");

   if (str) {
      wprintf(L"String extenso: %ls\n", str);
      free(str);
   } else {
      fprintf( stderr,
               "\nOcorreu um erro de codificacao\n" );
      return 1;
  }

   wprintf(L"\n------------------------------------\n");

   localidade = setlocale(LC_ALL, "C");

   if (!localidade) {
      wprintf(L"\nNao pude alterar a localidade\n");
      return 1;
   }

   wprintf( L"\nA localidade corrente e': %s\n",
            localidade );

      /* O string � "A��o" em UCN */
   str = MultibyteParaExtenso("A\u00E7\u00E3o");

   if (str) {
      wprintf(L"String extenso: %ls\n", str);
      free(str);
   } else {
      fprintf( stderr,
               "Ocorreu um erro de codificacao\n" );
      return 1;
  }


   return 0;
}

/*

Resultado do programa:

A localidade corrente e': pt_BR.utf8
Numero de caracteres extensos no resultado: 4
String extenso: A��o

------------------------------------

A localidade corrente e': C
Ocorreu um erro de codificacao

*/
