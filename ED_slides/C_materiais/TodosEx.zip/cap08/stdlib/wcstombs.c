#include <locale.h>
#include <stdlib.h>
#include <wchar.h>
#include <stdio.h>
#include <string.h>

#define LOCALE_BR "pt_BR.utf8"  /* Linux Ubuntu 8.1 */

/****
 *
 * Fun��o ExtensoParaMultibyte(): converte um string
 *                               extenso num string
 *                               multibyte compat�vel
 *                               com uma dada localidade
 *
 * Argumentos: str (entrada) - o string extenso que ser�
 *                             convertido
 *             local (entrada) - localidade na qual ser�
 *                               feita a convers�o
 *
 * Retorno: ponteiro para o string convertido ou NULL se
 *          a convers�o n�o for poss�vel
 *
 *
 * NOTA: Deve-se liberar o espa�o alocado para conter o
 *       string quando este n�o for mais necess�rio.
 ****/

char *ExtensoParaMultibyte( const wchar_t *str,
                            const char *local )
{
   char   *ptr;
   size_t  s;
   char   *p, *localCorrente, *localidade;

      /* Guarda a localidade corrente */
   p = setlocale(LC_ALL, "");
   localCorrente = malloc(strlen(p) + 1);
   strcpy(localCorrente, p);

      /* Tenta alterar a localidade corrente */
   localidade = setlocale(LC_ALL, local);

   if (!localidade) {
      fprintf( stderr,
               "\nNao pude alterar a localidade\n" );
      free(localCorrente);
      return NULL;
   }

#ifdef TESTE
   printf("\nA localidade corrente e': %s", localidade);
#endif

      /* Usa NULL como primeiro argumento  */
      /* para calcular o espa�o necess�rio */
      /* para conter o string multibyte    */
   s = wcstombs(NULL, str, 0);

      /* Se a fun��o mbstowcs() retorna (size_t) -1 */
      /* significa que h� caracteres que n�o podem  */
      /* ser convertidos para a localidade corrente */
   if (s == -1) {
      fprintf( stderr,
               "\nA conversao nao e' possivel "
               "nesta localidade\n" );
      free(localCorrente);
      return NULL;
   }

      /* Aloca o espa�o necess�rio */
   if (!(ptr = malloc(s + 1))) {
      fprintf( stderr,
               "\nNao foi possivel alocar o espaco "
               "necessario para conter o string\n" );
      free(localCorrente);
      return NULL;
   }

      /* Copia o resultado da        */
      /* convers�o no espa�o alocado */
   wcstombs(ptr, str, s);

   ptr[s] = '\0'; /* Termina o string multibyte */

      /* Restaura a localidade corrente */
   localidade = setlocale(LC_ALL, localCorrente);

   if (!localidade)
      fprintf( stderr,
               "\nNao foi possivel restaurar "
               "a localidade corrente\n" );

   free(localCorrente); /* N�o � mais necess�ria */

#ifdef TESTE
   printf("\nString convertido: %s\n", ptr);
#endif

   return ptr;
}

int main()
{
   char  *localidade;
   char  *str, *p;

   str = ExtensoParaMultibyte(L"Eu\u2665JP", LOCALE_BR);

   if (!str) {
      fprintf(stderr, "Ocorreu um erro de codificacao");
      return 1;
   }

      /* N�o h� problema em usar strlen() com um    */
      /* string multibyte, mas, neste caso, o valor */
      /* retornado � o n�mero de bytes no string e  */
      /* n�o o n�mero de caracteres.                */
   printf( "\nNumero de bytes no string multibyte: "
           "%d\n", strlen(str) );

      /* Imprime cada byte do string multibyte */
      /* em formato hexadecimal                */

   printf("Bytes que compoem o string multibyte: ");

      /* � preciso guardar um ponteiro para */
      /* o in�cio do string para que seja   */
      /* poss�vel liberar o espa�o          */
   p = str;

   while(*str)
      printf("%#x ", (unsigned char)*str++);

   putchar('\n');

   free(p); /* N�o se pode fazer free(str) aqui!!! */

   return 0;
}

/*

Resultado da execu��o do programa

A localidade corrente e': pt_BR.utf8
String convertido: Eu?JP [? = cora��o]

Numero de bytes no string multibyte: 7
Bytes que compoem o string multibyte: 0x45 0x75 0xe2 0x99 0xa5 0x4a 0x50

*/

