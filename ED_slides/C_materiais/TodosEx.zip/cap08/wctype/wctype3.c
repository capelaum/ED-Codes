/********************************************/
/* Exemplo: Influ�ncia da categoria LC_TYPE */
/********************************************/

#include <stdio.h>
#include <wctype.h>
#include <wchar.h>
#include <locale.h>

#define PORTUGUES_BRASIL "pt_BR.utf8" /* Linux */

/****
 *
 * Fun��o EhLetraLocal(): verifica se um caractere
 *                        extenso � uma letra na
 *                        localidade especificada e
 *                        imprime o resultado do teste
 *
 * Argumentos: cExt (entrada) - o caractere que ser�
 *                              testado
 *             localidade (entrada) - a localidade
 *
 * Retorno: Nada
 *
 ****/

void EhLetraLocal(wchar_t cExt, const char *localidade)
{
   char *local;

   local = setlocale(LC_CTYPE, localidade);
   if (!local) {
      printf("\nNao foi possivel alterar a localidade");
      return;
   }

   printf("\nA localidade corrente e': \"%s\"", local);
   printf( "\nNesta localidade, o caractere "
           "%s letra\n",
           iswalpha(cExt) ? "e'" : "nao e'" );
}

int main(void)
{
   wchar_t c = L'\u00E7'; /* O caractere � '�' */

      /* Usa a localidade do sistema */
   EhLetraLocal(c, "");

      /* Usa a localidade portugu�s do Brasil */
   EhLetraLocal(c, PORTUGUES_BRASIL);

      /* Usa a localidade padr�o */
   EhLetraLocal(c, "C");

   return 0;
}

/*

Resultado do programa:

A localidade corrente e': "en_US.UTF-8"
Nesta localidade, o caractere e' letra

A localidade corrente e': "pt_BR.utf8"
Nesta localidade, o caractere e' letra

A localidade corrente e': "C"
Nesta localidade, o caractere nao e' letra

*/
