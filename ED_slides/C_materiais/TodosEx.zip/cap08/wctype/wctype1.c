/*********************************/
/* Exemplo das fun��es iswcntrl, */
/* iswpunct, iswprint e iswgraph */
/*********************************/

#include <stdio.h>
#include <ctype.h>

int main(void)
{
   		/* Uso de iswcntrl() */
   printf("\nO caractere L'\\n' %s caractere de controle\n",
           iswcntrl(L'\n') ? "e'" : "nao e'");
   printf("O caractere L'$' %s caractere de controle\n",
           iswcntrl(L'$') ? "e'" : "nao e'");
   printf("O caractere L'#' %s caractere de controle\n",
           iswcntrl(L'#') ? "e'" : "nao e'");

   		/* Uso de iswpunct() */
   printf("\nO caractere L'?' %s caractere de pontuacao\n",
           iswpunct(L'?') ? "e'" : "nao e'");
   printf("O caractere L'B' %s caractere de pontuacao\n",
           iswpunct(L'B') ? "e'" : "nao e'");
   printf("O caractere L':' %s caractere de pontuacao\n",
           iswpunct(L':') ? "e'" : "nao e'");

   		/* Uso de iswprint() */
   printf("\nO caractere L'\\n' %s caractere imprimivel\n",
           iswprint(L'\n') ? "e'" : "nao e'");
   printf("O caractere L'$' %s caractere imprimivel\n",
           iswprint(L'$') ? "e'" : "nao e'");
   printf("O caractere L'\\a' %s caractere imprimivel\n",
           iswprint(L'\a') ? "e'" : "nao e'");

   		/* Uso de iswgraph() */
   printf("\nO caractere L'\\n' %s caractere grafico\n",
           iswgraph(L'\n') ? "e'" : "nao e'");
   printf("O caractere L'$' %s caractere grafico\n",
           iswgraph(L'$') ? "e'" : "nao e'");
   printf("O caractere L'\\a' %s caractere grafico\n",
           iswgraph(L'\a') ? "e'" : "nao e'");

   return 0;
}

/*

Resultado de execu��o do programa no Windows XP:

O caractere L'\n' e' caractere de controle
O caractere L'$' nao e' caractere de controle
O caractere L'#' nao e' caractere de controle

O caractere L'?' e' caractere de pontuacao
O caractere L'B' nao e' caractere de pontuacao
O caractere L':' e' caractere de pontuacao

O caractere L'\n' nao e' caractere imprimivel
O caractere L'$' e' caractere imprimivel
O caractere L'\a' nao e' caractere imprimivel

O caractere L'\n' nao e' caractere grafico
O caractere L'$' e' caractere grafico
O caractere L'\a' nao e' caractere grafico

*/
