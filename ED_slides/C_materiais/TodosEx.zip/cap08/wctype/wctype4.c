/********************************************/
/* Exemplos das fun��es iswlower, iswupper, */
/*                      towlower e towupper */
/********************************************/

#include <stdio.h>
#include <wctype.h>

int main(void)
{
   		/* Uso de iswlower() */
   printf("\nO caractere L'u' %s minuscula",
           iswlower(L'u') ? "e'" : "nao e'");
   printf("\nO caractere L'L' %s minuscula",
           iswlower(L'L') ? "e'" : "nao e'");
   printf("\nO caractere L'$' %s minuscula",
           iswlower(L'$') ? "e'" : "nao e'");

   		/* Uso de iswupper() */
   printf("\n\nO caractere L'u' %s maiuscula",
           iswupper(L'u') ? "e'" : "nao e'");
   printf("\nO caractere L'L' %s maiuscula",
           iswupper(L'L') ? "e'" : "nao e'");
   printf("\nO caractere L'$' %s maiuscula",
           iswupper(L'$') ? "e'" : "nao e'");

   		/* Uso de towlower() */
   printf("\n\nO caractere L'u' convertido em minuscula"
          " e' %c", towlower(L'u'));
   printf( "\nO caractere L'L' convertido em minuscula"
           " e' %c",towlower(L'L') );
   printf( "\nO caractere L'$' convertido em minuscula"
           " e' %c\n", towlower(L'$') );

   		/* Uso de towupper() */
   printf( "\n\nO caractere L'u' convertido em maiuscula"
           " e' %c", towupper(L'u'));
   printf( "\nO caractere L'L' convertido em maiuscula"
           " e' %c", towupper(L'L'));
   printf( "\nO caractere L'$' convertido em maiuscula"
           " e' %c\n", towupper(L'$'));

   return 0;
}

/*

Resultado do programa:

O caractere L'u' e' minuscula
O caractere L'L' nao e' minuscula
O caractere L'$' nao e' minuscula

O caractere L'u' nao e' maiuscula
O caractere L'L' e' maiuscula
O caractere L'$' nao e' maiuscula

O caractere L'u' convertido em minuscula e' u
O caractere L'L' convertido em minuscula e' l
O caractere L'$' convertido em minuscula e' $


O caractere L'u' convertido em maiuscula e' U
O caractere L'L' convertido em maiuscula e' L
O caractere L'$' convertido em maiuscula e' $

*/
