/*********************************************/
/* Exemplos das fun��es iswdigit, iswalpha,  */
/*                      iswalnum e iswxdigit */
/*********************************************/

#include <stdio.h>
#include <wctype.h>

int main(void)
{
   		/* Uso de iswdigit() */
   printf("O caractere L'5' %s digito\n",
           iswdigit(L'5') ? "e'" : "nao e'");
   printf("O caractere L'$' %s digito\n",
           iswdigit(L'$') ? "e'" : "nao e'");

   		/* Uso de iswalpha() */
   printf("\nO caractere L'z' %s letra\n",
           iswalpha(L'z') ? "e'" : "nao e'");
   printf("O caractere L'3' %s letra\n",
           iswalpha(L'3') ? "e'" : "nao e'");

   		/* Uso de iswalnum() */
   printf("\nO caractere L'z' %s letra ou digito\n",
           iswalnum(L'z') ? "e'" : "nao e'");
   printf("O caractere L'3' %s letra ou digito\n",
           iswalnum(L'3') ? "e'" : "nao e'");
   printf("O caractere L'@' %s letra ou digito\n",
           iswalnum(L'@') ? "e'" : "nao e'");

   		/* Uso de iswxdigit() */
   printf("\nO caractere L'z' %s digito hexadecimal\n",
           iswxdigit(L'z') ? "e'" : "nao e'");
   printf("O caractere L'3' %s digito hexadecimal\n",
           iswxdigit(L'3') ? "e'" : "nao e'");
   printf("O caractere L'C' %s digito hexadecimal\n",
           iswxdigit(L'C') ? "e'" : "nao e'");

   return 0;
}

/*

Resultado do programa no Win XP:

O caractere L'5' e' digito
O caractere L'$' nao e' digito

O caractere L'z' e' letra
O caractere L'3' nao e' letra

O caractere L'z' e' letra ou digito
O caractere L'3' e' letra ou digito
O caractere L'@' nao e' letra ou digito

O caractere L'z' nao e' digito hexadecimal
O caractere L'3' e' digito hexadecimal
O caractere L'C' e' digito hexadecimal

*/