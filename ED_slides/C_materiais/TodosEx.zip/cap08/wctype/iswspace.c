/********************************/
/* Exemplo da fun��o iswspace() */
/********************************/

#include <stdio.h>
#include <wctype.h>

int main(void)
{

   		/* Uso de iswspace() */
   printf("O caractere L'\\n' %s espaco em branco\n",
          iswspace(L'\n') ? "e'" : "nao e'");
   printf("O caractere L'$' %s espaco em branco\n",
          iswspace(L'$') ? "e'" : "nao e'");
   printf("O caractere L'\\t' %s espaco em branco\n",
          iswspace(L'\t') ? "e'" : "nao e'");
   printf("O caractere L' ' %s espaco em branco\n",
          iswspace(L' ') ? "e'" : "nao e'");

   return 0;
}

/*

Resultado do programa:

O caractere L'\n' e' espaco em branco
O caractere L'$' nao e' espaco em branco
O caractere L'\t' e' espaco em branco
O caractere L' ' e' espaco em branco

*/
