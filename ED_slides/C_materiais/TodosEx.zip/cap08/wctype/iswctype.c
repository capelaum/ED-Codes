/******************************************/
/* Exemplos das fun��es wctype e iswctype */
/******************************************/

#include <stdio.h>
#include <wctype.h>

int main()
{

   printf( "O caractere L'z' %s letra\n",
           iswctype(L'z', wctype("alpha")) ?
           "e'" : "nao e'" );

   printf( "O caractere L'$' %s digito\n",
           iswctype(L'$', wctype("digit")) ?
           "e'" : "nao e'");

   printf( "O caractere L'z' %s letra ou digito\n",
           iswctype(L'z', wctype("alnum")) ?
           "e'" : "nao e'" );

   return 0;
}
