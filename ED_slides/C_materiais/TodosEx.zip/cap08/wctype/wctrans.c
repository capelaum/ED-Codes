/*******************************************/
/* Exemplo das fun��es wctrans e towctrans */
/*******************************************/

#include <stdio.h>
#include <stdlib.h>
#include <wctype.h>
#include <string.h>

int main(void)
{
   char    *alfabeto = "abcdefghijlmnopqrstuvxz";
   wchar_t *strExtenso;
   int     i;
   size_t  tamAlfabeto;

   tamAlfabeto = strlen(alfabeto);

   strExtenso = malloc(sizeof(wchar_t)*(tamAlfabeto+1));

   mbstowcs(strExtenso, alfabeto, 2*(tamAlfabeto + 1));

   printf("Alfabeto minusculo: %ls\n", strExtenso);

   for (i = 0; i < tamAlfabeto; ++i)
      strExtenso[i] = (wchar_t)towctrans(strExtenso[i],
                                   wctrans("toupper"));

   printf("Alfabeto maiusculo: %ls\n", strExtenso);

   return 0;
}

/*

Resultado do programa:

Alfabeto minusculo: abcdefghijlmnopqrstuvxz
Alfabeto maiusculo: ABCDEFGHIJLMNOPQRSTUVXZ

*/
