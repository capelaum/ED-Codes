/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf c
 *
 ****/

#include <stdio.h>
#include <wchar.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   char    c;
   char    array[5] = {0};
   wchar_t ce;

        /* Exemplos de c */
   sscanf("abc", "%c", &c);
   IMPRIME(c, c);

   sscanf("abc", "%2c", array);
   IMPRIME(array, s);

   swscanf(L"abc", L"%c", &c);
   IMPRIME(c, c);

   sscanf("abc", "%lc", &ce);
   IMPRIME(ce, lc);

   swscanf(L"abc", L"%lc", &ce);
   IMPRIME(ce, lc);

   return 0;
}

/***

Resultado do programa:

Valor de c: a
Valor de array: ab
Valor de c: a
Valor de ce: a
Valor de ce: a

***/
