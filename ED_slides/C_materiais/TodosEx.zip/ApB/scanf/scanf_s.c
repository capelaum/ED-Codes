/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf s
 *
 ****/

#include <stdio.h>
#include <wchar.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   char    s[10];
   wchar_t se[10];

        /* Exemplos de s */
   sscanf("abcdef", "%s", s);
   IMPRIME(s, s);

   sscanf("abcdef", "%3s", s);
   IMPRIME(s, s);

   sscanf("abcdef", "%ls", se);    /* Armazena L"abcdef" */
   IMPRIME(se, ls);

   swscanf(L"abcdef", L"%ls", se); /* Armazena L"abcdef" */
   IMPRIME(se, ls);

   return 0;
}

/***

Resultado do programa:

Valor de s: abcdef
Valor de s: abc
Valor de se: abcdef
Valor de se: abcdef

***/
