/****
 *
 * Exemplos de uso dos especificadores de
 * formato da fam�lia scanf d e i
 *
 ****/

#include <stdio.h>

#define IMPRIME(x) printf("\tValor de %s = %d\n", #x, x)

int main(void)
{
   int x, y, z;

        /* Exemplos de uso de d */
   sscanf("125", "%d", &x);
   sscanf("031", "%d", &y);
   sscanf("0x2a", "%d", &z);

   printf("\nUsando o especificador %%d:\n");
   IMPRIME(x);
   IMPRIME(y);
   IMPRIME(z);

        /* Exemplos de uso de i */
   sscanf("125", "%i", &x);
   sscanf("031", "%i", &y);
   sscanf("0x2a", "%i", &z);

   printf("\nUsando o especificador %%i:\n");
   IMPRIME(x);
   IMPRIME(y);
   IMPRIME(z);

   return 0;
}

/*

Resultado do programa:

Usando o especificador %d:
	Valor de x = 125
	Valor de y = 31
	Valor de z = 0

Usando o especificador %i:
	Valor de x = 125
	Valor de y = 25
	Valor de z = 42

*/
