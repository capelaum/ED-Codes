/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf u
 *
 ****/

#include <stdio.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   unsigned short us;
   unsigned long  ul;
   unsigned int   ui;

        /* Exemplos de uso de u */
   sscanf("-210", "%u", &ui);
   IMPRIME(ui, u);

   sscanf("210", "%2hu", &us);
   IMPRIME(us, hu);

   sscanf("210abc", "%lu", &ul);
   IMPRIME(ul, lu);

   return 0;
}

/***

Resultado do programa:

Valor de ui: 4294967086
Valor de us: 21
Valor de ul: 210

***/
