/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf o
 *
 ****/

#include <stdio.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   short s;
   long  l;
   int   i;

        /* Exemplos de o */
   sscanf("210", "%2o", &i);
   IMPRIME(i, o);

   sscanf("-210", "%ho", &s);
   IMPRIME(s, ho);

   sscanf("219", "%lo", &l);
   IMPRIME(l, lo);

   return 0;
}

/***

Resultado do programa:

Valor de i: 21
Valor de s: 177570
Valor de l: 21

***/
