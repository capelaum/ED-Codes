/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf d
 *
 ****/

#include <stdio.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   short s;
   long  l;
   int   i;

        /* Exemplos de uso de d */
   sscanf("-210", "%3d", &i);
   IMPRIME(i, d);

   sscanf("-210", "%hd", &s);
   IMPRIME(s, hd);

   sscanf("-210abc", "%ld", &l);
   IMPRIME(l, ld);

   return 0;
}

/***

Resultado do programa:

Valor de i = -21
Valor de s = -210
Valor de l = -210

***/
