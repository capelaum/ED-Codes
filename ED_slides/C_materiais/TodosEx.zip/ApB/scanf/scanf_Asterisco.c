/****
 *
 * Exemplos de uso de especificadores de formato
 * da fam�lia scanf usando * (asterisco)
 *
 ****/

#include <stdio.h>

int main(void)
{
   int x = 0, y = 0;

        /* Exemplos de '*' */
    sscanf("-2 25", "%*d %d", &x, &y);
    printf("\nx = %d \t y = %d", x, y);

    sscanf("-2 25", "%d %*d", &x, &y);
    printf("\nx = %d \t y = %d", x, y);

   return 0;
}

/***

Resultado do programa:

x = 25   y = 0
x = -2   y = 0

***/
