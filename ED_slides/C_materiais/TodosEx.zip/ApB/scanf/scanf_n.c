/****
 *
 * Exemplos de uso de especificadores de
 * formato da fam�lia scanf usando n
 *
 ****/

#include <stdio.h>

int main(void)
{
   float f = 0;
   int   caracteresLidos;

        /* Exemplo de uso de n */
   sscanf( "-2 25.3abc", "%*d %f %n", &f,
           &caracteresLidos );
   printf( "\nCaracteres consumidos na leitura: %d",
           caracteresLidos );

   return 0;
}

/***

Resultado do programa:

Caracteres consumidos na leitura: 7

***/
