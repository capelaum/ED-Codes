/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf p
 *
 ****/

#include <stdio.h>

#define IMPRIME(x) printf("Valor de %s = %p\n", #x, x)

int main(void)
{
   long  *p1, *p2;

        /* Exemplos de uso de p */
   sscanf("fa210", "%3p", &p1);
   sscanf("21A-3", "%p", &p2);

   IMPRIME(p1);
   IMPRIME(p2);

   return 0;
}

/***

Resultado do programa:

Valor de p1 = 00000FA2
Valor de p2 = 0000021A

***/
