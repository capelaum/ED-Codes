/****
 *
 * Exemplos de uso dos especificadores
 * de formato da fam�lia scanf x e X
 *
 ****/

#include <stdio.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   short s = 0;
   long  l;
   int   i, i2;

        /* Exemplos de uso de x e X */
   sscanf("fa210", "%3x", &i);
   sscanf("210A", "%hx", &s);
   sscanf("0X2a19", "%lX", &l);
   sscanf("2a19", "%lX", &i2);

   IMPRIME(i, x);
   IMPRIME(s, hx);
   IMPRIME(l, lx);
   IMPRIME(i2, x);

   return 0;
}

/***

Resultado do programa:

Valor de i: fa2
Valor de s: 210a
Valor de l: 2a19
Valor de i2: 2a19

***/
