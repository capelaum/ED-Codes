/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf [...]
 *
 ****/

#include <stdio.h>
#include <wchar.h>

#define IMPRIME(x, f) printf("Valor de %s: %" #f "\n", #x, x)

int main(void)
{
   char    s[10];
   wchar_t se[10];

        /* Exemplos de s */
   sscanf("abcdef", "%[ecab]", s);
   IMPRIME(s, s);

   sscanf("abcdef", "%[^uzec]", s);
   IMPRIME(s, s);

   swscanf(L"abcdef", L"%[ecab]", s);
   IMPRIME(s, s);

   sscanf("abcdef", "%l[ecab]", se);
   IMPRIME(se, ls);

   swscanf(L"abcdef", L"%l[ecab]", se);
   IMPRIME(se, ls);

   return 0;
}

/***

Resultado do programa no Windows XP:

Valor de s: abc
Valor de s: ab
Valor de s: a
Valor de se: abc
Valor de se: abc

***********************************

Resultado do programa no Linux:

Valor de s: abc
Valor de s: ab
Valor de s: abc
Valor de se: abc
Valor de se: abc

***/
