/****
 *
 * Exemplos de uso dos especificadores de
 * formato da fam�lia printf: c e s
 *
 ****/

#include <stdio.h>
#include <wchar.h>

int main(void)
{
   printf("Exemplos de c:\n");
   printf("%-2c\n", 'u');
   printf("<%2c|%-2c>\n", 'x', 'y');
   printf("%2c\n", 'u');
   printf("%lc\n", L'u');

   printf("\n\nExemplos de s:\n");
   printf("%s\n", "Bola");
   printf("%.2s\n", "Bola");
   printf("%ls\n", L"Bola");

   return 0;
}

/***

Resultado do programa no Linux:

Exemplos de c:
u
< x|y >
 u
u

Exemplos de s:
Bola
Bo
Bola

***/
