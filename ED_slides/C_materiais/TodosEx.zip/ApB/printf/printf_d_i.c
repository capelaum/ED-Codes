/****
 *
 * Exemplos de uso dos especificadores
 * de formato da fam�lia printf d e i
 *
 ****/

#include <stdio.h>

int main(void)
{
   printf("Exemplos de d e i:\n");
   printf("%d\n", 25);
   printf("%.4i\n", -25);
   printf("%4.2ld\n", -25L);
   printf(" % 4.2u\n", (size_t)25);

   return 0;
}

/***

Resultado do programa:

Exemplos de d e i:
25
-0025
 -25
   25

***/
