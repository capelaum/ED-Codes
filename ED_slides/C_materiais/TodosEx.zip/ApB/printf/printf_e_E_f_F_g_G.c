/****
 *
 * Exemplos de uso dos especificadores de formato
 * da fam�lia printf: e, E, f, F, g, G
 *
 ****/

#include <stdio.h>

int main(void)
{
   printf("\nExemplos de e & E:\n");
   printf("%e\n", 1.44);
   printf("%E\n", 1.44);
   printf("%-6.2e\n", 1.44);
   printf("%+6.2e\n", 1.44);
   printf("%-6.2e\n", 1.44);
   printf("%-6.2e\n", -1.44);
   printf("% 6.2e\n", 1.44);
   printf("% 6.2e\n", -1.44);
   printf("%#e\n", 1.44);
   printf("%#e\n", -1.44);

   printf("\nExemplos de f e F:\n");
   printf("%f\n", 1.44);
   printf("%F\n", 1.44); /* gcc 3.2 n�o reconhece F */
   printf("%-6.2f\n", 1.44);
   printf("%+6.2f\n", 1.44);
   printf("%-6.2f\n", 1.44);
   printf("%-6.2f\n", -1.44);
   printf("% 6.2f\n", 1.44);
   printf("% 6.2f\n", -1.44);
   printf("%#f\n", 1.44);
   printf("%#f\n", -1.44);

   printf("\nExemplos de g e G:\n");
   printf("%g\n", 1.44);
   printf("%G\n", 1.44);
   printf("%g\n", 0.00000144);
   printf("%6.2LG\n", 144000.0L);
   printf("%-6.2g\n", 1.44);
   printf("%+6.2g\n", 1.44);
   printf("%-6.2g\n", 1.44);
   printf("%-6.2G\n", -1440.0);
   printf("% 6.2g\n", 1.44);
   printf("% 6.2g\n", -1.44);
   printf("%#g\n", 1.44);
   printf("%#G\n", -1.44);

   return 0;
}

/***

Resultado do programa no Linux:

Exemplos de e & E:
1.440000e+00
1.440000E+00
1.44e+00
+1.44e+00
1.44e+00
-1.44e+00
 1.44e+00
-1.44e+00
1.440000e+00
-1.440000e+00

Exemplos de f & F:
1.440000
1.440000
1.44
 +1.44
1.44
-1.44
  1.44
 -1.44
1.440000
-1.440000

Exemplos de g & G:
1.44
1.44
1.44e-06
1.4E+05
1.4
  +1.4
1.4
-1.4E+03
   1.4
  -1.4
1.44000
-1.44000

***/
