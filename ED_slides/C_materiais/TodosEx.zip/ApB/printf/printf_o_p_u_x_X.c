/****
 *
 * Exemplos de uso dos especificadores de formato
 * da fam�lia printf: o, p, x e X
 *
 ****/

#include <stdio.h>

int main(void)
{
   int x;

   printf("Exemplo de p\n");
   printf("%p\n", &x);

   printf("\nExemplos de o\n");
   printf("%o\n", 38);
   printf("%-lo\n", 38L);
   printf("%#o\n", 38);
   printf("%6o\n", 38);

   printf("\nExemplos de x & X\n");
   printf("%x\n", 9204);
   printf("%-lX\n", 9204L);
   printf("%#x\n", 9204);
   printf("%6x\n", 9204);

   return 0;
}

/***

Resultado do programa:

Exemplo de p
0xbfb56060

Exemplos de o
46
46
046
    46

Exemplos de x & X
23f4
23F4
0x23f4
  23f4

***/
