/****
 *
 * Exemplos de uso de especificadores de formato
 * da fam�lia printf na escrita de NAN e INF
 *
 ****/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double x = 0.0;

      /* Exemplos de escrita de NAN */
   printf("Resultado de sqrt(-2): %f\n", sqrt(-2));
   printf("Resultado de sqrt(-2): %F\n", sqrt(-2));

      /* Exemplos de escrita de INF */
   printf("\nResultado de 1.0/0.0: %f\n", 1.0/x);
   printf("Resultado de 1.0/0.0: %F\n", 1.0/x);

   return 0;
}

/***

Resultado do programa no Linux:

Resultado de sqrt(-2): nan
Resultado de sqrt(-2): NAN

Resultado de 1.0/0.0: inf
Resultado de 1.0/0.0: INF

***/
