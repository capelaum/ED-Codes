/****
 *
 * Exemplos de uso dos especificadores de
 * formato da fam�lia printf: n e %
 *
 ****/

#include <stdio.h>

int main(void)
{
   int nColunasImpressas;

        /* Exemplos de n */
    printf( "String com 24 caracteres%n\n",
            &nColunasImpressas );
    printf( "Numero de caracteres impressos: %d\n",
            nColunasImpressas );

        /*            Exemplo de %             */
        /* Quanto s�mbolos '%' ser�o impresso? */
        /* Resposta: a metade!                 */
    printf("%%%%%%%%%%");

   return 0;
}

/***

Resultado do programa:

String com 24 caracteres
Numero de caracteres impressos: 24
%%%%%

***/
