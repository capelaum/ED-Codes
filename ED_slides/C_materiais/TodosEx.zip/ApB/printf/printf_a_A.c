/****
 *
 * Exemplos de uso dos especificadores de
 * formato da fam�lia printf: a e A
 *
 ****/

#include <stdio.h>

int main(void)
{
        /* Exemplos de a e A (C99) */
   printf("Exemplo de a: %a\n", 1.44);
   printf("Exemplo de A: %A\n", 1.44);
   printf("%a", 30.0);
   printf("%.2A", 30.0);

   return 0;
}

/***

Resultado do programa no Linux:

Exemplo de a: 0x1.70a3d70a3d70ap+0
Exemplo de A: 0X1.70A3D70A3D70AP+0

***/
