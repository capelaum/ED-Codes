/****
 *
 * Exemplos de uso do especificador de
 * formato da fam�lia scanf [...]
 *
 ****/

#include <stdio.h>

int main(void)
{
   int   i;
   float x;
   char  nome[50];

        /* Exemplos de [caracteres] */
   sscanf( "56789 0123 56a72", "%2d%f%*d %[0123456789]",
           &i, &x, nome );

   printf("\ni = %d\tx = %f\tnome = \"%s\"\n", i, x, nome);

   return 0;
}

/***
 *
 *  Resultado do programa:
 *
 *  i = 56  x = 789.000000  nome = "56"
 *
 ***/
