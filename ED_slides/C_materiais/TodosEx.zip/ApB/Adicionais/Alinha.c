/***
 * �s vezes, o preenchimento com espa�os ou zeros provido
 * por printf() n�o � suficiente. Por exemplo, em algumas
 * aplica��es financeiras,  � necess�rio o preenchimento
 * de espa�os de tamanhos arbitr�rios com caracteres
 * espec�ficos (e.g., o uso de asteriscos em preenchimento
 * de cheques). O programa a seguir apresenta uma fun��o
 * que alinha um string � esquerda, direita ou centro
 * e preenche o espa�o restante com um caractere recebido
 * como par�metro.
 *
 ***/

#include <string.h>
#include <stdio.h>

#define TAMANHO   30
#define MIN(x, y) ((x) <= (y) ? (x) : (y))

typedef enum {ESQUERDA, CENTRO, DIREITA} tAlinhamento;

/****
 *
 * Fun��o Alinha(): alinha um string � esquerda, direita ou
 *                  ao centro preenchendo espa�os com um
 *                  caractere passado como par�metro
 *
 * Argumentos: ar (sa�da) - array que conter� o string alinhado
 *             largura (entrada) - tamanho do array
 *             preenchimento (entrada) - caractere usado no
 *                                       preenchimento do
 *                                       espa�o restante
 *             alinhamento (entrada) - o tipo de alinhamento
 *             str (entrada) - o string que ser� alinhado
 *
 * Retorno: ponteiro para o in�cio do array contendo o
 *          resultado da opera��o
 *
 * Nota: Se o comprimento do string for maior do que o
 *       tamanho do array, o string ser� truncado.
 *
 ****/

char *Alinha( char ar[], int largura, char preenchimento,
              tAlinhamento alinhamento, const char *str )
{
   char *p;
   int   menorLargura = MIN(largura, strlen(str));

      /* Preenche todo o array com o */
      /* caractere de preenchimento  */
   memset(ar, preenchimento, largura);
   ar[largura - 1] = '\0'; /* Torna o array num string */

      /* Determina o �ndice inicial */
      /* do string dentro do array  */
   if (alinhamento == ESQUERDA)
      p = ar;
   else if (alinhamento == CENTRO)
      p = ar + (largura - menorLargura)/2;
   else /* alinhamento == DIREITA */
      p = ar + largura - menorLargura - 1;

      /* Insere o string em sua posi��o */
   memcpy(p, str, menorLargura);

   return ar;
}

int main(void)
{
   char  ar[TAMANHO];
   char *str = "Um string";

   printf("\nString original: \"%s\"\n", str);

   (void) Alinha(ar, TAMANHO, '*', ESQUERDA, str);
   printf("\nString alinhado a esquerda:\n\"%s\"\n", ar);

   (void) Alinha(ar, TAMANHO, '*', DIREITA, str);
   printf("\nString alinhado a direita:\n\"%s\"\n", ar);

   (void) Alinha(ar, TAMANHO, '*', CENTRO, str);
   printf("\nString centralizado:\n\"%s\"\n", ar);

   return 0;
}

/*

Exemplo de execu��o do programa:

String original: "Um string"

String alinhado a esquerda:
"Um string********************"

String alinhado a direita:
"********************Um string"

String centralizado:
"**********Um string**********"

*/
