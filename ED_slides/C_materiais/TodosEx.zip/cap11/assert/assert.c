/*********************************************/
/* Exemplo de uso das macros assert e NDEBUG */
/*********************************************/

   /* Se o coment�rio a seguir for removido, */
   /* a macro assert n�o ter� nenhum efeito  */

/* #define NDEBUG */
#include <assert.h>

int main()
{
   int x = -10;

   assert(x > 0);

   return 0;
}
