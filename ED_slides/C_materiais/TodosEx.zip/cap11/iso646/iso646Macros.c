/*****************************/
/* Exemplo de uso de macros  */
/* definidas em <iso646.h>   */
/*****************************/

#include <stdio.h>
#include <iso646.h>

int main()
{
   int x = -1, y = 7, z = -3;

   if (x < 10 && !y || z)
      printf("A condicao foi satisfeita\n");
   else
      printf("A condicao NAO foi satisfeita\n");

      /* A condi��o do if a seguir tem a mesma    */
      /* interpreta��o da condi��o do if anterior */
   if (x < 10 and not y or z)
      printf("A condicao foi satisfeita\n");
   else
      printf("A condicao NAO foi satisfeita\n");

   return 0;
}
