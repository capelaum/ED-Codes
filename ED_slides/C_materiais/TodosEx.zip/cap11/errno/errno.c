/*******************************************/
/* Exemplo de uso da vari�vel global errno */
/* e da macro EDOM definida em <errno.h>   */
/*******************************************/

#include <stdio.h>
#include <math.h>
#include <errno.h>

int main()
{
   double x = 1.5, y = 0.5, z;

      /* Aqui, n�o � necess�rio zerar  */
      /* a vari�vel errno, mas � bom   */
      /* adquirir o h�bito de fazer    */
      /* isto para n�o esquecer quando */
      /* for realmente necess�rio      */
   errno = 0;

      /* A fun��o acos() atribui o valor   */
      /* EDOM � vari�vel global errno se   */
      /* o valor do argumento estiver fora */
      /* do intervalo [-1, 1]              */
   z = acos(x);

   if (errno == EDOM)
      printf( "O valor %f esta' fora do intervalo"
              " valido de acos()\n", x );
   else
      printf("Valor de acos(%f): %f\n", x, z);

      /* Aqui, � estritamente necess�rio   */
      /* zerar a vari�vel errno. Caso      */
      /* contr�rio, ela poder� continuar   */
      /* com o valor que lhe foi atribu�do */
      /* na chamada anterior de acos().    */
   errno = 0;

   z = acos(y);

   if (errno == EDOM)
      printf( "O valor %f esta' fora do intervalo"
              " valido de acos()\n", y );
   else
      printf("Valor de acos(%f): %f\n", y, z);

   return 0;
}
