/****
 *
 * Este programa mascara a ocorr�ncia de uma tentativa
 * de acesso � mem�ria. (� �til para enganar professores
 * que n�o t�m bom dom�nio de tratamento de sinais).
 *
 * CUIDADO: Em sistemas operacionais da fam�lia Windows
 *          voc� pode ter dificuldade para encerrar este
 *          programa. Em sistemas da fam�lia Unix,
 *          basta digitar CTRL-\ para encerr�-lo.
 *
 ****/

#include <stdio.h>
#include <signal.h>
#include <string.h>

/****
 *
 * Fun��o TrataSIGINT(): impede que o programa seja
 *                       encerrado com CTRL-C
 *
 * Argumentos: sinal (entrada) - o sinal recebido
 *                               (i.e., SIGINT)
 *
 * Retorno: Nada
 *
 ****/
void TrataSIGINT(int sinal)
{
   signal(SIGINT, TrataSIGINT);

   while(1)
      ; /* Vazio */
}

/****
 *
 * Fun��o TrataSIGSEGV(): "faz de conta" que existe um
 *                       problema com o servidor de rede
 *
 * Argumentos: sinal (entrada) - o sinal recebido
 *                               (i.e., SIGSEGV)
 *
 * Retorno: Nada
 *
 ****/
void TrataSIGSEGV(int sinal)
{
   signal(SIGINT, TrataSIGINT);

   fprintf( stderr,
            "O servidor nao esta' respondendo."
            " Tentando novamente...\n" );

   while(1)
      ; /* Vazio */
}

int main(void)
{
   char *s = NULL;

   signal(SIGSEGV, TrataSIGSEGV);

      /* A instru��o seguinte causa o */
      /* recebimento do sinal SIGSEGV */
   strcpy(s, "Bola");

   return 0;
}
