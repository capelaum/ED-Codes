/******************************/
/* Exemplo de uso de signal() */
/******************************/

# include <stdio.h>
# include <stdlib.h>
# include <signal.h>
# include <ctype.h>

void TrataSIGFPE(int sig)
{
   fprintf(stderr, "\nO programa tentou executar "
                   "uma operacao aritmetica ilegal"
                   " e sera' abortado. Tchau.\n");

   exit(1); /* � o melhor a fazer nesses casos */
}

void TrataSIGSEGV(int sig)
{
   fprintf(stderr, "\nO programa tentou um acesso"
                   " ilegal de memoria e sera' "
                   "abortado. Tchau.\n");

   exit(1); /* � o melhor a fazer nesses casos */
}

void TrataSIGILL(int sig)
{
   fprintf(stderr, "\nO programa tentou executar uma "
                   "operacao ilegal e sera' abortado."
                   " Tchau.\n");

   exit(1); /* � o melhor a fazer nesses casos */
}

int main()
{
   const char *const msg = "Nao foi possivel instalar "
                           "um tratador de sinal";
   int   c;
   float x;
   char *p = NULL;
   unsigned char ar[4] = {0xff, 0xff, 0xff, 0xff};

      /* O ponteiro de fun��o F definido a seguir */
      /* aponta para uma instru��o ilegal         */
      /* (0xFFFFFFFF) processadores Pentium       */
   void (*F)() = (void (*)())ar;

   if (signal(SIGFPE, TrataSIGFPE) == SIG_ERR) {
      perror(msg);
      return 1;
   }

   if (signal(SIGSEGV, TrataSIGSEGV) == SIG_ERR) {
      perror(msg);
      return 1;
   }

   if (signal(SIGILL, TrataSIGILL) == SIG_ERR) {
      perror(msg);
      return 1;
   }

   printf( "\nEscolha o tipo de sinal que deseja que"
           " o programa receba:\n" );
   printf( "\t1. Acesso ilegal de memoria.\n"
           "\t2. Operacao aritmetica ilegal.\n"
           "\t3. Operacao ilegal (inexistente).\n" );
   printf("\nSua opcao: ");

   while((c = getchar()) != '1' && c != '2' && c != '3')
      getchar(); /* Melhor: LimpaBuffer() [v. Vol I] */

   if ('1' == c)
      *p = 5; /* O ponteiro p � NULL. Portanto */
              /* esta instru��o causar� uma    */
              /* tentativa de acesso ilegal    */
              /* de mem�ria.                   */
   else if ('2' == c)
      c = 10 / 0; /* Evidentemente, esta �  */
                  /* uma �pera��o de ponto- */
                  /* flutuante ilegal.      */
   else
      F(); /* Esta fun��o aponta para uma     */
           /* instru��o ilegal (inexistente). */

   return 0;
}

