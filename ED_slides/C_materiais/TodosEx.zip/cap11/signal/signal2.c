/****
 *
 * O programa a seguir demonstra o uso de signal()
 * e da implementa��o de uma fun��o para tratar o
 * sinal SIGINT
 *
 ****/

#include <signal.h>
#include <stdio.h>

/****
 *
 * Fun��o TrataSIGINT(): trata o sinais do tipo SIGINT
 *
 * Argumentos: sinal (entrada) - o valor SIGINT
 *
 * Retorno: Nada
 *
 ****/

void TrataSIGINT(int sinal)
{
   printf( "Voce acaba de digitar CTRL-C."
           " Aguarde um pouco mais.\n" );

      /* � preciso reinstalar o tratador de sinal */
   signal(SIGINT, TrataSIGINT);
}

int main(void)
{
   int i, j;

   printf( "Realizando uma longa e inutil operacao."
           " Experimente digitar CTRL-C.\n\n" );

   signal(SIGINT, TrataSIGINT);

      /* Este � apenas um la�o relativamente  */
      /* demorado para manter o programa em   */
      /* execu��o enquanto os sinais s�o      */
      /* testados. Dependendo do computador   */
      /* utilizado deve-se ajustar os valores */
      /* de modo que o tempo gasto n�o seja   */
      /* longo ou curto demais.               */
   for (i = 0; i < 5000; i++)
      for (j = 0; j < 1000000; j++);

   return 0;
}
