/****
 *
 * Exemplo de uso de signal() e raise()
 *
 * Este programa demonstra o uso de uma �nica fun��o
 * para tratamento  de v�rios tipos de sinais
 *
 ****/

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <limits.h>

void LimpaBuffer(void);
char LeOpcao(int min, int max);
void TrataSinais(int sinal);

   /* A vari�vel global a seguir indica  */
   /* se o usu�rio digitou CTRL-C ou n�o */
volatile sig_atomic_t digitouCTRLC = 0;

int main(void)
{
   int x, opcao, i = ULONG_MAX;

      /* Pode-se, obviamente, instalar uma fun��o */
      /* para cada sinal, mas aqui apenas uma     */
      /* fun��o � usada para v�rios sinais        */
   signal( SIGABRT, TrataSinais );
   signal( SIGFPE, TrataSinais );
   signal( SIGINT, TrataSinais );
   signal( SIGSEGV, TrataSinais );
   signal( SIGTERM, TrataSinais );

   while(1) {
      printf( "\nOpcoes:\n\n"
              "\t0:Sai do programa\n"
              "\t1:Testa sinal SIGABRT\n"
              "\t2:Testa sinal SIGFPE\n"
              "\t3:Testa sinal SIGINT\n"
              "\t4:Testa sinal SIGSEGV\n"
              "\t5:Testa sinal SIGTERM\n" );

      opcao = LeOpcao('0', '5');

      switch( opcao ) {
         case '0':
            return 0;
         case '1':
            abort();
            break;
         case '2':
            x = 10/0;
            break;
         case '3':
               digitouCTRLC = 0;
               printf( "\nDigite CTRL-C para causar"
                       " uma interrupcao\n" );
               /* D� um tempo para o usu�rio */
               /*digitar CTRL-C              */
            while (i--)
               if (digitouCTRLC)
                  break;

            if (!digitouCTRLC) {
               printf( "\nVoce nao digitou CTRL-C. "
                       "O programa gerara' o sinal "
                       "correspondente.\n" );
               raise(SIGINT);
            }
            break;
         case '4':
           	printf("\nSimulacao de tentativa de acesso "
                   "ilegal a memoria usando raise().");
           	raise(SIGSEGV);
            break;
         case '5':
           	printf("\nSimulacao de solicitacao do SO "
                   "para terminar o programa usando
                   raise().");
           	raise(SIGTERM);
            break;
      } /* switch */
   } /* while */

   return 0;
}

/****
 * Fun��o LimpaBuffer(): L� e descarta caracteres
 *                       encontrados na entrada padr�o
 * Argumentos: Nenhum
 * Retorno: Nada
 ****/
void LimpaBuffer(void)
{
  int c;

  while( (c = fgetc(stdin)) != EOF && c != '\n' )
    ; /* Corpo Vazio */
}

/****
 * Fun��o LeOpcao(): L� e valida a op��o digitada
 *                   pelo usu�rio
 * Argumentos: min (entrada) - o menor valor que o
 *                             usu�rio deve digitar
 *             max (entrada) - o maior valor que o
 *                             usu�rio deve digitar
 * Retorno: A op��o escolhida pelo usu�rio
 ****/
char LeOpcao(int min, int max)
{
   int op;

   while (1) {
      printf("\nDigite sua opcao: ");
      op =  getchar();

      if (op >= min && op <= max) {
         LimpaBuffer();
         break;
      } else {
         printf("\nOpcao invalida. Tente novamente.\n");
         LimpaBuffer();
      }
   }

   return op;
}

/****
 * Fun��o TrataSinais(): trata diversos tipos de
 *                       sinais recebidos pelo programa
 * Argumentos: sinal (entrada) - o sinal recebido
 *                               pelo programa
 * Retorno: Nada
 ****/
void TrataSinais(int sinal)
{
   int opcao = 0;

   printf("\n\nFuncao de tratamento de sinais:");

   switch( sinal ) {
      case SIGABRT:
       	printf( "\n\tSinal de termino anormal recebido."
       	        "\n\tO programa sera encerrado quando "
       	        "esta funcao retornar.\n\tDigite uma "
       	        "tecla para encerrar o programa." );
        getchar();
        break;
      case SIGFPE:
       	printf( "\n\tSinal de operacao aritmetica "
       	        "invalida recebido.\n\tSe esta funcao "
       	        "retornar o programa entrara em loop "
       	        "infinito.\n\tEste tipo de erro e' "
       	        "irrecuperavel. Portanto, o programa "
       	        "\n\tsera' abortado quando voce "
       	        "digitar ENTER" );
       	getchar();
       	exit(1); /* Sem esta instru��o o   */
        break;   /* programa entra em loop */
      case SIGINT:
       	printf( "\n\tSinal de interrupcao "
       	        "[CTRL-C] recebido.\n" );
       	digitouCTRLC = 1;
        break;

      case SIGSEGV:
       	printf( "\n\tSinal de tentativa de acesso "
                "ilegal a memoria recebido.\n" );
        break;
      case SIGTERM:
       	printf( "\n\tSinal de solicitacao do SO para "
       	        "encerrar o programa recebido.\n" );
        break;
   }

        /* � necess�rio reinstalar a fun��o de   */
        /* tratamento de sinal; caso contr�rio,  */
        /* da pr�xima vez que surgir este sinal, */
        /* SIG_DFL ser� chamada.                 */
   signal(sinal, TrataSinais);
}
