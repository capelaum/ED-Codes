/*****************************/
/* Exemplo de uso de macros  */
/* definidas em <stdbool.h>  */
/*****************************/

#include <stdio.h>
#include <stdbool.h>

   /* Se seu compilador n�o suporta esta           */
   /* caracter�stica de C99 ou se o coment�rio     */
   /* da linha a seguir for removido, o trecho     */
   /* de programa correspondente a #else ser�      */
   /* compilado. Caso contr�rio, o trecho de       */
   /* programa correspondente a #if ser� compilada */

/* #undef __bool_true_false_are_defined */
int main()
{
   int  x = -1, y = 7;

#if __bool_true_false_are_defined

   bool teste = false;

   printf("Usando macros definidas em <stdbool.h>.\n");

   if (x < y)
      teste = true;

#else

   _Bool teste = 0;

   printf( "Macros definidas em <stdbool.h>"
           " NAO sao usadas.\n" );

   if (x < y)
      teste = 1;

#endif

   return 0;
}
