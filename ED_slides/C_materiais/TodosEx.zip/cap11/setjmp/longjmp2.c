/***
 *
 * Exemplo de uso de setjmp() e longjmp()
 *
 * O programa a seguir ser� provavelmente abortado
 * porque a fun��o F1() que chama setjmp() retorna
 * antes da chamada correspondente de longjmp()
 *
 ***/

#include <setjmp.h>
#include <stdio.h>

int F1(char *s, jmp_buf estado)
{
   int i;

   i = setjmp(estado);

   printf("F1(): i = %d, s = %s\n", i, s);

   return i;
}

void F2(int j, jmp_buf estado)
{
   printf("F2(): j = %d\n", j);

   longjmp(estado, j);
}

int main()
{
   jmp_buf estado;

   F1("Asa", estado);

   F2(5, estado);

   return 0;
}
