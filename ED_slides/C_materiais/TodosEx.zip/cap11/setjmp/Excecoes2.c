/***
 *
 * Este programa simula o mecanismo de
 * tratamento de exce��es de C++ usando macros
 * e as fun��es setjmp() e longjmp().
 *
 ***/

#include <stdio.h>
#include <setjmp.h>

#define TRY       do{ switch(setjmp(estado)){ case 0:
#define CATCH(e)  break; case e:
#define FIM_TRY   } } while(0)
#define THROW(e)  longjmp(estado, e)

   /* Tipos de exce��es que este programa pode lan�ar */
typedef enum {EX1 = 1, EX2, EX3} tExcecao;

jmp_buf estado; /* Vari�vel global */

   /* Alus�es */
extern void F1(int);
extern void F2(int);
extern void F3(int);

void F1(int x)
{
   printf("\nExecutando F1()");

   if (!x)
      THROW(EX1);
   else if (x < 0)
      THROW(EX2);

   F2(x);
}

void F2(int x)
{
   printf("\nExecutando F2()");

   F3(x);
}

void F3(int x)
{
   printf("\nExecutando F3()");

   if (x < 10)
      THROW(EX3);
}

int main(int argc, char** argv)
{
   TRY
   {
      printf("\nDentro do bloco try");
      F1(5);
   }
   CATCH(EX1)
   {
      printf("\nExcecao EX1 capturada\n");
   }
   CATCH(EX2)
   {
      printf("\nExcecao EX2 capturada\n");
   }
   CATCH(EX3)
   {
      printf("\nExcecao EX3 capturada\n");
   }
   FIM_TRY;

   return 0;
}
