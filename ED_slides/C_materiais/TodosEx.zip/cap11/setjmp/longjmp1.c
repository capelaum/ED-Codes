/**************************************/
/* Exemplo de uso de longjmp e setjmp */
/**************************************/

#include <stdio.h>
#include <setjmp.h>
#include <stdlib.h>

/****
 *
 * Esta fun��o serve apenas para
 * demonstrar o uso de longjmp()
 *
 ****/

void UmaFuncao(jmp_buf status)
{
      /* Se o valor do segundo argumento for        */
      /* trocado por zero, o resultado ser� o mesmo */
   longjmp(status, 1);

      /* Se fosse uma fun��o convencional, */
      /* longjmp() retornaria neste ponto. */
   printf("\nEsta mensagem nunca sera' impressa\n");
}

int main(void)
{
   int     retorno;
   jmp_buf estado;
   double  umDouble = 10.5;

      /* Quando setjmp() � chamada diretamente, */
      /* ela sempre retorna zero.               */

      /* Tanto setjmp() quanto setjmp()    */
      /* retornam neste ponto do programa. */
   retorno = setjmp(estado);

   printf("Esta mensagem sera' impressa duas vezes\n");

   if (retorno) { /* setjmp() retornou indiretamente */
                  /* por meio de longjmp().          */
      printf( "longjmp() retornou com valor %d\n",
              retorno );

         /* Aqui, o valor da vari�vel umDouble */
         /* � indefinido. Ela deveria ter sido */
         /* definida com volatile.             */
      printf("Valor de umDouble: %f", umDouble);

      return retorno;
   } else /* setjmp() foi diretamente chamada */
      printf( "Valor retornado por setjmp(): %d\n",
              retorno );

   umDouble *= 2.0;
   printf("Valor de umDouble: %f", umDouble); /* OK */

   UmaFuncao(estado);

   return 0;
}

/*

Resultado da execu��o do programa no Windows XP:

Esta mensagem sera' impressa duas vezes
Valor retornado por setjmp(): 0
Valor de umDouble: 21.000000
Esta mensagem sera' impressa duas vezes
longjmp() retornou com valor 1
Valor de umDouble: 21.000000

*/
