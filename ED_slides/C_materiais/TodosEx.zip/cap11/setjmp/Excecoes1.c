/***
 *
 * Este programa simula o mecanismo de
 * tratamento de exce��es de C++ usando as
 * fun��es setjmp() e longjmp().
 *
 ***/

#include <stdio.h>
#include <setjmp.h>

   /* Tipos de exce��es que este programa pode lan�ar */
typedef enum {EX1 = 1, EX2, EX3} tExcecao;

jmp_buf estado; /* Vari�vel global */

   /* Alus�es */
extern void F1(int);
extern void F2(int);
extern void F3(int);

void F1(int x)
{
   printf("\nExecutando F1()");

   if (!x)
      longjmp(estado, EX1);
   else if (x < 0)
      longjmp(estado, EX2);

   F2(x);
}

void F2(int x)
{
   printf("\nExecutando F2()");

   F3(x);
}

void F3(int x)
{
   printf("\nExecutando F3()");

   if (x < 10)
      longjmp(estado, EX3);
}

int main(int argc, char** argv)
{
   switch(setjmp(estado)){
      case 0:
         printf("\nDentro do bloco try");
         F1(5);
         break;
      case EX1:
         printf("\nExcecao EX1 capturada\n");
      case EX2:
         printf("\nExcecao EX2 capturada\n");
      case EX3:
         printf("\nExcecao EX3 capturada\n");
   }

   return 0;
}

/*

Resultado do programa:

Dentro do bloco try
Executando F1()
Executando F2()
Executando F3()
Excecao EX3 capturada

*/
