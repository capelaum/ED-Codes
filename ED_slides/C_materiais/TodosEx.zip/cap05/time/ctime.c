#include <stdio.h>
#include <time.h>

int main(void)
{
   time_t  t;

   time(&t);

   printf("Data e hora correntes: %s\n", ctime(&t));

   return 0;
}

/*

Resultado do programa:

Data e hora correntes: Tue Aug 18 19:16:51 2008

*/
