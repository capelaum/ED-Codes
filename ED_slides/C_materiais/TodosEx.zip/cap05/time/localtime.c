/*****************************************/
/* Exemplo de uso de localtime e asctime */
/*****************************************/

#include <time.h>
#include <stdio.h>

int main(void)
{
   time_t hora;
   struct tm *tmHora;

      /* Obt�m a data e a hora atuais */
   hora = time(NULL);

      /* Converte a data e a hora numa estrutura tm */
   tmHora = localtime(&hora);

   printf("Data e hora correntes: %s", asctime(tmHora));

   return 0;
}

