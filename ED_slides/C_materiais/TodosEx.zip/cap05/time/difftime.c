/******************************/
/* Exemplo de uso de difftime */
/******************************/

#include <time.h>
#include <stdio.h>

int main(void)
{
   time_t t0 = time(NULL);
   time_t t1;

   printf( "\nAguarde alguns instantes e depois "
           "digite alguma tecla " );

   getchar();

   t1 = time(NULL);

   printf( "\nVoce aguardou %5.2f segundos\n",
           difftime(t1, t0) );

   return 0;
}

