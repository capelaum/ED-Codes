/********************************/
/* Exemplo de uso de strftime() */
/********************************/

#include <time.h>
#include <stdio.h>

int main()
{
   time_t     agora;
   struct tm *tLocal;
   char       strHora[80] = "";

   time(&agora);
   tLocal = localtime(&agora);

   if (strftime(strHora, 78,
                "Data: %a, %d %b %Y %T %z\n", tLocal))
      printf("\n%s", strHora);
   else
      return 1;

   return 0;
}

/*

Resultado de uma execu��o do programa:

Data: Wed, 27 May 2009  Hora oficial do Brasil

*/
