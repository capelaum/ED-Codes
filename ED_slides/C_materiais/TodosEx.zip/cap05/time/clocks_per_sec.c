/******************************************/
/* Exemplo de uso da macro CLOCKS_PER_SEC */
/******************************************/

#include <stdio.h>
#include <time.h>

int main(void)
{
   clock_t inicio, fim;
   int     n;

      /* Marca o in�cio do tempo */
   inicio = clock();

      /* Pede para o usu�rio introduzir um n�mero */
   printf("Digite um numero inteiro: ");
   scanf("%d",&n);

      /* Encerra a contagem de tempo */
   fim = clock();

   printf( "Voce levou %f s para escrever esse numero\n",
           (double)(fim-inicio)/CLOCKS_PER_SEC );

   return 0;
}

/***

Resultado do programa:

Digite um numero inteiro: 12
Voce levou 4.734000 s para escrever esse numero

***/
