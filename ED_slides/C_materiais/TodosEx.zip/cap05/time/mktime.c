/****************************/
/* Exemplo de uso de mktime */
/****************************/

#include <stdio.h>
#include <time.h>

    /* Macro utilizada para       */
    /* verificar entrada de dados */
#define ASSEGURA( x, msg ) if (!(x) ) {\
                             printf("\n%s", #msg "\n"); \
                             exit(1); \
                           }

char *diaDaSemana[] = {
                        "Domingo", "Segunda", "Terca",
                        "Quarta", "Quinta", "Sexta",
                        "Sabado", "Invalido"
                      };

int main(void)
{
   struct tm t;
   int    ano, mes, dia, teste;

   ano = mes = dia = 0;

      /*  Introduz dia, mes e ano */
   printf("\nAno a partir de 1970: ");
   teste = scanf("%d", &ano);
   ASSEGURA(teste && (ano >= 1970), Entrada incorreta);

   printf("Mes: ");
   teste = scanf("%d", &mes);
   ASSEGURA( teste && (mes >= 1) && (mes <= 12),
             Entrada incorreta);

   printf("Dia: ");
   teste = scanf("%d", &dia);
   ASSEGURA( teste && (dia >= 1) && (dia <= 31),
             Entrada incorreta);

      /*  Preenche a estrutura t com os dados */
   t.tm_year = ano - 1900;
   t.tm_mon  = mes - 1;
   t.tm_mday = dia;
   t.tm_hour = 0;
   t.tm_min  = 0;
   t.tm_sec  = 1;
   t.tm_isdst = -1;

      /* Preenche o dia da semana  */
      /* da estrutura t com mktime */
   if (mktime(&t) == -1)
      t.tm_wday = 7;

      /*  Imprime o dia da semana  */
   printf( "\nO dia da semana e' %s\n",
           diaDaSemana[t.tm_wday] );

   return 0;
}

/*

Exemplo de execu��o do programa:

Ano a partir de 1970: 2007
Mes: 12
Dia: 25

O dia da semana e' Terca

*/
