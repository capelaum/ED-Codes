/********************************************/
/* Exemplo de uso de clock e CLOCKS_PER_SEC */
/********************************************/

#include <stdio.h>
#include <time.h>

void Dorme(double tempoDeSono)
{
    double t1, t0;

    if (tempoDeSono <= 0)
        return;

    t0 = (double) clock() / CLOCKS_PER_SEC;

    printf("O programa esta' dormindo\n");

    do {
        t1 = (double) clock() / CLOCKS_PER_SEC;
        printf("%f\n", t1 - t0); /* Apenas para teste */
    } while ((t1 - t0) < tempoDeSono);
}

int main(void)
{
	double t1, t0 = (double) clock()/CLOCKS_PER_SEC;

	Dorme(4.5); /* Dorme durante 4.5 segundos */

	t1 = (double) clock() / CLOCKS_PER_SEC;

	printf("O programa dormiu %f segundos\n", t1 - t0);

	return 0;
}

/***

Resultado do programa:

O programa dormiu 4.500000 segundos

***/
