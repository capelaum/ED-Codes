/************************************************/
/* Exemplo de uso de time, localtime e strftime */
/************************************************/

#include <stdio.h>
#include <time.h>

int main(void)
{
   struct tm 	*agora;
   time_t 		segundos;
   char 		str[80];

   time(&segundos);
   agora = localtime(&segundos);
   strftime( str, 80,
             "Passam %M minutos das %I horas (%z) "
             "%A, %B %d 20%y", agora );
   printf("%s\n",str);

   strftime(str, 80,"%Ex",agora);

   printf("%s\n",str);

   return 0;
}

/***

Resultado do programa:

Passam 08 minutos das 03 horas (-0300) Wednesday, May 27 2009
05/27/09

***/
