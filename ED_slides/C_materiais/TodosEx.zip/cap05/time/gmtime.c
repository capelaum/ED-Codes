/****************************/
/* Exemplo de uso de gmtime */
/****************************/

#include <stdio.h>
#include <time.h>

int main(void)
{
   time_t t;
   struct tm *gmt, *localT;

   t = time(NULL); /* Obt�m a hora atual */

      /* Obt�m e imprime a data e a */
      /* hora no fuso hor�rio local */
   localT = localtime(&t);
   printf("\nData e hora locais:\t%s", asctime(localT));

      /* Obt�m e imprime a data e a */
      /* hora no fuso hor�rio GMT   */
   gmt = gmtime(&t);
   printf("Data e hora GMT:\t%s", asctime(gmt));

   return 0;
}
