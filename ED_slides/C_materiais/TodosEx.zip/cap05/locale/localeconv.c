#include<locale.h>
#include<stdio.h>
#include<limits.h> /* Define CHAR_MAX */

/****
 *
 * Fun��o ImprimeAgrupamento(): Imprime o conte�do do
 *                              campo grouping ou
 *                              mon_grouping de uma
 *                              estrutura lconv
 *
 * Argumentos: ar (entrada) - array contendo o agrupamento
 *
 * Retorno: Nada
 *
 * Observa��o: Nem sempre o agrupamento (ar) � um string.
 *             Por isso, esta fun��o � necess�ria.
 *
 ****/
void ImprimeAgrupamento(char *ar)
{
   while (*ar != '\0' && *ar != CHAR_MAX)
      printf("%d ", *ar++);

   printf("\n");
}

int main(void)
{
   struct lconv *ptrLocal;
   char         *localidadeCorrente;

   localidadeCorrente = setlocale(LC_ALL, "");

   if (!localidadeCorrente) {
      printf("Erro na chamada da funcao setlocale()");
      return 1;
   }

   printf( "\nA localidade corrente e': %s\n",
           localidadeCorrente );

   ptrLocal = localeconv();

   printf( "\nSeparador de Casa Decimal:     %s\n",
           ptrLocal->decimal_point );
   printf( "Separador de Milhares:           %s\n",
           ptrLocal->thousands_sep );
   printf("Agrupamento de digitos:          ");
   ImprimeAgrupamento(ptrLocal->grouping);

   printf("\n****** Convencoes Monetarias ******\n\n");

   printf( "Simbolo Monetario:                %s\n",
           ptrLocal->currency_symbol  );
   printf( "Simbolo Monetario Internacional:  %s\n",
           ptrLocal->int_curr_symbol);
   printf( "Separador de Casa Decimal:        %s\n",
           ptrLocal->mon_decimal_point );
   printf( "Separador de Milhares:            %s\n",
           ptrLocal->mon_thousands_sep );
   printf("Agrupamento Monetario:            ");
   ImprimeAgrupamento(ptrLocal->mon_grouping);
   printf( "Sinal Positivo:                   %s\n",
           ptrLocal->positive_sign );
   printf( "Sinal Negativo:                   %s\n",
           ptrLocal->negative_sign );
   printf( "Casas Decimais:                   %i\n",
           ptrLocal->frac_digits );
   printf( "Casas Decimais (Internacional):   %i\n",
           ptrLocal->int_frac_digits );
   printf( "Sinal Positivo Precede Valor:     %i\n",
           ptrLocal->p_cs_precedes );
   printf( "Sinal Positivo Separado p espaco: %i\n",
           ptrLocal->p_sep_by_space );
   printf( "Sinal Negativo Precede Valor:     %i\n",
           ptrLocal->n_cs_precedes );
   printf( "Sinal Negativo Separado p espaco: %i\n",
           ptrLocal->n_sep_by_space );
   printf( "Sinal Positivo Posn:              %i\n",
           ptrLocal->p_sign_posn );
   printf( "Sinal Negativo Posn:              %i\n",
           ptrLocal->n_sign_posn );

   return 0;
}

/***

Resultado do programa no Linux:

A localidade corrente e': en_US.UTF-8

Separador de Casa Decimal:     .
Separador de Milhares:           ,
Agrupamento de digitos:          3 3 

****** Convencoes Monetarias ******

Simbolo Monetario:                $
Simbolo Monetario Internacional:  USD 
Separador de Casa Decimal:        .
Separador de Milhares:            ,
Agrupamento Monetario:            3 3 
Sinal Positivo:                   
Sinal Negativo:                   -
Casas Decimais:                   2
Casas Decimais (Internacional):   2
Sinal Positivo Precede Valor:     1
Sinal Positivo Separado p espaco: 0
Sinal Negativo Precede Valor:     1
Sinal Negativo Separado p espaco: 0
Sinal Positivo Posn:              1
Sinal Negativo Posn:              1

***/
