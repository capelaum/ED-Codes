/*******************************/
/* Exemplo de uso de setlocale */
/*******************************/

#include <locale.h>
#include <stdio.h>

#define LINUX_LOCALE "pt_BR.utf8"
#define WIN_LOCALE   "Portuguese_Brazil.850"

int main(void)
{
   char *localidade;

   	      /* Retorna um string que specifica */
   	      /* a localidade corrente           */
   localidade = setlocale(LC_COLLATE, NULL);

   if (localidade)
      printf( "A localidade corrente e': %s\n",
              localidade );

   	      /* Funciona com Linux Ubuntu 8.10 */
   localidade = setlocale(LC_ALL, LINUX_LOCALE);

   if (localidade)
      printf( "A localidade foi alterada para: %s\n",
              localidade );
   else
      printf("Nao foi possivel alterar a localidade\n");

   return 0;
}

/***

Resultado do programa no Linux:

A localidade corrente e': C
A localidade foi alterada para: pt_BR.utf8

***/
