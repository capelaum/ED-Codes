/**************************************************/
/* Exemplo de uso de strftime() com a maioria dos */
/* especificadores de formato de data e hora.     */
/**************************************************/

#include <stdio.h>
#include <time.h>
#include <locale.h>

#define MAX 80

   /* As localidades a seguir funcionam */
   /* no Linux Ubuntu 8.10              */
#define LOCALIDADE_BR "pt_BR.utf8"
#define LOCALIDADE_US "en_US.utf8"

int main(void)
{
   struct tm  *t;
   time_t     segundos;
   char       s[MAX] = {'\0'};
   int        op;
   char       *local;

   printf("Escolha a localidade:\n");
   printf( "\t1 = Brasileira\n\t2 = Americana\n"
           "\tOutro valor = C\n" );
   printf("Sua opcao: ");
   scanf("%d", &op);

   if (op == 1)
      local = setlocale(LC_ALL, LOCALIDADE_BR);
   else if (op == 2)
      local = setlocale(LC_ALL, LOCALIDADE_US);
   else
      local = setlocale(LC_ALL, NULL);

   if (!local) {
      printf("\nNao foi possivel alterar localidade");
      return 1;
   }

   printf("\nA localidade corrente e': %s\n\n", local);

   time(&segundos);
   t = localtime(&segundos);

   strftime(s, MAX, "Usando especificador %%a: %a", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%A: %A", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%b: %b", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%B: %B", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%c: %c", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%C (C99): "
            "%C", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%d: %d", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%D (C99): "
            "%D", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%e (C99): "
            "%e", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%F (C99): "
            "%F", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%g (C99): "
            "%g", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%G (C99): "
            "%G", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%h (C99): "
            "%h", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%H: %H", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%I: %I", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%j: %j", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%m: %m", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%M: %M", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%p: %p", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%r (C99): "
            "%r", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%R (C99): "
            "%R", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%S: %S", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%T (C99): "
            "%T", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%u (C99): "
            "%u", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%U: %U", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%V (C99): "
            "%V", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%w: %w", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%W: %W", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%x: %x", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%X: %X", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%y: %y", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%Y: %Y", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%z (C99): "
            "%z", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%Z: %Z", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%Ec (C99): "
            "%Ec", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%EC (C99): "
            "%EC", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%Er (C99): "
            "%Er", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%Ex (C99): "
            "%Ex", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%EX (C99): "
            "%EX", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%Ey (C99): "
            "%Ey", t);
   printf("%s\n", s);

   strftime(s, MAX, "Usando especificador %%EY (C99): "
            "%EY", t);
   printf("%s\n", s);

   return 0;
}
