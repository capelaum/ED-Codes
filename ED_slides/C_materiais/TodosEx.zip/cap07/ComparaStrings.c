#include <wchar.h>

extern int PesoPrimario(wchar_t ce);
extern int PesoSecundario(wchar_t ce);
extern int PesoTerciario(wchar_t ce);

/****
 *
 * Fun��o ComparaStrings(): compara dois strings
 *                          extensos utilizando
 *                          tr�s n�veis de pesos
 *
 * Argumentos: s1 (entrada) - primeiro string longo
 *                            extenso
 *             s2 (entrada) - segundo string longo
 *                            extenso
 *
 * Retorno: 0, se os strings s�o iguais; -1, se o
 *          primeiro string for menor do que o segundo;
 *          1, se o primeiro string for maior do que
 *          o segundo
 *
 *
 * OBSERVA��O: Sup�e-se a exist�ncia das fun��es
 *             PesoPrimario(), PesoSecundario() e
 *             PesoTerciario() que retornam,
 *             respectivamente, os pesos prim�rio,
 *             secund�rio e terci�rio do caractere
 *             recebido como argumento.
 *
 ****/
int ComparaStrings(const wchar_t* s1, const wchar_t* s2)
{
   int primeiraDiferencaSecundaria = 0;
   int primeiraDiferencaTerciaria = 0;
   int i = 0;
   int comprimento1 = wcslen(s1);
   int comprimento2 = wcslen(s2);

   while (i < comprimento1 && i < comprimento2) {
      if (PesoPrimario(s1[i]) > PesoPrimario(s2[i]))
         return 1;
      if (PesoPrimario(s2[i]) > PesoPrimario(s1[i]))
         return -1;
      if (primeiraDiferencaSecundaria == 0) {
         if ( PesoSecundario(s1[i]) >
              PesoSecundario(s2[i]) )
            primeiraDiferencaSecundaria = 1;
         else if ( PesoSecundario(s2[i]) >
                   PesoSecundario(s1[i]) )
            primeiraDiferencaSecundaria = -1;
         else if (primeiraDiferencaTerciaria == 0) {
            if ( PesoTerciario(s1[i]) >
                 PesoTerciario(s2[i]) )
               primeiraDiferencaTerciaria = 1;
            else if ( PesoTerciario(s2[i]) >
                      PesoTerciario(s1[i]) )
               primeiraDiferencaTerciaria = -1;
         }
      }
      ++i;
   }

   if (comprimento1 > comprimento2)
      return 1;

   if (comprimento2 > comprimento1)
      return -1;

   if (primeiraDiferencaSecundaria != 0)
      return primeiraDiferencaSecundaria;

   return primeiraDiferencaTerciaria;
}
