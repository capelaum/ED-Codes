/****************************************************/
/* Exemplos das fun��es isalnum, isdigit e isxdigit */
/****************************************************/

#include <stdio.h>
#include <ctype.h>

int main()
{
   		/* Uso de isalnum() */
   printf( "\nO caractere 'z' %s letra nem digito\n",
           isalnum('z') ? "e'" : "nao e'" );
   printf( "O caractere '3' %s letra nem digito\n",
           isalnum('3') ? "e'" : "nao e'" );
   printf( "O caractere '@' %s letra nem digito\n",
           isalnum('@') ? "e'" : "nao e'" );

   		/* Uso de isdigit() */
   printf( "\nO caractere '5' %s digito\n",
           isdigit('5') ? "e'" : "nao e'" );
   printf( "O caractere '$' %s digito\n",
           isdigit('$') ? "e'" : "nao e'" );

   		/* Uso de isxdigit() */
   printf( "\nO caractere 'z' %s digito hexadecimal\n",
           isxdigit('z') ? "e'" : "nao e'" );
   printf( "O caractere '3' %s digito hexadecimal\n",
           isxdigit('3') ? "e'" : "nao e'" );
   printf( "O caractere 'C' %s digito hexadecimal\n",
           isxdigit('C') ? "e'" : "nao e'" );

   return 0;
}

/*

Resultado do programa:

O caractere 'z' e' letra nem digito
O caractere '3' e' letra nem digito
O caractere '@' nao e' letra nem digito

O caractere '5' e' digito
O caractere '$' nao e' digito

O caractere 'z' nao e' digito hexadecimal
O caractere '3' e' digito hexadecimal
O caractere 'C' e' digito hexadecimal


*/