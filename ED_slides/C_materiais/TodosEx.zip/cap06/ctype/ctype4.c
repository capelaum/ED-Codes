/*******************************************/
/* Exemplos das fun��es: islower, isupper, */
/*                       tolower e toupper */
/*******************************************/

#include <stdio.h>
#include <ctype.h>

int main()
{
   		/* Uso de islower() */
   printf( "\nO caractere 'u' %s minuscula\n",
           islower('u') ? "e'" : "nao e'" );
   printf( "O caractere 'L' %s minuscula\n",
           islower('L') ? "e'" : "nao e'" );
   printf( "O caractere '$' %s minuscula\n",
           islower('$') ? "e'" : "nao e'" );

   		/* Uso de isupper() */
   printf( "\nO caractere 'u' %s maiuscula\n",
           isupper('u') ? "e'" : "nao e'" );
   printf( "O caractere 'L' %s maiuscula\n",
           isupper('L') ? "e'" : "nao e'" );
   printf( "O caractere '$' %s maiuscula\n",
           isupper('$') ? "e'" : "nao e'" );

   		/* Uso de tolower() */
   printf( "\nO caractere 'u' convertido em minuscula"
           " e' %c\n", tolower('u') );
   printf( "O caractere 'L' convertido em minuscula"
           " e' %c\n", tolower('L') );
   printf( "O caractere '$' convertido em minuscula"
           " e' %c\n", tolower('$') );

   		/* Uso de toupper() */
   printf( "\nO caractere 'u' convertido em maiuscula"
           " e' %c\n", toupper('u') );
   printf( "O caractere 'L' convertido em maiuscula"
           " e' %c\n", toupper('L') );
   printf( "O caractere '$' convertido em maiuscula"
           " e' %c\n", toupper('$') );

   return 0;
}

/*

Resultado do programa:

O caractere 'u' e' minuscula
O caractere 'L' nao e' minuscula
O caractere '$' nao e' minuscula

O caractere 'u' nao e' maiuscula
O caractere 'L' e' maiuscula
O caractere '$' nao e' maiuscula

O caractere 'u' convertido em minuscula e' u
O caractere 'L' convertido em minuscula e' l
O caractere '$' convertido em minuscula e' $

O caractere 'u' convertido em maiuscula e' U
O caractere 'L' convertido em maiuscula e' L
O caractere '$' convertido em maiuscula e' $

*/