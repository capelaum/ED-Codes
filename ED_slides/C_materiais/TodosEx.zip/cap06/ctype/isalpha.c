#include <ctype.h>
#include <locale.h>
#include <stdio.h>

/****
 * Fun��o EhStringAlfabetico(): verifica se um string
 *                              cont�m apenas letras
 *
 * Argumentos: str (entrada) - o string a ser checado
 *
 * Retorno: 1, se o string for alfab�tico;
 *          0, em caso contr�rio
 ****/
int EhStringAlfabetico(const char *str)
{
      /* O la�o while � encerrado quando */
      /* um caractere que n�o � letra    */
      /* � encontrado (inclusive '\0')   */
   while (isalpha(*str++))
      ;

      /* Faz 'str' apontar para o caractere */
      /* que causou o encerramento do la�o  */
   --str;

   return !*str;
}

int main(void)
{
   char  *s = "bola";

   printf( "O string \"%s\" %s alfabetico\n", s,
           EhStringAlfabetico(s) ? "e'" : "nao e'" );

   return 0;
}

/***

Resultado do programa:

O string "bola" e' alfabetico

***/
