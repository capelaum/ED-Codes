/***********************************/
/* Exemplo da fun��o isblank (C99) */
/***********************************/

#include <stdio.h>
#include <ctype.h>

int main(void)
{
   printf("O caractere '\\n' %s espaco em branco\n",
           isblank('\n') ? "e'" : "nao e'");
   printf("O caractere '$' %s espaco em branco\n",
           isblank('$') ? "e'" : "nao e'");
   printf("O caractere '\\t' %s espaco em branco\n",
           isblank('\t') ? "e'" : "nao e'");
   printf("O caractere ' ' %s espaco em branco\n",
           isblank(' ') ? "e'" : "nao e'");

   return 0;
}

/***

Resultado do programa no Libux:

O caractere '\n' nao e' espaco em branco
O caractere '$' nao e' espaco em branco
O caractere '\t' e' espaco em branco
O caractere ' ' e' espaco em branco

***/
