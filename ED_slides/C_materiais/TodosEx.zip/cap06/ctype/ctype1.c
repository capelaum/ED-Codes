/***************************************************/
/* Exemplos das fun��es isgraph, isprint e ispunct */
/***************************************************/

#include <stdio.h>
#include <ctype.h>

int main()
{
   		/* Uso de isgraph() */
   printf( "\nO caractere '\\n' %s caractere grafico\n",
           isgraph('\n') ? "e'" : "nao e'");
   printf( "O caractere '$' %s caractere grafico\n",
           isgraph('$') ? "e'" : "nao e'");
   printf( "O caractere '\\a' %s caractere grafico\n",
           isgraph('\a') ? "e'" : "nao e'");

   		/* Uso de isprint() */
   printf("\nO caractere '\\n' %s caractere imprimivel\n",
          isprint('\n') ? "e'" : "nao e'");
   printf( "O caractere '$' %s caractere imprimivel\n",
           isprint('$') ? "e'" : "nao e'");
   printf( "O caractere '\\a' %s caractere imprimivel\n",
           isprint('\a') ? "e'" : "nao e'");

   		/* Uso de ispunct() */
   printf( "\nO caractere '?' %s caractere de pontuacao\n",
           ispunct('?') ? "e'" : "nao e'");
   printf( "O caractere 'B' %s caractere de pontuacao\n",
           ispunct('B') ? "e'" : "nao e'");
   printf( "O caractere ':' %s caractere de pontuacao\n",
           ispunct(':') ? "e'" : "nao e'");

   return 0;
}

/*

Resultado do programa:

O caractere '\n' nao e' caractere grafico
O caractere '$' e' caractere grafico
O caractere '\a' nao e' caractere grafico

O caractere '\n' nao e' caractere imprimivel
O caractere '$' e' caractere imprimivel
O caractere '\a' nao e' caractere imprimivel

O caractere '?' e' caractere de pontuacao
O caractere 'B' nao e' caractere de pontuacao
O caractere ':' e' caractere de pontuacao

*/
