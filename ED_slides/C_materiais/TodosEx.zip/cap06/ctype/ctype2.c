/******************************************/
/* Exemplos das fun��es iscntrl e isspace */
/******************************************/

#include <stdio.h>
#include <ctype.h>

int main()
{
   		/* Uso de iscntrl() */
   printf("\nO caractere '\\n' %s caractere de "
          "controle\n",iscntrl('\n') ? "e'" : "nao e'");
   printf( "O caractere '$' %s caractere de controle\n",
           iscntrl('$') ? "e'" : "nao e'");
   printf( "O caractere '#' %s caractere de controle\n",
           iscntrl('#') ? "e'" : "nao e'");

   		/* Uso de isspace() */
   printf( "\nO caractere '\\n' %s espaco em branco\n",
           isspace('\n') ? "e'" : "nao e'");
   printf( "O caractere '\\t' %s espaco em branco\n",
           isspace('\t') ? "e'" : "nao e'");
   printf( "O caractere '#' %s espaco em branco\n",
           isspace('#') ? "e'" : "nao e'");

   return 0;
}

/*

Reultado do programa:

O caractere '\n' e' caractere de controle
O caractere '$' nao e' caractere de controle
O caractere '#' nao e' caractere de controle

O caractere '\n' e' espaco em branco
O caractere '\t' e' espaco em branco
O caractere '#' nao e' espaco em branco

*/
