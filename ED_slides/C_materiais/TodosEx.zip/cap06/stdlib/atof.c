/**************************/
/* Exemplo de uso de atof */
/**************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
   char   *str = "2.54cm";
   double  d;

   d = atof(str);

   printf( "Convertendo o string \"%s\" para "
           "double obtem-se: %3.2f\n", str, d );

   return 0;
}

/***

Resultado do programa:

Convertendo o string "2.54cm" para double obtem-se: 2.54

***/
