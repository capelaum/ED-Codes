/**************************************/
/* Exemplo de uso de strtol e strtoul */
/**************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
   long          li;
   unsigned long ul;
   char         *string = "1234567abc", *resto;

   li = strtol(string, &resto, 0);
   ul = strtoul(string, &resto, 0);

   printf( "\nString original: \"%s\"\n", string);
   printf( "\nValor convertido para long int: "
           "%ld\n", li );
   printf( "\nValor convertido para unsigned long: "
           "%lu\n", ul );
   printf( "\nResto do string original que nao "
           "foi convertido: \"%s\"\n", resto );

   return 0;
}

/***

Resultado do programa:

String original: "1234567abc"

Valor convertido para long int: 1234567

Valor convertido para unsigned long: 1234567

Resto do string original que nao foi convertido: "abc"

***/
