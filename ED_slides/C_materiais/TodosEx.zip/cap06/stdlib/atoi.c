/**************************/
/* Exemplo de uso de atoi */
/**************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
   char *str = "1234";
   int   i;

   i = atoi(str);

   printf( "Convertendo o string \"%s\" para int"
           " o resultado e': %d\n", str, i );

   return 0;
}

/***

Resultado do programa:

Convertendo o string "1234" para int o resultado e': 1234

***/
