/**********************************/
/* Exemplo de uso de atol & atoll */
/**********************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
   char     *str = "-92233720368547758";
   long      umLong;
   long long umLongLong;

   umLong = atol("-92233720368547758");
   umLongLong = atoll("-92233720368547758");

   printf( "\nString \"%s\" convertido para long:"
           "\n\t%ld\n", str, umLong );
   printf( "\nString \"%s\" convertido para long long:"
           "\n\t%lld\n\n", str, umLongLong );

   return 0;
}

/*

Resultado do programa quando executado no Linux Ubuntu 8.10:

String "-92233720368547758" convertido para long:
	-2147483648

String "-92233720368547758" convertido para long long:
	-92233720368547758

*/
