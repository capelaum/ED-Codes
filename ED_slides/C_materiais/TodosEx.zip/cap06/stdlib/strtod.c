/****************************/
/* Exemplo de uso de strtod */
/****************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
   double d;
   char   *str = "51.2 + alguma coisa", *final;

   d = strtod(str, &final );

   printf( "O string \"%s\" foi convertido para %f\n",
           str, d );
   printf( "O string \"%s\" NAO fez parte da "
           "conversao\n", final );

   return 0;
}

/***

Resultado do programa:

O string "51.2 + alguma coisa" foi convertido para 51.200000
O string " + alguma coisa" NAO fez parte da conversao

***/
