/*****************************/
/* Exemplo de uso de strxfrm */
/*****************************/

#include <string.h>
#include <stdio.h>
#include <locale.h>

int main(void)
{
   char  str1[] = "Zebra";
   char  str2[] = "abelha";
   char  strColl1[50];
   char  strColl2[50];
   int   comparacao;
   char *localidade;

   printf("\n** Usando a localidade padrao (\"C\") **");

   strxfrm(strColl1, str1, 50);
   strxfrm(strColl2, str2, 50);

   comparacao = strcmp(strColl1, strColl2);

   if (comparacao < 0)
      printf( "\n\"%s\" precede \"%s\"\n",
              str1, str2 );
   else if (comparacao > 0)
      printf( "\n\"%s\" sucede \"%s\"\n",
              str1, str2 );
   else
      printf( "\n\"%s\" e \"%s\" sao iguais\n",
              str1, str2 );

      /* Usa a localidade corrente do SO */
   localidade = setlocale(LC_COLLATE, "");

   if (!localidade) {
      printf("\nNao foi possivel alterar localidade\n");
      return 1;
   }

   printf("\n** Usando a localidade do SO **");

   strxfrm(strColl1, str1, 50);
   strxfrm(strColl2, str2, 50);

   comparacao = strcmp(strColl1, strColl2);

   if (comparacao < 0)
      printf( "\n\"%s\" precede \"%s\"\n",
              str1, str2 );
   else if (comparacao > 0)
      printf( "\n\"%s\" sucede \"%s\"\n",
              str1, str2 );
   else
      printf( "\n\"%s\" e \"%s\" sao iguais\n",
              str1, str2 );

   return 0;
}

/*

Resultado do programa:

** Usando a localidade padrao ("C") **
"Zebra" precede "abelha"

** Usando a localidade do SO **
"Zebra" sucede "abelha"

*/
