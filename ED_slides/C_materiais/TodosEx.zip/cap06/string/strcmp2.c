/****************************/
/* Exemplo de uso de strcmp */
/****************************/

#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

/****
 *
 * Fun��o StringMinusculo(): cria uma c�pia de um
 *                           string substituindo
 *                           letras mai�sculas por
 *                           min�sculas
 *
 * Argumentos: s (entrada) - o string a ser convertido
 *
 * Retorno: c�pia do string recebido como argumento
 *          com letras mai�sculas substitu�das por
 *          min�sculas
 *
 ****/

char *StringMinusculo(const char *s)
{
   char *p = malloc(strlen(s) + 1);
   char *pAux = p;

   if (!p)
      return NULL;

   while (*p++ = tolower(*s++))
      ;

   return pAux;
}

int main(void)
{
   char  str1[] = "Zebra";
   char  str2[] = "abelha";
   char *strMinusculo1, *strMinusculo2;
   int   comparacao;

   strMinusculo1 = StringMinusculo(str1);
   strMinusculo2 = StringMinusculo(str2);

   if (!strMinusculo1 || !strMinusculo2) {
      printf( "\nNao foi possivel criar copias"
              "minusculas dos strings\n" );
      return 1;
   }

   comparacao = strcmp(strMinusculo1, strMinusculo2);

   if (comparacao < 0)
      printf( "\n\"%s\" precede \"%s\"\n",
              str1, str2 );
   else if (comparacao > 0)
      printf( "\n\"%s\" sucede \"%s\"\n",
              str1, str2 );
   else
      printf( "\n\"%s\" e \"%s\" sao iguais\n",
              str1, str2 );

   free(strMinusculo1);
   free(strMinusculo2);

   return 0;
}

/*

Resultado do programa:

"Zebra" sucede "abelha"

*/
