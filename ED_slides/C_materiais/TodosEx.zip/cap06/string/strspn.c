/****************************/
/* Exemplo de uso de strspn */
/****************************/

#include <stdio.h>
#include <string.h>

main()
{
   char *str1 = "ABCDEFGHIJH";
   char *str2 = "DCFAB";
   int   posicao;

   posicao = strspn(str1, str2);

   printf( "\nPrimeiro caractere de \"%s\" que "
           "nao esta em \"%s\": '%c'\n",
		   str1, str2, str1[posicao] );

   return 0;
}

/*

Resultado do programa:

Primeiro caractere de "ABCDEFGHIJH" que nao esta em "DCFAB": 'E'

*/
