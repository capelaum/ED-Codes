/*****************************/
/* Exemplo de uso de strcspn */
/*****************************/

#include <stdio.h>
#include <string.h>

main()
{
   char   *str1 = "Isto e' um teste";
   char   *str2 = "AHuh";
   size_t  intersecao;

   intersecao = strcspn(str1, str2);

   printf( "\nOs strings \"%s\" e \"%s\" se "
           "interceptam no caractere '%c'\n",
           str1, str2, str1[intersecao] );

   return 0;
}

/*

Resultado do programa:


Os strings "Isto e' um teste" e "AHuh" se interceptam no caractere 'u'

*/