/*****************************/
/* Exemplo de uso de strrchr */
/*****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char *str = "Apenas um string";
   char c = 's';

   printf( "\nRestante de \"%s\" comecando com a "
           "ultima \nocorrencia do caractere \'%c\': "
           "\"%s\"\n", str, c, strrchr(str, c) );

   return 0;
}

/*

Resultado do programa:

Restante de "Apenas um string" comecando com a ultima
ocorrencia do caractere 's': "string"

*/