/****************************/
/* Exemplo de uso de strcmp */
/****************************/

#include <string.h>
#include <stdio.h>

int main(void)
{
   char str1[] = "Zebra";
   char str2[] = "abelha";
   int  comparacao;

   comparacao = strcmp(str1, str2);

   if (comparacao < 0)
      printf( "\n\"%s\" precede \"%s\"\n",
              str1, str2 );
   else if (comparacao > 0)
      printf( "\n\"%s\" sucede \"%s\"\n",
              str1, str2 );
   else
      printf( "\n\"%s\" e \"%s\" sao iguais\n",
              str1, str2 );

   return 0;
}

/*

Resultado do programa:

"Zebra" precede "abelha"

*/
