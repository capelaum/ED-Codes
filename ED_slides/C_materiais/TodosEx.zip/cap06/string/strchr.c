/****************************/
/* Exemplo de uso de strchr */
/****************************/

#include <stdio.h>
#include <string.h>

int main(void)
{
   char str[]="Isto e' um teste";

   printf("\nString original: \"%s\"\n", str);
   printf( "String apos a primeira ocorrencia de 'e':"
           "\"%s\"\n", strchr(str,'e') );

   return 0;
}

/*

Resultado do programa:

String original: "Isto e' um teste"
String apos a primeira ocorrencia de 'e':"e' um teste"

*/
