/****************************/
/* Exemplo de uso de memcmp */
/****************************/

#include <stdio.h>
#include <string.h>

typedef struct {
           char nome[30];
           char endereco[20];
           char telefone[10];
} tContato;

int main()
{
   tContato e1 = {"Manoel", "Rua X", "88882424"};
   tContato e2 = {"Manoel", "Rua X", "88882424"};
   tContato e3 = {"Joaquim", "Rua Y", "99994242"};


   printf( "\nAs estruturas 'e1' e 'e2' %ssao iguais\n",
           memcmp(&e1, &e2, sizeof(tContato)) ? "NAO " : "");

   printf( "As estruturas 'e1' e 'e3' %ssao iguais\n",
           memcmp(&e1, &e3, sizeof(tContato)) ? "NAO " : "");

   return 0;
}

/*

Resultado do programa:

As estruturas 'e1' e 'e2' sao iguais
As estruturas 'e1' e 'e3' NAO sao iguais

*/
