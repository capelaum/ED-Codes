/****************************/
/* Exemplo de uso de strstr */
/****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char *str1 = "abcdefabcdef";
   char *str2 = "def";

   printf( "\nPorcao do string \"%s\" comecando"
           "\ncom o string \"%s\": \"%s\"\n",
           str1, str2, strstr(str1, str2) );

   return 0;
}

/*

Resultado do programa:

Porcao do string "abcdefabcdef" comecando
com o string "def": "defabcdef"

*/
