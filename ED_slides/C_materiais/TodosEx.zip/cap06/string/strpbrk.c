/*****************************/
/* Exemplo de uso de strpbrk */
/*****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char *str1 = "Apenas um string";
   char *str2 = "Teste";
   char *ocorrenciaPtr;

   ocorrenciaPtr = strpbrk(str1, str2);

   if (ocorrenciaPtr)
      printf( "\nDentre os caracteres em \"%s\", \'%c\'"
              " e' o primeiro caractere \na aparecer em"
              " \"%s\"\n", str2, *ocorrenciaPtr, str1 );
   else
      printf( "Nao existe caractere em \"%s\" que "
              "apareca em \"%s\"\n", str2, str1 );

   return 0;
}

/*

Resultado do programa:

Dentre os caracteres em "Teste", 'e' e' o primeiro caractere
a aparecer em "Apenas um string"

*/
