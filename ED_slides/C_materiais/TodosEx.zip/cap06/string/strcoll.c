/*****************************/
/* Exemplo de uso de strcoll */
/*****************************/

#include <string.h>
#include <stdio.h>
#include <locale.h>

int main(void)
{
   char  str1[] = "Zebra";
   char  str2[] = "abelha";
   int   comparacao;
   char *localidade;

      /* Usa a localidade corrente */
   localidade = setlocale(LC_COLLATE, "");

   if (!localidade) {
      printf("\nNao foi possivel alterar localidade\n");
      return 1;
   }

   comparacao = strcoll(str1, str2);

   if (comparacao < 0)
      printf( "\n\"%s\" precede \"%s\"\n",
              str1, str2 );
   else if (comparacao > 0)
      printf( "\n\"%s\" sucede \"%s\"\n",
              str1, str2 );
   else
      printf( "\n\"%s\" e \"%s\" sao iguais\n",
              str1, str2 );

   return 0;
}

/*

Resultado do programa:

"Zebra" sucede "abelha"

*/
