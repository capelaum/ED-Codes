#include <string.h>
#include <stdio.h>

/****
 *
 * Fun��o CopiaFinal(): copia os caracteres finais de um
 *                      string
 *
 * Argumentos: copia (sa�da) - array que receber� os
 *                             caracteres copiados
 *             origem (entrada) - string que fornecer�
 *                                os caracteres
 *             nCaracteres (entrada) - no. de caracteres
 *                                    que ser�o copiados
 *
 * Retorno: ponteiro para o in�cio do string 'copia'.
 *
 ****/

char *CopiaFinal( char *copia, const char *origem,
                  int nCaracteres )
{
   const char *ptr = origem;

   if ( nCaracteres <= 0 ) {
      *copia = '\0';
      return copia;
   }

   while ( *ptr++ )
      ; /* VAZIO */

   if (ptr - nCaracteres - 1 > origem)
      origem = ptr - nCaracteres - 1;

   return strcpy(copia, origem);
}

int main()
{
   char  ar[50];
   char  str[] = "String que fornecera caracteres";

   printf("\nString de origem: \"%s\"\n", str);

   printf( "String que recebeu caracteres: \"%s\"\n",
           CopiaFinal(ar, str, 10) );

   return 0;
}

/*

Resultado do programa:

String de origem: "String que fornecera caracteres"
String que recebeu caracteres: "caracteres"

*/