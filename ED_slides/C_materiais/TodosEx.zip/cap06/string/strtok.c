/****************************/
/* Exemplo de uso de strtok */
/****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char *token;
   int  i = 0;
   char string[] = "String com 4 tokens.";
   char separadores[] = " ."; /* Note o espa�o */
                              /* em branco     */

   printf( "\nString a ser separado em tokens:"
           "\n\t\"%s\"\n", string );
   printf("\nOs tokens sao:\n");

   token = strtok(string, separadores);

   while (token) {
      printf("\tToken %d: \"%s\"\n", ++i, token);
      token = strtok(NULL, separadores);
   }

   printf( "\nString original alterado por strtok():"
           "\n\t\"%s\"\n", string );

   return 0;
}

/*

Resultado do programa:

String a ser separado em tokens:
        "String com 4 tokens."

Os tokens sao:
        Token 1: "String"
        Token 2: "com"
        Token 3: "4"
        Token 4: "tokens"

String original alterado por strtok():
        "String"

*/

