/*****************************/
/* Exemplo de uso de strncpy */
/*****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char destino[80];

   strncpy(destino, "Pequeno", 20);
   printf( "\nString 'destino' apos chamada de "
           "strncpy(destino, \"Pequeno\", 20):"
           "\n\t \"%s\"\n", destino );


   strncpy(destino, "Um string bem grande", 10);

   printf( "\nString 'destino' apos chamada de "
           "strncpy(destino, \"Um string bem grande\","
           " 10):\n\t \"%s\"\n", destino );

   return 0;
}

/*

Resultado do programa:

String 'destino' apos chamada de strncpy(destino, "Pequeno", 10):
         "Pequeno"

String 'destino' apos chamada de strncpy(destino, "Um string bem grande", 10):
         "Um string "

*/