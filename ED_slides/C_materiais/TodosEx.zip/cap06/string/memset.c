/****************************/
/* Exemplo de uso de memset */
/****************************/

#include <string.h>
#include <stdio.h>

typedef struct {
           char nome[30];
           char endereco[20];
           char telefone[10];
} tContato;

int main()
{
   tContato pessoa = {"Manoel", "Rua X", "88882424"};

   printf("\nEstrutura ANTES de chamar memset():\n");
   printf("\n\tNome: %s", pessoa.nome);
   printf("\n\tEndereco: %s", pessoa.endereco);
   printf("\n\tTelefone: %s\n", pessoa.telefone);

   memset(&pessoa, '*', sizeof(tContato));

      /* � preciso tranformar os arrays  */
      /* novamente em strings para poder */
      /* usar printf().                  */
   pessoa.nome[29] = pessoa.endereco[19] =
                     pessoa.telefone[9] = '\0';

   printf("\nEstrutura DEPOIS de chamar memset():\n");
   printf("\n\tNome: %s", pessoa.nome);
   printf("\n\tEndereco: %s", pessoa.endereco);
   printf("\n\tTelefone: %s\n", pessoa.telefone);

   return 0;
}

/*

Resultado do programa:

Estrutura ANTES de chamar memset():

        Nome: Manoel
        Endereco: Rua X
        Telefone: 88882424

Estrutura DEPOIS de chamar memset():

        Nome: *****************************
        Endereco: *******************
        Telefone: *********

*/
