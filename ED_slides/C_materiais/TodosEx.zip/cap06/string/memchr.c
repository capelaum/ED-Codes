/****************************/
/* Exemplo de uso de memchr */
/****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char *s = "Apenas um string";
   char *p;

   p = memchr(s, 'r', strlen(s));

   printf("\nString original: \"%s\"", s);
   printf( "\nString a partir do caractere 'r':"
           " \"%s\"\n", p );

   return 0;
}

/*

Resultado do programa

String original: "Apenas um string"
String a partir do caractere 'r': "ring"

*/
