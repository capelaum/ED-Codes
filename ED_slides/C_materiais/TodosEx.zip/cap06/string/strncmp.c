/*****************************/
/* Exemplo de uso de strncmp */
/*****************************/

#include <string.h>
#include <stdio.h>

int main(void)
{
   char string1[] = "Isto eh um teste";
   char string2[] = "Isto nao eh um teste";
   int  comparacao;

   comparacao = strncmp(string1, string2, 5);

   printf("\nComparando ate' o quinto caractere, ");

   if (comparacao < 0)
      printf( "'%s' eh menor do '%s'\n",
              string1, string2 );
   else if (comparacao > 0)
      printf( "'%s' eh maior do '%s'\n",
              string1, string2 );
   else
      printf("os strings sao iguais\n");

   return 0;
}

/*

Resultado do programa:

Comparando ate' o quinto caractere, os strings sao iguais

*/
