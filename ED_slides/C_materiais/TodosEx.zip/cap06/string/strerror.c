/******************************/
/* Exemplo de uso de strerror */
/******************************/

#include <stdio.h>
#include <string.h>

int main()
{
   int i;

       /* Enumera erros com c�digos entre 0 e 4 */
   for (i = 0; i <= 4; ++i)
      printf("Erro No. %d: %s\n", i, strerror(i));

   return 0;
}

/***
 *
 * Resultado do programa:
 *
 * Erro No. 0: No error
 * Erro No. 1: Operation not permitted
 * Erro No. 2: No such file or directory
 * Erro No. 3: No such process
 * Erro No. 4: Interrupted function call
 *
 ***/
