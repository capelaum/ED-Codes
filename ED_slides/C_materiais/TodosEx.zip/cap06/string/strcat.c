/****************************/
/* Exemplo de uso de strcat */
/****************************/

#include <stdio.h>
#include <string.h>

int main(void)
{
   char nome[30]="Manoel ";
   char sobrenome[]="Silva";

   printf("\nNome: \"%s\"\n", nome);
   printf("Sobrenome: \"%s\"\n", sobrenome);

   strcat(nome,sobrenome);

   printf("Nome completo: \"%s\"\n", nome);

   return 0;
}

/*

Resultado do programa:

Nome: "Manoel "
Sobrenome: "Silva"
Nome completo: "Manoel Silva"

*/