/****************************/
/* Exemplo de uso de memcpy */
/****************************/

#include <stdio.h>
#include <string.h>

typedef struct {
           char nome[30];
           char endereco[20];
           char telefone[10];
} tContato;

int main()
{
   tContato umaPessoa = {"Manoel", "Rua X", "88882424"};
   tContato pessoaCopia;

   memcpy(&pessoaCopia, &umaPessoa, sizeof(umaPessoa));

   printf("\nDados copiados:\n");
   printf("\n\tNome: %s", pessoaCopia.nome);
   printf("\n\tEndereco: %s", pessoaCopia.endereco);
   printf("\n\tTelefone: %s\n", pessoaCopia.telefone);

   return 0;
}

/*

Resultado do programa:

Dados copiados:

        Nome: Manoel
        Endereco: Rua X
        Telefone: 88882424

*/
