#include <stdio.h>
#include <stdlib.h>

/****
 *
 * Fun��o FinalDeString(): retorna um ponteiro para
 *                         o caractere '\0', que
 *                         termina um string
 *
 * Argumentos: string (entrada) - o string
 *
 * Retorno: ponteiro para o caractere terminal '\0'
 *
 ****/

char *FinalDeString( const char *string )
{
   return string + strlen(string);
}

int main(void)
{
   char  str[] = "String que sera' invertido";
   char *p;

   printf("\nString original: \"%s\"", str);

   printf("\nString invertido: \"");

      /* Faz p apontar para o �ltimo */
      /* caractere do string         */
   p = FinalDeString(str) - 1;

      /* Imprime os caracteres de tr�s para frente */
   while (p >= str)
      putchar(*p--);

      /* Retoques finais */
   putchar('\"');
   putchar('\n');

   return 0;
}

/*

Resultado do programa:

String original: "String que sera' invertido"
String invertido: "oditrevni 'ares euq gnirtS"

*/
