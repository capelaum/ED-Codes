/*****************************/
/* Exemplo de uso de strncat */
/*****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char destino[80] = "Isto e'";
   char *origem = " um teste apenas.";

   printf("\nString original: \n\t \"%s\"\n", destino);
   printf( "\nString que contem os caracteres a ser "
           "concatenados: \n\t \"%s\"\n",
           origem );

   strncat(destino, origem, 9);

   printf( "\nString original apos ser concatenado "
           "usando strncat(destino, origem, 9): "
           "\n\t \"%s\"\n", destino );

   return 0;
}

/*

Resultado do programa:

String original:
         "Isto e'"

String que contem os caracteres a ser concatenados:
         " um teste apenas."

String original apos ser concatenado usando strncat(destino, origem, 9):
         "Isto e' um teste"

*/
