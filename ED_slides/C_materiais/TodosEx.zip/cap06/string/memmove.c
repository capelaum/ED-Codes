/*****************************/
/* Exemplo de uso de memmove */
/*****************************/

#include <stdio.h>
#include <string.h>

int main()
{
   char s[30] = "Apenas um string";

   printf( "\nString ANTES da chamada de memmove(): "
           "\"%s\"\n", s );
   memmove(s + 7, s, 10);

   printf( "String DEPOIS da chamada de memmove(): "
           "\"%s\"\n", s );

   return 0;
}

/*

Resultado do programa:

String ANTES da chamada de memmove(): "Apenas um string"
String DEPOIS da chamada de memmove(): "Apenas Apenas um "

*/
