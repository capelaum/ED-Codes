/****
 *
 * ATEN��O: Este programa demonstra uma chamada incorreta
 *          da fun��o printf() e pode causar o aborto do
 *          programa.
 *
 ****/

#include <stdio.h>

int main(void)
{
   int x = 10;

   printf("Conteudo do string: %s", x);

   return 0;
}
