/****************************/
/* Exemplo de uso de system */
/****************************/

#include <stdlib.h>

#ifdef LINUX
#error "Este programa nao funciona com Linux"
#endif

int main(void)
{
   if (system(NULL)) /* Verifica a disponibilidade */
                     /* do processador de comandos */
         /* Executa a calculadora do Windows */
      system("calc.exe");

   return 0;
}
