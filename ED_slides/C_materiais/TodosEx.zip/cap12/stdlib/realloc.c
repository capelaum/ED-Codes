/*******************************/
/* Exemplo de uso de realloc() */
/*******************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define NUM_ELEMENTOS 100u

int main(void)
{
   char *bloco = NULL;

          /* Aloca um bloco com calloc() */
   bloco = calloc(NUM_ELEMENTOS, sizeof(char));

   if(bloco == NULL) {
      printf("Nao foi possivel alocar espaco\n");
      return 1;
   } else
      printf( "Bloco alocado com o tamanho %d\n",
              NUM_ELEMENTOS );

   strcpy(bloco, "Isto e� um teste.");

          /* Realoca o bloco de modo que ele */
          /* contenha exatamente o string    */
   bloco = realloc(bloco, strlen(bloco) + 1);

   if(bloco == NULL)
      printf("Nao foi possivel realocar o bloco\n");
   else
      printf( "Bloco realocado com o tamanho %d\n",
              strlen(bloco) + 1 );

   return 0;
}
