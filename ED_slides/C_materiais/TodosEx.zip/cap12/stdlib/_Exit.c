/************************************/
/* Exemplo de uso de _Exit e atexit */
/************************************/

#include <stdio.h>
#include <stdlib.h>

void Despedida(void)
{
   printf("O programa sera' encerrado agora. Bye.\n");
}

int main()
{
   int opcao;

      /* Registra a fun��o Despedida(). O que se */
      /* deseja mostrar aqui � que esta fun��o   */
      /* n�o ser� chamada, como ocorreria se     */
      /* exit() fosse usada.                     */
   atexit(Despedida);

   printf( "Digite 1 para encerrar o programa "
           "usando _Exit ou outro valor para "
           "encerrar o programa normalmente: " );

   opcao = getchar();

   if ( opcao == '1' ) {
      printf( "\nPrograma terminando com chamada "
              "de _Exit()...\n" );
      _Exit(EXIT_SUCCESS);
   }

   printf("\nPrograma terminando normalmente...\n");

   return 0;
}

