/***************************/
/* Exemplo de uso de qsort */
/***************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/****
 *
 * Fun��o Compara(): compara dois strings
 *
 * Argumentos: p1 (entrada) - ponteiro para o
 *                            primeiro strings
 *             p2 (entrada) - ponteiro para o
 *                            segundo strings
 *
 * Retorno:  0, se os strings forem iguais
 *           1, se o primeiro string for maior
 *          -1, se o primeiro string for menor
 *
 ****/

int Compara(const void *s1, const void *s2)
{
   const char *str1 = (char *)s1;
   const char *str2 = (char *)s2;

   return strcmp(str1, str2);
}

int main(void)
{
   char carros[4][10] = {"GM", "Ford", "Fiat", "Honda"};
   int  i;

   qsort(carros, 4, sizeof(carros[0]), Compara);

   for (i = 0; i < 4; i++)
      printf("%s\n", carros[i]);

   return 0;
}

