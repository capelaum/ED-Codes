/***************************/
/* Exemplo de uso de abort */
/***************************/

#include <stdio.h>
#include <signal.h>
#include <stdlib.h>

void TratamentoDeSinal(int sinal)
{
      /* Esta fun��o trata apenas o sinal SIGABRT */
   if (sinal != SIGABRT)
      return;

   printf("O programa sera' abortado agora. Tchau.");
}

int main()
{
   char c;

   printf( "Digite 1 para instalar a funcao de "
           "tratamento de sinal ou outro valor "
           "para nao instala-la: " );
   c = getchar();

   if (c == '1')
      signal(SIGABRT, TratamentoDeSinal);

   printf("Digite 1 para abortar o programa ou "
          "outro valor para termina-lo normalmente: ");

   getchar(); /* Limpa o buffer de entrada */

   c = getchar();

   if (c == '1')
      abort();

   return 0;
}

