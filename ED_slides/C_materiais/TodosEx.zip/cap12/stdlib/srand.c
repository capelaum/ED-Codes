/*****************************/
/* Exemplo de uso de srand() */
/*****************************/

#include <stdio.h>
#include <time.h>
#include <stdlib.h>

int main(void)
{
      /* Atrav�s de v�rias execu��es deste programa */
      /* � poss�vel perceber que os dois primeiros  */
      /* valores impressos nunca s�o modificados    */
      /* enquanto que os dois �ltimos valores s�o   */
      /* modificados a cada execu��o do programa    */

   time_t t;

   printf( "Primeira chamada de rand() SEM o "
           "inicializador srand(): %d\n", rand() );
   printf( "Segunda chamada de rand() SEM o "
           "inicializador srand(): %d\n", rand() );

   srand((unsigned)time(&t));

   printf( "Primeira chamada de rand() COM o "
           "inicializador srand(): %d\n", rand() );
   printf( "Segunda chamada de rand() COM o "
           "inicializador srand(): %d\n", rand() );

   return 0;
}

