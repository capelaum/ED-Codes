/****************************/
/* Exemplo de uso de getenv */
/****************************/

#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   char *str;

   str = getenv("PATH");

   if (str)
      printf( "O conteudo da variavel de ambiente "
              "PATH e':\n\t\"%s\"\n", str);

   return 0;
}
