/*****************************/
/* Exemplo de uso de bsearch */
/*****************************/

#include <stdlib.h>
#include <stdio.h>

   /* Macro usada para calcular o n�mero */
   /* de elementos de um array           */
#define N_ELEMENTOS(ar) (sizeof(ar) / sizeof(ar[0]))

   /* Tipo do ponteiro de fun��o usado   */
   /* como �ltimo argumento de bsearch() */
typedef int (*tFPtr)(const void*, const void*);

/****
 *
 * Fun��o Compara(): compara dois inteiros
 *
 * Argumentos: p1 (entrada) - ponteiro para o
 *                            primeiro inteiro
 *             p2 (entrada) - ponteiro para o
 *                            segundo inteiro
 *
 * Retorno:  0, se os inteiros forem iguais
 *           1, se o primeiro inteiro for maior
 *          -1, se o primeiro inteiro for menor
 *
 ****/

int Compara(const int *p1, const int *p2)
{
   return (*p1 - *p2);
}

/****
 *
 * Fun��o TestaChave(): verifica se uma chave inteira
 *                     faz parte de um array de inteiros
 *
 * Argumentos: chave (entrada) - a chave a ser testada
 *             ar (entrada) - o array que ser� examinado
 *
 * Retorno: 1, se a chave fizer parte do array
 *          0, se a chave n�o fizer parte do array
 *
 ****/

int TestaChave(int chave, const int ar[])
{
   int *p;

   p = bsearch( &chave, ar, N_ELEMENTOS(ar),
				sizeof(int), (tFPtr)Compara );

   return (p != NULL);
}

int main(void)
{
   int  array[] = {123, 456, 789, 888, 900, 933};

   if (TestaChave(789, array))
      printf("789 foi encontrado no array\n");
   else
      printf("789 NAO foi encontrado no array\n");

   if (TestaChave(111, array))
      printf("111 foi encontrado no array\n");
   else
      printf("111 NAO foi encontrado no array\n");

   return 0;
}
