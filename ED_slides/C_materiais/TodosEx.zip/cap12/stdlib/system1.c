/******************************/
/* Exemplo de uso de system() */
/******************************/

#include <stdlib.h>
#include <stdio.h>

#ifdef LINUX
#define COMANDO "ls -alt > Conteudo.txt"
#else
#define COMANDO "dir > Conteudo.txt"
#endif

int main()
{
   if (system(NULL)) { /* Testa se o processador de */
                       /* comandos est� dispon�vel  */
      if(!system(COMANDO))
         printf("O conteudo do diretorio corrente "
                "foi gravado no arquivo "
                "\"Conteudo.txt\"\n");
   } else
      printf("Processador de comandos indisponivel.\n");

   return 0;
}
