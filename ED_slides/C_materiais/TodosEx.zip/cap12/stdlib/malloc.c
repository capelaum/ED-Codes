/******************************/
/* Exemplo de uso de malloc() */
/******************************/

#include <stdio.h>
#include <stdlib.h>

#define NUM_ELEMENTOS 100u

int main(void)
{
   int    *blocos;
   size_t  i;

      /* Aloca um array com 100 elementos tipo */
      /* int. Nenhum elemento � iniciado.      */
   blocos = malloc(NUM_ELEMENTOS * sizeof(int));

      /* Testa se foi poss�vel     */
      /* alocar o espa�o requerido */
   if(blocos == NULL)
       printf("Array nao pode ser alocado\n");
   else{ /* Espa�o alocado com sucesso */
      printf("Conteudo do array:\n");

      for (i = 0; i < NUM_ELEMENTOS; ++i)
         printf("\tblocos[%d] = %d\n", i, blocos[i]);

      free(blocos); /* Libera o espa�o alocado */
   }

   return 0;
}
