/**********************************/
/* Exemplo de uso de rand e srand */
/**********************************/

#include <stdlib.h>
#include <stdio.h>
#include <time.h>

/****
 *
 * Fun��o LancaDados(): simula um n�mero determinado
 *                      de lan�amentos de um dado
 *
 * Argumentos: nLancamentos (entrada) - n�mero de vezes
 *                                      que o dado ser�
 *                                      lan�ado
 *
 * Retorno: Nada
 *
 ****/

void LancaDados(unsigned nLancamentos)
{
   unsigned i;

   for(i=0; i < nLancamentos; i++)
      printf("\t\t\t\t%d\n", rand()%6 + 1);
}

int main(void)
{
   time_t t;

      /* Alimenta o gerador de n�meros aleat�rios */
   srand((unsigned) time(&t));

   printf("\nPrimeira serie de lancamentos:\n");
   LancaDados(10);

   printf("\nSegunda serie de lancamentos:\n");
   LancaDados(10);

   return 0;
}
