/***********************************/
/* Exemplo de uso de exit e atexit */
/***********************************/

#include <stdio.h>
#include <stdlib.h>

void Despedida(void)
{
   printf("O programa sera' encerrado agora. Bye.\n");
}

int main()
{
   int opcao;

      /* Registra a fun��o Despedida */
   atexit(Despedida);

   printf( "Digite 1 para encerrar o programa "
           "usando exit() ou outro valor para "
           "encerrar o programa normalmente: " );

   opcao = getchar();

   if ( opcao == '1' ) {
      printf( "\nPrograma terminando com "
              "chamada de exit()...\n" );
      exit(EXIT_SUCCESS);
   }

   printf("\nPrograma terminando normalmente...\n");

   return 0;
}

