/****************************/
/* Exemplo de uso de free() */
/****************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define TAMANHO 4096

   /* A macro a seguir chama fun��o free() e em  */
   /* seguida anula o ponteiro. Assim, uma       */
   /* tentativa de usar o ponteiro causa um erro */
   /* em tempo de execu��o, em vez de deixar a   */
   /* execu��o prosseguir com um comportamento   */
   /* indefinido (erro l�gico).                  */
#define FREE(x) do { free(x); x = NULL; } while(0)

int main()
{
   char *ptr;

      /* Tenta obter um bloco de 4096 bytes */
   ptr = malloc(TAMANHO * sizeof(char));

   if (!ptr) {
      fprintf( stderr, "Memoria insuficiente\n" );
      return 1;
   }

   strncpy( ptr, "Suponha que isto e' um string "
                 "bem longo\n", TAMANHO );

   fputs(ptr, stdout);

      /* Para testar o programa, uma das instru��es */
      /* a seguir deve ser comentada                */
   free(ptr); /* A fun��o */
/*   FREE(ptr); /* A macro  */

   fputs(ptr, stdout);

   return 0;
}
