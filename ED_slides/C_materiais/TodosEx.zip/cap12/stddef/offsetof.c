/******************************/
/* Exemplo de uso de offsetof */
/******************************/

#include <stdio.h>
#include <stddef.h>

typedef struct {
  char  membro1;
  int   membro2;
} tEstrutura1;

typedef struct {
  int   membro1;
  char  membro2;
} tEstrutura2;

int main(void)
{
   printf( "Deslocamento de membro2 de tEstrutura1: "
           "%d\n", offsetof(tEstrutura1, membro2));
   printf( "Deslocamento de membro2 de tEstrutura2: "
           "%d\n", offsetof(tEstrutura2, membro2));

   return 0;
}

/***
 *
 * Resultado do programa quando compilado com Borland C++ 5.0:
 *
 * Deslocamento de membro2 de tEstrutura1: 1
 * Deslocamento de membro2 de tEstrutura2: 4
 *
 * ************************************************************
 *
 * Resultado do programa quando compilado com gcc 3.2 (Win XP) e
 * 4.3.2 (Linux Ubuntu 8.10):
 *
 * Deslocamento de membro2 de tEstrutura1: 4
 * Deslocamento de membro2 de tEstrutura2: 4
 *
 ***/

