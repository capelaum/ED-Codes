/*******************************************************/
/* Exemplo de uso de macros e das fun��es fegetround e */
/* fesetround para altera��o do modo de arredondamento */
/*******************************************************/

#include <stdio.h>
#include <fenv.h>
#include <assert.h>
#include <math.h>

void Arredonda(double arredondeMe)
{
#pragma STDC FENV_ACCESS ON

   int  arredondametoSalvo;

      /* Guarda o modo de arredondamento corrente */
   arredondametoSalvo = fegetround();

   if (fesetround(FE_DOWNWARD)) {
      printf( "Nao foi possivel alterar o modo de "
              "arredondamento" );
      return;
   }

   printf( "O valor de %3.2f arredondado usando lrint "
           "e' %ld\n", arredondeMe, lrint(arredondeMe) );
   printf( "O valor de %3.2f arredondado usando "
           "lround e' %ld\n", arredondeMe,
           lround(arredondeMe) );

   if (fesetround(FE_UPWARD)) {
      printf("Nao foi possivel alterar o modo de "
             "arredondamento");
      return;
   }

   printf( "O valor de %3.2f arredondado usando "
           "lrint e' %ld\n", arredondeMe,
           lrint(arredondeMe) );
   printf( "O valor de %3.2f arredondado usando "
           "lround e' %ld\n", arredondeMe,
           lround(arredondeMe) );

      /* Restaura o modo de arredondamento original */
   fesetround(arredondametoSalvo);
}

int main()
{
   double x = 2.4;

      /* Executa algumas opera��es */
   /* ... */

   Arredonda(x);

      /* Executa outras opera��es com o mesmo  */
      /* modo de arredondamento em vigor antes */
      /* de chamar Arredonda()                 */
   /* ... */


   return 0;
}

/*

Resultado do programa no Windows XP:

O valor de 2.40 arredondado usando lrint e' 2
O valor de 2.40 arredondado usando lround e' 2
O valor de 2.40 arredondado usando lrint e' 3
O valor de 2.40 arredondado usando lround e' 2

*/
