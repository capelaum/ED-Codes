/*********************************************/
/* Exemplo de uso de macros e fun��es para   */
/* tratamento de exce��es de ponto flutuante */
/*                                           */
/* Fun��es demonstradas:                     */
/*       * feholdexcept()                    */
/*       * feupdateenv()                     */
/*       * feraiseexcept()                   */
/*       * fetestexcept()                    */
/*********************************************/

#include <stdio.h>
#include <fenv.h>

void ImprimeFlags(const char* textoInicial, int flags)
{
   if (flags & FE_INEXACT)
      printf("\n%s\n\tOcorreu um resultado inexato\n",
             textoInicial);

   if (flags & FE_UNDERFLOW)
      printf("\n%s\n\tOcorreu underflow\n",
             textoInicial);

   if (flags & FE_OVERFLOW)
      printf("\n%s\n\tOcorreu overflow\n",
             textoInicial);

   if (flags & FE_DIVBYZERO)
      printf("\n%s\n\tOcorreu uma divisao por zero\n",
             textoInicial);

   if (flags & FE_INVALID)
      printf("\n%s\n\tOcorreu uma operacao invalida\n",
             textoInicial);

   if (!(flags & FE_ALL_EXCEPT))
      printf("\n%s\n\tNao houve ocorrencia de excecao\n",
             textoInicial);
}

double OperacaoDePF(double x)
{
   fenv_t  ambientePF;
   int     excecao;

      /* O trecho a seguir demonstra que, como esta */
      /* fun��o pode ter sido chamada depois de     */
      /* alguma flag ter sido ligada, se ocorrer    */
      /* alguma exce��o aqui, n�o ser� poss�vel     */
      /* saber se esta exce��o surgiu nesta fun��o  */
      /* ou se a mesma j� havia ocorrido antes de   */
      /* esta fun��o ser chamada.                   */
   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags( "Na entrada da funcao OperacaoDePF:",
                 excecao );

      /* Aqui come�a a situa��o real. Primeiro,   */
      /* salvam-se os sinalizadores e desligam-se */
      /* os mesmos usando a fun��o feholdexcept() */
   feholdexcept(&ambientePF);

      /* Agora s�o executadas opera��es de ponto */
      /* flutuante que podem dar origem a alguma */
      /* exce��o. Aqui, isto � simulado usando   */
      /* a fun��o feraiseexcept().               */

   // ... (opera��es que podem causar exce��o)
   feraiseexcept(FE_INEXACT);

      /* Numa situa��o real, as instru��es a seguir   */
      /* seriam substitu�das por instru��es que testa */
      /* se ocorreram exece��es nas opera��es acima.  */
   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags("Na funcao OperacaoDePF, depois da "
                "ocorrencia de uma excecao:", excecao);

      /* Agora as exce��es de ponto flutuante que     */
      /* possam ter ocorrido seriam tratadas a seguir */
   // ... (tratamento de evetuais exce��es)

      /* Restaura a configura��o de ambiente    */
      /* guardada acima e liga os sinalizadores */
      /* de exce��es que ocorreram nesta fun��o */
   feupdateenv(&ambientePF);

   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags( "Na funcao OperacaoDePF, antes "
                 "de retornar:", excecao );

   return x;
}

int main(void)
{
  int       excecao;

  		/* Suponha que no trecho de programa a seguir */
  		/* possa ocorrer uma situa��o de exce��o.     */
  		/* Aqui, n�s simulamos isto usando a fun��o   */
  		/* feraiseexcept().                           */

   // ... (opera��es que podem causar exce��o)
   feraiseexcept(FE_DIVBYZERO);

   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags( "Na funcao main antes de chamar "
                 "OperacaoDePF:", excecao );

      /* Agora, chama a fun��o OperacaoDePF()  */
      /* que tamb�m pode provocar uma exce��o. */
   OperacaoDePF(2.5);

   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags( "Na funcao main depois de chamar "
                 "OperacaoDePF:", excecao );

   return 0;
}

/*

Resultado do programa no Windows XP:

Na funcao main antes de chamar OperacaoDePF:
        Ocorreu uma divisao por zero

Na entrada da funcao OperacaoDePF:
        Ocorreu uma divisao por zero

Na funcao OperacaoDePF, depois da ocorrencia de uma excecao:
        Ocorreu um resultado inexato

Na funcao OperacaoDePF, antes de retornar:
        Ocorreu um resultado inexato

Na funcao OperacaoDePF, antes de retornar:
        Ocorreu uma divisao por zero

Na funcao main depois de chamar OperacaoDePF:
        Ocorreu um resultado inexato

Na funcao main depois de chamar OperacaoDePF:
        Ocorreu uma divisao por zero

*/
