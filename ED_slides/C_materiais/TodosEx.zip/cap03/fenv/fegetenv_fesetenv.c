/*********************************************/
/* Exemplo de uso de macros e fun��es para   */
/* tratamento de exce��es de ponto-flutuante */
/*                                           */
/* Fun��es demonstradas:                     */
/*       * fegetenv()                        */
/*       * fesetenv()                        */
/*                                           */
/* Demonstra ainda o uso de #pragma:         */
/*       * STDC FENV_ACCESS                  */
/*********************************************/

#include <stdio.h>
#include <float.h>
#include <fenv.h>

/***
*
* A fun��o a seguir altera o ambiente de ponto
* flutuante para realizar algumas opera��es, mas
* restaura o ambiente original antes de retornar
*
***/
double UmaFuncao(double x, double y)
{
      /* Esta op��o fica ativada at� o  */
      /* final da execu��o desta fun��o */
#pragma STDC FENV_ACCESS ON

   double  resultado = 0.0;
   fenv_t  ambienteGuardado;

      /* Guarda o ambiente de ponto */
      /* flutuante original         */
   fegetenv(&ambienteGuardado);

      /* Instala o ambiente de  */
      /* ponto flutuante padr�o */
   fesetenv(FE_DFL_ENV);

      /* Executa opera��es de ponto flutuante */
   /* ... */

      /* Antes de retornar, restaura */
      /* o ambiente original         */
   fesetenv(&ambienteGuardado);

   return resultado;
}

int main()
{
   double resultado;

       /* Talvez o ambiente de ponto-flutuante seja */
       /* alterado no trecho de programa a seguir   */
   /* ... */

   resultado = UmaFuncao(2.4, -0.5);

       /* Neste ponto, o ambiente de ponto-flutuante */
       /* � o mesmo de antes da chamada da fun��o    */
   /* ... */

   return 0;
}

