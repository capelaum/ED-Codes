/*****************************************************/
/* Exemplo de uso de macros e da fun��o fetestexcept */
/* para tratamento de exce��es de ponto flutuante    */
/*****************************************************/

#include <stdio.h>
#include <float.h>
#include <fenv.h>

int main()
{
   int     flags;
   double  x;

#pragma STDC FENV_ACCESS ON

   x = 2.0/3.0; /* Causa uma exce��o de inexatid�o */

   x = DBL_MIN / 5.0; /* Deve causar underflow */

      /* Ao contr�rio do que muitos pensam, a  */
      /* instru��o seguinte n�o causa o aborto */
      /* do programa. Ela simplesmente liga o  */
      /* sinalizador de exce��o de opera��o    */
      /* inv�lida e o resultado armazenado em  */
      /* x � indefinido.                       */
   x = 0.0/0.0;
   printf("%f", x);

      /* Armazena todas em flags as exce��es de */
      /* ponto flutuante que se desejam testar  */
   flags = fetestexcept( FE_UNDERFLOW |
                         FE_INEXACT |
                         FE_INVALID );

      /* Agora testa que tipo de exece��o de ponto */
      /* flutuante ocorreu nas opera��es acima     */

   if (flags & FE_UNDERFLOW)
      printf("\nOcorreu overflow numa das operacoes\n");

   if (flags & FE_INEXACT)
      printf( "\nFoi executada uma operacao que "
              "resultou num valor inexato\n" );

   if (flags & FE_INVALID)
      printf( "\nHouve uma tentativa de execucao de "
              "operacao invalida\n" );

   return 0;
}

/*

Resultado do programa no Windows XP:

-1.#IND00
Houve uma tentativa de execucao de operacao invalida

*/
