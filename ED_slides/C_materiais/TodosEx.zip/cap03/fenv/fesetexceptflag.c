/*********************************************/
/* Exemplo de uso de macros e fun��es para   */
/* tratamento de exce��es de ponto flutuante */
/*                                           */
/* Fun��es demonstradas:                     */
/*       * fegetexceptflag()                 */
/*       * feclearexcept()                   */
/*       * fetestexcept()                    */
/*       * fesetexceptflag()                 */
/*********************************************/

#include <stdio.h>
#include <float.h>
#include <fenv.h>

/***
 *
 * Suponha que a fun��o a seguir executa uma opera��o
 * de ponto flutuante que possa gerar uma exce��o do
 * tipo representada pela flag FE_INVALID e que esta
 * fun��o deva manter intacto o status da vari�vel
 * que armazena todas as exce��es de ponto flutuante
 *
 ***/
double UmaFuncao(double x, double y)
{
   int        flag;
   fexcept_t  flagsGuardadas;

      /* Armazena todas as flags de exce��es de      */
      /* ponto flutuante na vari�vel fegetexceptflag */
   fegetexceptflag(&flagsGuardadas, FE_ALL_EXCEPT);

      /* Desliga a flag que supostamente interessa */
   feclearexcept(FE_INVALID);

      /* Executa a opera��o que pode */
      /* gerar a suposta exce��o     */
   /* ... */

      /* Armazena na vari�vel flag a flag de interesse */
      /* (i.e., aquela que pode ter sido ligada) na    */
      /* opera��o representada acima por "..."         */
   flag = fetestexcept(FE_INVALID);

      /* Agora testa se ocorreu a prov�vel exece��o */
   if (flag & FE_INVALID) {
         /* Faz o devido tratamento */
         /* da situa��o de exce��o  */
      /* ... */
   }

      /* Antes de retornar, restaura todos */
      /* os sinalizadores de exce��es de   */
      /* ponto flutuante armazenados na    */
      /* vari�vel flagsGuardadas           */
   fesetexceptflag(&flagsGuardadas, FE_ALL_EXCEPT);

      /* Isto � apenas um programa educativo; por */
      /* isso, � retornado x + y. Na realidade,   */
      /* seria retornado o resultado da opera��o  */
      /* implementada pela fun��o.                */
   return x + y;
}

int main()
{
   double resultado;

      /* Executa opera��es que podem gerar  */
      /* exce��es de ponto flutuante        */
   /* ... */

      /* Talvez algum sinalizador de exce��o de */
      /* ponto flutuante esteja ligado neste    */
      /* ponto do programa. A chamada da fun��o */
      /* UmaFuncao() garante que o status dos   */
      /* sinalizadores ser� preservado.         */

   resultado = UmaFuncao(2.4, -0.5);

   return 0;
}

/*

Resultado do programa no Windows XP:

Este programa n�o tem sa�da, est� OK.

*/
