/*********************************************/
/*                                           */
/* Exemplo de uso de macros e fun��es para   */
/* tratamento de exce��es de ponto-flutuante */
/*                                           */
/* Fun��es demonstradas:                     */
/*       * fegetexceptflag()                 */
/*       * fetestexcept()                    */
/*       * feraiseexcept()                   */
/*       * feclearexcept()                   */
/*       * fesetexceptflag()                 */
/*                                           */
/*********************************************/

#include <stdio.h>
#include <fenv.h>

void ImprimeFlags(const char* textoInicial, int flags)
{
   if (flags & FE_INEXACT)
      printf("\n%s\n\tOcorreu um resultado inexato\n",
              textoInicial);

   if (flags & FE_UNDERFLOW)
      printf("\n%s\n\tOcorreu underflow\n",
              textoInicial);

   if (flags & FE_OVERFLOW)
      printf("\n%s\n\tOcorreu overflow\n",
              textoInicial);

   if (flags & FE_DIVBYZERO)
      printf("\n%s\n\tOcorreu uma divisao por zero\n",
              textoInicial);

   if (flags & FE_INVALID)
      printf("\n%s\n\tOcorreu uma operacao invalida\n",
              textoInicial);

   if (!(flags & FE_ALL_EXCEPT))
      printf("\n%s\n\tNao houve ocorrencia de excecao\n",
              textoInicial);
}

int main(void)
{
   fexcept_t flagsSalvas;
   int       excecao;

      /* Guardas o status dos sinalizadores */
      /* para restaura��o posterior         */
   fegetexceptflag(&flagsSalvas, FE_ALL_EXCEPT);

      /* Testa todos os sinalizadores de exce��o */
   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags("No inicio:", excecao);

      /* Provoca uma exce��o do tipo divis�o por zero */
   feraiseexcept(FE_DIVBYZERO);

      /* Testa se ocorreu algum tipo de exce��o.   */
      /* Ap�s a chamada de fetestexcept(), pode-se */
      /* usar a variavel excecao para verificar se */
      /* ocorreu exe��o de algum dos tipos         */
      /* espcificados como argumentos de           */
      /* fetestexcept() usando o operador &, o que */
      /* � feito pela fun��o ImprimeFlags().       */
   excecao = fetestexcept(FE_DIVBYZERO | FE_INEXACT);
   ImprimeFlags( "Apos feraiseexcept(FE_DIVBYZERO):",
                 excecao );

      /* Provoca uma exce��o de   */
      /* inexatid�oe depois testa */
   feraiseexcept(FE_INEXACT);
   excecao = fetestexcept(FE_OVERFLOW | FE_INEXACT);
   ImprimeFlags( "Apos feraiseexcept(FE_INEXACT):",
                 excecao );

      /* Desliga todos os sinalizadores de exce��o */
   feclearexcept(FE_ALL_EXCEPT);

      /* Testa todos os sinalizadores de exce��o */
   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags( "Apos desligar todas as excecoes:",
                 excecao );

      /* Provoca uma exce��o de inexatid�o */
      /* e depois as testa                 */
   feraiseexcept(FE_UNDERFLOW);
   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags( "Apos feraiseexcept(FE_UNDERFLOW):",
                 excecao );

      /* Restauras o status de todos os */
      /* sinalizadores de exce��es      */
   fesetexceptflag(&flagsSalvas, FE_ALL_EXCEPT);

      /* Testa todos os sinalizadores de exce��o */
   excecao = fetestexcept(FE_ALL_EXCEPT);
   ImprimeFlags("Apos restauras flags:", excecao);

   return 0;
}

/*

Resultado do programa no Windows XP:

No inicio:
        Nao houve ocorrencia de excecao

Apos feraiseexcept(FE_DIVBYZERO):
        Ocorreu uma divisao por zero

Apos feraiseexcept(FE_INEXACT):
        Ocorreu um resultado inexato

Apos desligar todas as excecoes:
        Nao houve ocorrencia de excecao

Apos feraiseexcept(FE_UNDERFLOW):
        Ocorreu underflow

Apos restauras flags:
        Nao houve ocorrencia de excecao

*/
