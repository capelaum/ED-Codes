/**********************************************/
/* Execute o programa abaixo para conhecer os */
/* valores das macros (constantes) definidas  */
/* no arquivo float.h.                        */
/**********************************************/

#include <stdio.h>
#include <float.h>

int main(void)
{
   printf("\nPrecisao em casas decimais para o tipo "
          "double: %d", DBL_DIG);
   printf("\nMenor X do tipo double tal que "
          "1.0 + X != 1.0: %f", DBL_EPSILON);
   printf("\nNumero de digitos na mantissa, na base "
          "FLT_RADIX, para o tipo double: %d",
          DBL_MANT_DIG);
   printf("\nMaior valor finito e representavel do "
          "tipo double: %E", DBL_MAX);
   printf("\nMaior inteiro X, tal que 10^X e' um "
          " valor finito e representavel do tipo "
          "double: %d", DBL_MAX_10_EXP);
   printf("\nMaior inteiro X, tal que FLT_RADIX^(X - 1)"
          " e' um valor finito e representavel do tipo "
          "double: %d", DBL_MAX_EXP);
   printf("\nMenor valor normalizado, finito e "
          "representavel do tipo double: %f", DBL_MIN);
   printf("\nMenor inteiro X, tal que 10^X e' um valor"
          " normalizado, finito e representavel do "
          "tipo double: %d", DBL_MIN_10_EXP);
   printf("\nMenor inteiro X, tal que FLT_RADIX^(X - 1)"
          " e' um valor normalizado, finito e "
          "representavel do tipo double: %d",
           DBL_MIN_EXP);
   printf("\nNumero minimo de casas decimais necessarias"
          " para representar todos os digitos "
          "significativos para o tipo long double: %d",
          DECIMAL_DIG); // (C99)
   printf("\nPrecisao em casas decimais para o tipo "
          "float: %d", FLT_DIG);
   printf("\nMenor X do tipo float tal que "
          "1.0 + X != 1.0: %f", FLT_EPSILON);

   printf("\nModo de avaliacao para operacoes de "
          "ponto flutuante: ");

   switch (FLT_EVAL_METHOD) { // (C99)
      case -1:
         printf("indeterminado");
         break;
      case  0:
         printf("nao ha promocao de valores");
         break;
      case  1:
         printf("valores do tipo float sao "
                "promovidos a double");
         break;
      case  2:
         printf("valores do tipo float e double sao "
                "promovidos a long double");
         break;
   }

   printf("\nNumero de digitos na mantissa, na base "
          "FLT_RADIX, para o tipo float: %d",
          FLT_MANT_DIG);
   printf("\nMaior valor finito e representavel do "
          "tipo float: %E", FLT_MAX);
   printf("\nMaior inteiro X, tal que 10^X e' um valor"
          " finito e representavel do tipo float: %d",
          FLT_MAX_10_EXP);
   printf("\nMaior inteiro X, tal que FLT_RADIX^(X - 1)"
          " e' um valor finito e representavel do tipo"
          " float: %d", FLT_MAX_EXP);
   printf("\nMenor valor normalizado, finito e "
          "representavel do tipo float: %f", FLT_MIN);
   printf("\nMenor inteiro X, tal que 10^X e' um valor"
          " normalizado, finito e representavel do "
          "tipo float: %d", FLT_MIN_10_EXP);
   printf("\nMenor inteiro X, tal que FLT_RADIX^(X - 1)"
          " e' um valor normalizado, finito e "
          "representavel do tipo float: %d",
          FLT_MIN_EXP);
   printf("\nBase de todas as representacoes de "
          "numeros de ponto flutuante: %d", FLT_RADIX);

   printf("\nO modo de arredondamento para operacoes"
          " de ponto flutuante e' ");

   switch (FLT_ROUNDS) {
      case -1:
         printf("indeterminado");
         break;
      case 0:
         printf("direcionado para zero");
         break;
      case 1:
         printf("para o mais proximo valor "
                "representavel");
         break;
      case 2:
         printf("direcionado para mais infinito");
         break;
      case 3:
         printf("direcionado para menos infinito");
         break;
   }

   printf("\nPrecisao em casas decimais para o tipo "
          "long double: %d", LDBL_DIG);
   printf("\nMenor X do tipo long double tal que "
          "1.0 + X != 1.0: %Lf", LDBL_EPSILON);
   printf("\nNumero de digitos na mantissa, na base "
          "FLT_RADIX, para o tipo long double: %d",
          LDBL_MANT_DIG);
   printf("\nMaior valor finito e representavel do "
          "tipo long double: %LE", LDBL_MAX);
   printf("\nMaior inteiro X, tal que 10^X e' um valor"
          " finito e representavel do tipo long double:"
          " %d", LDBL_MAX_10_EXP);
   printf("\nMaior inteiro X, tal que FLT_RADIX^(X - 1)"
          " e' um valor finito e representavel do tipo"
          " long double: %d", LDBL_MAX_EXP);
   printf("\nMenor valor normalizado, finito e "
          "representavel do tipo long double: %Lf",
          LDBL_MIN);
   printf("\nMenor inteiro X, tal que 10^X e' um valor"
          " normalizado, finito e representavel do "
          "tipo long double: %d", LDBL_MIN_10_EXP);
   printf("\nMenor inteiro X, tal que FLT_RADIX^(X - 1)"
          " e' um valor normalizado, finito e "
          "representavel do tipo long double: %d\n",
          LDBL_MIN_EXP);

   return 0;
}
