/*************************/
/* Exemplo de uso de nan */
/*************************/

#include <stdio.h>
#include <math.h>

int main()
{
   printf( "O resultado de 'nan(\"NAN\")' %s e' NaN\n",
           isnan(nan("32")) ? "" : "NAO" );

   return 0;
}

/***

Resultado do programa:

O resultado de 'nan("NAN")'  e' NaN

***/
