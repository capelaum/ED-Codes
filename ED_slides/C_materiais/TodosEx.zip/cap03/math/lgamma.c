/****************************/
/* Exemplo de uso de lgamma */
/****************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = -2.4;

   printf( "O valor de lgamma(%3.2f) e' %f\n",
           x, lgamma(x) );

   return 0;
}

/***

Resultado do programa:

O valor de lgamma(-2.40) e' 0.102584

***/
