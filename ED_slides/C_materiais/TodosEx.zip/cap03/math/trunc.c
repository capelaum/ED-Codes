/***************************/
/* Exemplo de uso de trunc */
/***************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 2.99, y = -2.9;

   printf( "O valor de %3.2f arredondado usando "
           "trunc e' %3.2f\n", x, trunc(x) );
   printf( "O valor de %3.2f arredondado usando "
           "trunc e' %3.2f\n", y, trunc(y) );

   return 0;
}

/***

Resultado do programa:

O valor de 2.99 arredondado usando trunc e' 2.00
O valor de -2.90 arredondado usando trunc e' -2.00

***/
