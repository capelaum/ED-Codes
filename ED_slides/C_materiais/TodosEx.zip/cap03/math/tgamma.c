/****************************/
/* Exemplo de uso de tgamma */
/****************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 3.14;

   printf( "A funcao gama de %3.2f e' %3.2f\n",
           x, tgamma(x) );

   return 0;
}

/***

Resultado do programa:

A funcao gama de 3.14 e' 2.28

***/
