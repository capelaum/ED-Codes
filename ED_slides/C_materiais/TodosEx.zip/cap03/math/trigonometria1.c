/***************************************/
/* Exemplo de uso de acos, asin e atan */
/***************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   printf( "Arco coseno de %3.2f = %3.2f\n", 1.0,
           acos(1.0) );
   printf( "Arco seno de %3.2f = %3.2f\n", 1.0,
           asin(1.0) );
   printf( "Arco tangente de %3.2f (atan) = %3.2f\n",
           1.0, atan(1.0) );

   return 0;
}

/***

Resultado do programa:

Arco coseno de 1.00 = 0.00
Arco seno de 1.00 = 1.57
Arco tangente de 1.00 (atan) = 0.79

***/
