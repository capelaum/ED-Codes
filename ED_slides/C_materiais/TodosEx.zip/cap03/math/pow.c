/*************************/
/* Exemplo de uso de pow */
/*************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
    printf("3 elevado a 5 = %5.3f\n", pow(3.0, 5.0));

    return 0;
}

/***

Resultado do programa:

3 elevado a 5 = 243.000

***/
