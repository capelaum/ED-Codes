/****************************/
/* Exemplo de uso de log2() */
/****************************/

#include <math.h>
#include <stdio.h>
#include <errno.h>

int main()
{
   double x[] = { 0, 0.8, -1.5, 123, INFINITY };
   int    i;

   putchar('\n');

   for (i = 0; i < sizeof(x)/sizeof(double); i++) {
      errno = 0;
      printf( "O logaritmo na base 2 de %.1f is %.3f\n",
              x[i], log2(x[i]) );
      if ( errno == EDOM || errno == ERANGE )
         perror( __FILE__ );
   }

   putchar('\n');

   return 0;
}

/*

Resultado do programa no Linux:

O logaritmo na base 2 de 0.0 is -inf
log2.c: Numerical result out of range
O logaritmo na base 2 de 0.8 is -0.322
O logaritmo na base 2 de -1.5 is nan
log2.c: Numerical argument out of domain
O logaritmo na base 2 de 123.0 is 6.943
O logaritmo na base 2 de inf is inf

*/
