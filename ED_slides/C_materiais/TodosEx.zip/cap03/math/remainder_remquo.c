/****************************************/
/* Exemplo de uso de remainder e remquo */
/****************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double  x = 5.0, y = 3.0;
   int     quociente;

   printf( "Resto da divisao de %f por %f usando "
           "remainder: %f\n", x, y, remainder(x, y) );

   printf( "Resto da divisao de %f por %f "
           "usando remquo: %f\n", x, y,
           remquo(x, y, &quociente) );

   printf( "Quociente da divisao de %f por %f "
           "usando remquo: %d\n", x, y, quociente );

   return 0;
}

/***

Resultado do programa:

Resto da divisao de 5.000000 por 3.000000 usando remainder: -1.000000
Resto da divisao de 5.000000 por 3.000000 usando remquo: -1.000000
Quociente da divisao de 5.000000 por 3.000000 usando remquo: 2


***/
