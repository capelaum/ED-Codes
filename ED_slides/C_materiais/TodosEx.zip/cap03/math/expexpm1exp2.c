/****************************************/
/* Exemplo de uso de exp, expm1 e exp2  */
/****************************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
    double x = 5.0;

    printf( "Exponencial de %f na base 'e': %f\n",
            x, exp(x) );
    printf( "Exponencial de %f na base 'e' "
            "menos um: %f\n",x, expm1(x) );
    printf( "Exponencial de %f na base 2: %f\n",
            x, exp2(x) );

    return 0;
}

/***

Resultado do programa:

Exponencial de 5.000000 na base 'e': 148.413159
Exponencial de 5.000000 na base 'e' menos um: 147.413159
Exponencial de 5.000000 na base 2: 32.000000

***/
