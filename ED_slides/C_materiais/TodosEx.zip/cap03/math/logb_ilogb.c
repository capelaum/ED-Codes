/**********************************/
/* Exemplo de uso de logb e ilogb */
/**********************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double x = 0.0, y = INFINITY, z = NAN, w = 3.5;

   printf("\n**** logb ****\n");
   printf("\tlogb(%f) = %f\n", x, logb(x));
   printf("\tlogb(%f) = %f\n", y, logb(y));
   printf("\tlogb(%f) = %f\n", z, logb(z));
   printf("\tlogb(%f) = %f\n", w, logb(w));

   printf("\n\n**** ilogb ****\n");
   printf("\tilogb(%f) = %d\n", x, ilogb(x));
   printf("\tilogb(%f) = %d\n", y, ilogb(y));
   printf("\tilogb(%f) = %d\n", z, ilogb(z));
   printf("\tilogb(%f) = %d\n", w, ilogb(w));

   return 0;
}

/*

Resultado do programa no Win XP:

**** logb ****
        logb(0.000000) = -1.#INF00
        logb(1.#INF00) = 1.#INF00
        logb(-1.#IND00) = -1.#IND00
        logb(3.500000) = 1.000000


**** ilogb ****
        ilogb(0.000000) = -2147483648
        ilogb(1.#INF00) = 2147483647
        ilogb(-1.#IND00) = -2147483648
        ilogb(3.500000) = 1

*/
