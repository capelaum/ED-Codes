/********************************************/
/* Exemplo de uso de nextafter e nexttoward */
/********************************************/

#include <stdio.h>
#include <math.h>
#include <float.h>

int main()
{
   double   x = 2.9, y = 2.5, z = -2.5;

   printf( "Valor mais proximo de %3.2f usando "
           "nextafter(%3.2f, %3.2f): %3.2f\n",
           x, x, y, nextafter(x, y) );

   printf( "Valor mais proximo de %3.2f usando "
           "nextafter(%3.2f, %3.2f): %3.2f\n",
           x, x, z, nextafter(x, z) );

   y = DBL_MAX;
   z = DBL_MIN;

   printf( "Valor mais proximo de %3.2f usando "
           "nexttoward(%3.2f, %3.2E): %3.2f\n",
           x, x, y, nexttoward(x, y) );

   printf( "Valor mais proximo de %3.2f usando "
           "nexttoward(%3.2f, %3.2E): %3.2f\n",
           x, x, z, nexttoward(x, z) );

   return 0;
}

/***

Resultado do programa:

Valor mais proximo de 2.90 usando nextafter(2.90, 2.50): 2.90
Valor mais proximo de 2.90 usando nextafter(2.90, -2.50): 2.90
Valor mais proximo de 2.90 usando nexttoward(2.90, 1.80E+308): 2.90
Valor mais proximo de 2.90 usando nexttoward(2.90, 2.23E-308): 2.90


***/
