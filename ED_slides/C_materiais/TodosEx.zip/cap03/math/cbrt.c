/**************************/
/* Exemplo de uso de cbrt */
/**************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 8.0;

   printf( "A raiz cubica de %3.2f e' %3.2f\n",
           x, cbrt(x) );

   return 0;
}

/***

Resultado do programa:

A raiz cubica de 8.00 e' 2.00

***/
