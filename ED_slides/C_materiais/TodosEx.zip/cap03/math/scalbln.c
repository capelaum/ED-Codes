/****************************/
/* Exemplo de uso de scalbn */
/****************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = -3.4;
   long   expoente = 2L;

   printf( "O valor de scalbln(%3.2f, %d) e' %f\n",
           x, expoente, scalbln(x, expoente) );

   return 0;
}

/***

Resultado do programa:

O valor de scalbln(-3.40, 2) e' -13.600000

***/
