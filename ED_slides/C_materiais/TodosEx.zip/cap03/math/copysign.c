/******************************/
/* Exemplo de uso de copysign */
/******************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = -3.14, y = 2.5, z = -4.8;

   printf( "Valores originais: x = %3.2f, y = %3.2f\n",
           x, y );
   printf( "Valor de x com sinal de y = %3.2f\n",
           copysign(x, y) );

   printf( "\n\nValores originais: x = %3.2f, "
           "z = %3.2f\n", x, z );
   printf( "Valor de x com sinal de z = %3.2f\n",
           copysign(x, z) );

   return 0;
}

/***

Resultado do programa:

Valores originais: x = -3.14, y = 2.50
Valor de x com sinal de y = 3.14

Valores originais: x = -3.14, z = -4.80
Valor de x com sinal de z = -3.14

***/
