/**************************/
/* Exemplo de uso de sqrt */
/**************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
    return !printf("sqrt(2) = %.4f\n", sqrt(2));
}

/***

Resultado do programa:

sqrt(2) = 1.4142

***/
