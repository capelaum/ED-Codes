/*****************************/
/* Exemplo de uso de signbit */
/*****************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = -3.4, y = 7.44;

   printf( "O bit de sinal de %3.2f esta' %s\n",
           x, signbit(x) ? "ligado" : "desligado");

   printf( "O bit de sinal de %3.2f esta' %s\n",
           y, signbit(y) ? "ligado" : "desligado");

   return 0;
}

/***

Resultado do programa:

O bit de sinal de -3.40 esta' ligado
O bit de sinal de 7.44 esta' desligado

***/
