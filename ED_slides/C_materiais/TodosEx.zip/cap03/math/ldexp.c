/***************************/
/* Exemplo de uso de ldexp */
/***************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
    double x = 0.785398;
    int    y = 2;

    printf("ldexp(%f, %d) = %f\n", x, y, ldexp(x,y));

    return 0;
}

/***

Resultado do programa:

ldexp(0.785398, 2) = 3.141592

***/
