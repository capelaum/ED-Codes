/**************************************/
/* Exemplo de uso de llrint e llround */
/**************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 2.4, y = -2.55;

   printf( "O valor de %3.2f arredondado usando "
           "llrint e' %lld\n", 2.0/3.0,
           llrint(2.0/3.0) );
   printf( "O valor de %3.2f arredondado usando "
           "llround e' %lld\n", 2.0/3.0,
           llround(2.0/3.0) );

   printf( "O valor de %3.2f arredondado usando "
           "llrint e' %lld\n", y, llrint(y) );
   printf( "O valor de %3.2f arredondado usando "
           "llround e' %lld\n", y, llround(y) );

   return 0;
}

/***

Resultado do programa:

O valor de 0.67 arredondado usando llrint e' 1
O valor de 0.67 arredondado usando llround e' 1
O valor de -2.55 arredondado usando llrint e' -3
O valor de -2.55 arredondado usando llround e' -3

***/
