/***************************/
/* Exemplo de uso de atan2 */
/***************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double r, teta, x = 2.0, y = -2.0;

   r = sqrt(x*x + y*y);

   teta = atan2(y, x);

   printf( "Ponto em coordenadas retangulares (x, y): "
           "(%5.3f, %5.3f)\n", x, y );
   printf( "Ponto em coordenadas polares (r, teta): "
           "(%5.3f, %5.3f)\n", r, teta );

   return 0;
}

/***

Resultado do programa:

Ponto em coordenadas retangulares (x, y): (2.000, -2.000)
Ponto em coordenadas polares (r, teta): (2.828, -0.785)

***/
