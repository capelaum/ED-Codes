/**********************************************/
/* Exemplo de uso de log, log10, log1p e log2 */
/**********************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 2.5;

   printf( "Logaritmo na base 'e' de %3.2f: %f\n",
           x, log(x) );
   printf( "Logaritmo na base 10 de %3.2f: %f\n",
           x, log10(x) );
   printf( "Logaritmo na base 'e' de %3.2f + 1: %f\n",
           x, log1p(x) );
   printf( "Logaritmo na base 2 de %3.2f: %f\n",
           x, log2(x) );

   return 0;
}

/***

Resultado do programa:

Logaritmo na base 'e' de 2.50: 0.916291
Logaritmo na base 10 de 2.50: 0.397940
Logaritmo na base 'e' de 2.50 + 1: 1.252763
Logaritmo na base 2 de 2.50: 1.321928

***/
