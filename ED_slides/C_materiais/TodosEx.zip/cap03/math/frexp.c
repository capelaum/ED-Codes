/***************************/
/* Exemplo de uso de frexp */
/***************************/

#include <math.h>
#include <stdio.h>

int main(void)
{
   double mantissa, numero;
   int    expoente;

   printf("Digite um numero de ponto flutuante: ");
   scanf("%lf", &numero);

   mantissa = frexp(numero, &expoente);

   printf("\nO numero %f e' igual a ", numero);
   printf( "%f vezes 2 elevado a %d\n",
           mantissa, expoente );

   return 0;
}

/***

Resultado do programa:

Digite um numero de ponto flutuante: 2.5

O numero 2.500000 eh igual a 0.625000 vezes 2 elevado a 2

***/
