/***************************/
/* Exemplo de uso de hypot */
/***************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double base = 3.0, altura = 4.0;

   printf( "A hipotenusa do triangulo com base = %3.2f"
           " e altura = %3.2f e' %3.2f\n",
           base, altura, hypot(base, altura) );

   return 0;
}

/***

Resultado do programa:

A hipotenusa do triangulo com base = 3.00 e altura = 4.00 e' 5.00

***/
