/*******************************************/
/* Exemplo de uso de acosh, asinh e atanh */
/*******************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 0.5, y = 1.5;

   printf( "Arco coseno hiperbolico de %3.2f = %3.2f\n",
           y, acosh(y) );
   printf( "Arco seno hiperbolico de %3.2f = %3.2f\n",
           x, asinh(x) );
   printf( "Arco tangente hiperbolica de %3.2f = %3.2f\n",
           x, atanh(x) );

   return 0;
}

/***

Resultado do programa:

Arco coseno hiperbolico de 1.50 = 0.96
Arco seno hiperbolico de 0.50 = 0.48
Arco tangente hiperbolica de 0.50 = 0.55

***/
