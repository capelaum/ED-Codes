/*********************************/
/* Exemplo de uso de fmax e fmin */
/*********************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 3.2, y = -1.4;

   printf("O maior valor entre %3.2f e %3.2f e' %3.2f\n",
          x, y, fmax(x, y));
   printf("O menor valor entre %3.2f e %3.2f e' %3.2f\n",
          x, y, fmin(x, y));

   return 0;
}

/***

Resultado do programa:

O maior valor entre 3.20 e -1.40 e' 3.20
O menor valor entre 3.20 e -1.40 e' -1.40

***/
