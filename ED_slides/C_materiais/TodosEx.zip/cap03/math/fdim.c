/**************************/
/* Exemplo de uso de fdim */
/**************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = -3.2, y = -1.4;

   printf( "%f - %f %s maior do que 0\n", x, y,
           fdim(x, y) ? "e'" : "nao e'" );

   return 0;
}

/***

Resultado do programa:

-3.200000 - -1.400000 nao e' maior do que 0

***/
