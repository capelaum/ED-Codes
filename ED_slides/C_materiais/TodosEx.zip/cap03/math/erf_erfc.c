/********************************/
/* Exemplo de uso de erf e erfc */
/********************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double x = 1.0;

   printf("Funcao erro de %f:\t\t %f\n", x, erf(x));
   printf( "Funcao erro complementar de %f:\t %f\n",
           x, erfc(x) );

   return 0;
}

/***

Resultado do programa:

Funcao erro de 1.000000:                 0.842701
Funcao erro complementar de 1.000000:    0.157299

***/
