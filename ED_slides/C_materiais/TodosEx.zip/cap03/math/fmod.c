/**************************/
/* Exemplo de uso de fmod */
/**************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double x = 3.14159, y = 3.0;

   printf( "fmod(%3.5f, %3.2f) = %3.5f\n",
           x, y, fmod(x,y) );

   return 0;
}

/***

Resultado do programa:

fmod(3.14159, 3.00) = 0.14159

***/
