/*************************************/
/* Exemplo de uso de cos, sin, e tan */
/*************************************/

#define PI 3.141592

#include <stdio.h>
#include <math.h>

int main()
{
   double oArco = PI/2;

   printf( "Coseno de %3.2f = %3.2f\n",
           oArco, cos(oArco) );
   printf("Seno de %3.2f = %3.2f\n", oArco, sin(oArco));
   printf("Tangente de %3.2f = %3.2f\n", PI, tan(PI));

   return 0;
}

/***

Resultado do programa:

Coseno de 1.57 = 0.00
Seno de 1.57 = 1.00
Tangente de 3.14 = -0.00

***/
