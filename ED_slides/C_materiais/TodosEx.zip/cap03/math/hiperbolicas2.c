/***************************************/
/* Exemplo de uso de cosh, sinh e tanh */
/***************************************/

#define PI 3.141592

#include <stdio.h>
#include <math.h>

int main()
{
   double oArco = PI/2;

   printf( "Coseno hiperbolico de %3.2f = %3.2f\n",
           oArco, cosh(oArco) );
   printf( "Seno hiperbolico de %3.2f = %3.2f\n",
           oArco, sinh(oArco) );
   printf( "Tangente hiperbolica de %3.2f = %3.2f\n",
           oArco, tanh(oArco) );

   return 0;
}

/***

Resultado do programa:

Coseno hiperbolico de 1.57 = 2.51
Seno hiperbolico de 1.57 = 2.30
Tangente hiperbolica de 1.57 = 0.92

***/
