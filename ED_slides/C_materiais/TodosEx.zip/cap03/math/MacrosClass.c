/*******************************************************/
/* Exemplo de uso de macros de classifica��o de math.h */
/*******************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 0, y = -2.0, z;

   z = pow(x,y);

   printf( "\nO resultado da avaliacao de "
           "pow(%3.1f, %3.1f) e' ", x, y );

   if (isfinite(z))
      printf("finito");
   else if (isinf(z))
      printf("infinito");
   else if (isnan(z))
      printf("NaN");
   else if (isnormal(z))
      printf("finito e normalizado");

   if (isnan(sqrt(-2)))
      printf( "\nO resultado da avaliacao de "
              "sqrt(-2) e' NaN" );
  else
      printf( "\nO resultado da avaliacao de "
              "sqrt(-2) NAO e' NaN" );

   if (isgreater(x, y))
      printf("\n%4.2f e' maior do que %4.2f", x, y);

   if (isgreaterequal(x, y))
      printf( "\n%4.2f e' maior do que ou igual a "
              "%4.2f", x, y );

   if (isless(x, y))
      printf("\n%4.2f e' menor do que %4.2f", x, y);

   if (islessequal(x, y))
      printf( "\n%4.2f e' menor do que ou igual a "
              "%4.2f", x, y );

   if (islessgreater(x, y))
      printf( "\nOu %4.2f e' maior do que %4.2f "
              "ou %4.2f e' maior do que %4.2f",
              x, y, y, x );

   if (isunordered(x, y))
      printf("\nOu %4.2f e' NaN ou %4.2f e' NaN", x, y);
   else
      printf("\nNem %4.2f nem %4.2f e' NaN", x, y);

   putchar('\n');

   return 0;
}

/***

Resultado do programa:

O resultado da avaliacao de pow(0.0, -2.0) e' infinito
O resultado da avaliacao de sqrt(-2) e' NaN
0.00 e' maior do que -2.00
0.00 e' maior do que ou igual a -2.00
Ou 0.00 e' maior do que -2.00 ou -2.00 e' maior do que 0.00
Nem 0.00 nem -2.00 e' NaN

***/
