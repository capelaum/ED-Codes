/**************************/
/* Exemplo de uso de fabs */
/**************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
   return !printf("fabs(-0.2) = %3.2f\n", fabs(-0.2));
}

/***

Resultado do programa:

fabs(-0.2) = 0.20

***/
