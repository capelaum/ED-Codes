/**************************************/
/* Exemplo de uso de nearbyint e rint */
/**************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 2.4, y = -2.55;

   printf( "O valor de %3.2f arredondado usando "
           "nearbyint e' %3.2f\n", x, nearbyint(x) );
   printf( "O valor de %3.2f arredondado usando "
           "nearbyint e' %3.2f\n", y, nearbyint(y) );

   printf( "O valor de %3.2f arredondado usando "
           "rint e' %3.2f\n", x, rint(x) );
   printf( "O valor de %3.2f arredondado usando "
           "rint e' %3.2f\n", y, rint(y) );

   return 0;
}

/***

Resultado do programa:

O valor de 2.40 arredondado usando nearbyint e' 2.00
O valor de -2.55 arredondado usando nearbyint e' -3.00
O valor de 2.40 arredondado usando rint e' 2.00
O valor de -2.55 arredondado usando rint e' -3.00

***/
