/**********************************/
/* Exemplo de uso de ceil e floor */
/**********************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
    double x = -2.00001;
    double y = 3.1415;

    printf( "O valor de ceil(%f) e' %f\n",
            x, ceil(x) );
    printf( "O valor de floor(%f) e' %f\n",
            y, floor(y) );

    return 0;
}

/***

Resultado do programa:

O valor de ceil(-2.000010) e' -2.000000
O valor de floor(3.141500) e' 3.000000

***/
