/*************************/
/* Exemplo de uso de fma */
/*************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 3.2, y = -1.4, z= 7.23;

   printf( "FMA de %3.2f, %3.2f e %3.2f: %3.2f\n",
           x, y, z, fma(x, y, z) );

   return 0;
}

/***

Resultado do programa:

FMA de 3.20, -1.40 e 7.23: 2.75

***/
