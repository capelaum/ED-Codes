/****************************/
/* Exemplo de uso de scalbn */
/****************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = -3.4;
   int    expoente = 2;

   printf( "O valor de scalbn(%3.2f, %d) e' %f\n",
           x, expoente, scalbn(x, expoente) );

   return 0;
}

/***

Resultado do programa:

O valor de scalbn(-3.40, 2) e' -13.600000

***/
