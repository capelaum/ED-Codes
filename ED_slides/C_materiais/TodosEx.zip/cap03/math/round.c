/***************************/
/* Exemplo de uso de round */
/***************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 2.4, y = -2.55;

   printf( "O valor de %3.2f arredondado usando "
           "round e' %3.2f\n", x, round(x) );
   printf( "O valor de %3.2f arredondado usando "
           "round e' %3.2f\n", y, round(y) );

   return 0;
}

/***

Resultado do programa:

O valor de 2.40 arredondado usando round e' 2.00
O valor de -2.55 arredondado usando round e' -3.00

***/
