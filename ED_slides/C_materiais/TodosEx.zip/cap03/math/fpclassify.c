/********************************/
/* Exemplo de uso de fpclassify */
/********************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 0.0, y = -2.0, z;
   int    classificacao;

   z = pow(x,y);

   classificacao = fpclassify(z);

   printf( "\nO resultado da avaliacao de "
           "pow(%3.1f, %3.1f) e' ", x, y );

   switch(classificacao) {
      case FP_INFINITE:
         printf("infinito");
         break;
      case FP_NAN:
         printf("NaN");
         break;
      case FP_NORMAL:
         printf("finito e normalizado");
         break;
      case FP_SUBNORMAL:
         printf("finito e nao normalizado");
         break;
      case FP_ZERO:
         printf("zero");
         break;
      default:
         printf("desconhecido");
   }

   putchar('\n');

   return 0;
}

/*

Resultado do programa no Windows XP:

O resultado da avaliacao de pow(0.0, -2.0) e' infinito

*/
