/**************************************************/
/* Exemplo de uso de macros definidas em <math.h> */
/**************************************************/

#include <stdio.h>
#include <math.h>
#include <float.h>

int main()
{
   printf( "fma(x, y, z) %se' tao rapida quanto a "
           "avaliacao da expressao double: x * y + z\n",
           FP_FAST_FMA ? "" : "nao " );

   printf( "Valor retornado por uma chamada da funcao "
           "ilogb(x), quando x e' +0.0 ou -0.0: %d\n",
           FP_ILOGB0 );

   printf( "Valor retornado por uma chamada da funcao "
           "ilogb(x), quando x e' NaN: %d\n",
           FP_ILOGBNAN );

   printf( "Representa��o do tipo float de +infinito:"
           " %f\n", INFINITY );

   printf( "Representa��o do tipo float de  NAN: %f\n",
           NAN );

   if (math_errhandling & MATH_ERRNO)
      printf( "As funcoes declaradas em <math.h> "
              "comunicam erros de dominio usando "
              "a variavel errno\n" );
   else if (math_errhandling & MATH_ERREXCEPT)
      printf( "As funcoes declaradas em <math.h> "
              "comunicam erros de dominio usando "
              "sinalizadores de exce��o\n" );
   else
      printf("Esta instrucao nao deve ser executada\n");

   if (cosh(DBL_MAX) == HUGE_VAL)
      printf("O resultado da operacao e' grande demais"
             " para caber num valor do tipo double\n");

   return 0;
}
