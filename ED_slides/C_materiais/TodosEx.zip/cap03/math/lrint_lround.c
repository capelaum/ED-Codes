/************************************/
/* Exemplo de uso de lrint e lround */
/************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   double x = 2.4, y = -2.55;

   printf( "O valor de %3.2f arredondado usando "
           "lrint e' %ld\n", x, lrint(x) );
   printf( "O valor de %3.2f arredondado usando "
           "lround e' %ld\n", x, lround(x) );

   printf( "O valor de %3.2f arredondado usando "
           "lrint e' %ld\n", y, lrint(y) );
   printf( "O valor de %3.2f arredondado usando "
           "lround e' %ld\n", y, lround(y) );

   return 0;
}

/***

Resultado do programa:

O valor de 2.40 arredondado usando lrint e' 2
O valor de 2.40 arredondado usando lround e' 2
O valor de -2.55 arredondado usando lrint e' -3
O valor de -2.55 arredondado usando lround e' -3

***/
