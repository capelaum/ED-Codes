/**************************/
/* Exemplo de uso de modf */
/**************************/

#include <stdio.h>
#include <math.h>

int main(void)
{
    double inteira, frac, numero = 4.1234;

    frac = modf(numero, &inteira);

    printf("Parte fracionaria de %3.4f = %3.4f\n",
            numero, frac);
    printf("Parte inteira de %3.4f = %3.4f\n",
            numero, inteira);

    return 0;
}

/***

Resultado do programa:

Parte fracionaria de 4.1234 = 0.1234
Parte inteira de 4.1234 = 4.0000

***/
