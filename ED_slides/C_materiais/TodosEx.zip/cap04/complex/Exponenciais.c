/***************************************/
/* Exemplo de uso de fun��es complexas */
/*                                     */
/* Fun��es demonstradas:               */
/*       - cexp()                      */
/*       - clog()                      */
/*       - cpow()                      */
/*       - csqrt()                     */
/*                                     */
/***************************************/

#include <stdio.h>
#include <complex.h>

int main()
{
   double _Complex x = 2.0 -3.0*I,
                   y = -1.5 + 2.3*I,
                   z;

     /* NOTA: As fun��es creal() e cimag() retornam, */
     /*       respectivamente, as partes real e      */
     /*       imagin�ria de um n�mero complexo.      */

   z = cexp(x);
   printf( "Exponencial de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n", creal(x), cimag(x),
           creal(z), cimag(z) );

   z = clog(x);
   printf( "Logaritmo de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n", creal(x), cimag(x),
           creal(z), cimag(z) );

   z = cpow(x, y);
   printf("%3.1f + %3.1f*i elevado a %3.1f + %3.1f*i ="
          " %5.3f + %5.3f*i\n", creal(x), cimag(x),
          creal(y), cimag(y), creal(z), cimag(z) );

   z = csqrt(x);
   printf( "Raiz quadrada de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n", creal(x), cimag(x),
           creal(z), cimag(z) );

   return 0;
}

/*

Resultado da execu��o do programa no Windows XP:

Exponencial de 2.0 + -3.0*i = -7.315 + -1.043*i
Logaritmo de 2.0 + -3.0*i = 1.282 + -0.983*i
2.0 + -3.0*i elevado a -1.5 + 2.3*i = -0.398 + -1.342*i
Raiz quadrada de 2.0 + -3.0*i = 1.674 + -0.896*i

*/
