/***************************************/
/* Exemplo de uso de fun��es complexas */
/*                                     */
/* Fun��es demonstradas:               */
/*       - cabs()                      */
/*       - carg()                      */
/*       - conj()                      */
/*       - cproj()                     */
/*       - creal()                     */
/*       - cimag()                     */
/*                                     */
/***************************************/

#include <stdio.h>
#include <complex.h>

int main()
{
   double _Complex x = 2.0 -3.0*I,
                   y = -1.5 + 2.3*I,
                   z;

   printf( "Modulo de %3.1f + %3.1f*i = %5.3f\n",
           creal(x), cimag(x), cabs(x) );

   printf( "Angulo de fase de %3.1f + %3.1f*i = "
           "%5.3f\n", creal(x), cimag(x), carg(x) );

   z = conj(x);
   printf( "Conjugado de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n", creal(x), cimag(x),
           creal(z), cimag(z) );

   z = cproj(x);
   printf( "Projecao de %3.1f + %3.1f*i na esfera de "
           "Riemann = %5.3f + %5.3f*i\n",
           creal(x), cimag(x), creal(z), cimag(z) );

   return 0;
}

/*

Resultado da execu��o do programa no Windows XP:

Modulo de 2.0 + -3.0*i = 3.606
Angulo de fase de 2.0 + -3.0*i = -0.983
Conjugado de 2.0 + -3.0*i = 2.000 + 3.000*i
Projecao de 2.0 + -3.0*i na esfera de Riemann = 2.000 + -3.000*i

*/
