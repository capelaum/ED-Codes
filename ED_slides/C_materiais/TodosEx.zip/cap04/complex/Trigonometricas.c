/***************************************/
/* Exemplo de uso de fun��es complexas */
/*                                     */
/* Fun��es demonstradas:               */
/*       - cacos()                     */
/*       - casin()                     */
/*       - catan()                     */
/*       - ccos()                      */
/*       - csin()                      */
/*       - ctan()                      */
/*                                     */
/***************************************/

#include <stdio.h>
#include <complex.h>

int main()
{
   double _Complex x = 2.0 -3.0*I,
                   z;

     /* NOTA: As fun��es creal() e cimag() retornam, */
     /*       respectivamente, as partes real e      */
     /*       imagin�ria de um n�mero complexo.      */

   z = cacos(x);
   printf( "Arco cosseno de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n", creal(x), cimag(x),
           creal(z), cimag(z) );

   z = casin(x);
   printf( "Arco seno de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n",
           creal(x), cimag(x), creal(z), cimag(z) );

   z = catan(x);
   printf( "Arco tangente de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n", creal(x), cimag(x),
           creal(z), cimag(z) );

   z = ccos(x);
   printf( "Cosseno de %3.1f + %3.1f*i = "
            "%5.3f + %5.3f*i\n",
           creal(x), cimag(x), creal(z), cimag(z) );

   z = csin(x);
   printf( "Seno de %3.1f + %3.1f*i = %5.3f + %5.3f*i\n",
           creal(x), cimag(x), creal(z), cimag(z) );

   z = ctan(x);
   printf( "Tangente de %3.1f + %3.1f*i = "
           "%5.3f + %5.3f*i\n",
           creal(x), cimag(x), creal(z), cimag(z) );

   return 0;
}

/*

Resultado do programa no Windows XP:

Arco cosseno de 2.0 + -3.0*i = 1.000 + 1.983*i
Arco seno de 2.0 + -3.0*i = 0.571 + -1.983*i
Arco tangente de 2.0 + -3.0*i = 1.410 + -0.229*i
Cosseno de 2.0 + -3.0*i = -4.190 + 9.109*i
Seno de 2.0 + -3.0*i = 9.154 + 4.169*i
Tangente de 2.0 + -3.0*i = -0.004 + -1.003*i

*/
