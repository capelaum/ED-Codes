/***************************************/
/* Exemplo de uso de fun��es complexas */
/*                                     */
/* Fun��es demonstradas:               */
/*       - cacosh()                    */
/*       - casinh()                    */
/*       - catanh()                    */
/*       - ccosh()                     */
/*       - csinh()                     */
/*       - ctanh()                     */
/*                                     */
/***************************************/

#include <stdio.h>
#include <complex.h>

int main()
{
   double _Complex x = 2.0 -3.0*I,
                   z;

     /* NOTA: As fun��es creal() e cimag() retornam, */
     /*       respectivamente, as partes real e      */
     /*       imagin�ria de um n�mero complexo.      */

   z = cacosh(x);
   printf( "Arco cosseno hiperbolico de "
            "%3.1f + %3.1f*i = %5.3f + %5.3f*i\n",
            creal(x), cimag(x), creal(z), cimag(z) );

   z = casinh(x);
   printf( "Arco seno hiperbolico de "
            "%3.1f + %3.1f*i = %5.3f + %5.3f*i\n",
            creal(x), cimag(x), creal(z), cimag(z) );

   z = catanh(x);
   printf( "Arco tangente hiperbolica de "
            "%3.1f + %3.1f*i = %5.3f + %5.3f*i\n",
            creal(x), cimag(x), creal(z), cimag(z) );

   z = ccosh(x);
   printf( "Cosseno hiperbolico de %3.1f + %3.1f*i = "
            "%5.3f + %5.3f*i\n",
            creal(x), cimag(x), creal(z), cimag(z) );

   z = csinh(x);
   printf( "Seno hiperbolico de %3.1f + %3.1f*i = "
            "%5.3f + %5.3f*i\n",
            creal(x), cimag(x), creal(z), cimag(z) );

   z = ctanh(x);
   printf( "Tangente hiperbolica de %3.1f + %3.1f*i = "
            "%5.3f + %5.3f*i\n",
            creal(x), cimag(x), creal(z), cimag(z) );

   return 0;
}

/*

Resultado da execu��o do programa no Windows XP:

Arco cosseno hiperbolico de 2.0 + -3.0*i = -1.983 + 1.000*i
Arco seno hiperbolico de 2.0 + -3.0*i = 1.969 + -0.965*i
Arco tangente hiperbolica de 2.0 + -3.0*i = 0.147 + -1.339*i
Cosseno hiperbolico de 2.0 + -3.0*i = -3.725 + -0.512*i
Seno hiperbolico de 2.0 + -3.0*i = -3.591 + -0.531*i
Tangente hiperbolica de 2.0 + -3.0*i = 0.965 + 0.010*i

*/
