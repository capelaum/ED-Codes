/**************************************/
/* Exemplo de uso de macros gen�ricas */
/* definidas em <tgmath.h>            */
/**************************************/

#include <stdio.h>
#include <tgmath.h>

#define IMPRIME(x) printf("%s = %f\n", #x, x)
#define IMPRIME_LD(x) printf("%s = %Lf\n", #x, x)

#define IMPRIME_C(x) printf("%s = %f + %f*i\n",\
                            #x, creal(x), cimag(x))
#define IMPRIME_CLD(x) printf("%s = %Lf + %Lf*i\n",\
                              #x, creal(x), cimag(x))

int main()
{
   int                    i;
   float                  f;
   double                 d;
   long double           ld;
   float _Complex        fc;
   double _Complex       dc;
   long double _Complex ldc;

                            /********* Chama: *********/
   IMPRIME(exp(i));         /* exp() em <math.h>      */
   IMPRIME(asinh(f));       /* asinhf() em <math.h>   */
   IMPRIME(sin(d));         /* sin() em <math.h>      */
   IMPRIME_LD(atan(ld));    /* atanl() em <math.h>    */
   IMPRIME_C(log(fc));      /* clogf() em <complex.h> */
   IMPRIME_C(sqrt(dc));     /* csqrt() em <complex.h> */
   IMPRIME_CLD(pow(ldc,f)); /* cpowl() em <complex.h> */
                            /**************************/

      /* Chama remainder() em <math.h> */
   IMPRIME(remainder(i, i));

      /* Chama nextafter() em <math.h> */
   IMPRIME(nextafter(d, f));

      /* Chama nexttowardf() em <math.h> */
   IMPRIME(nexttoward(f, ld));

      /* Chama copysignl() em <math.h> */
   IMPRIME_LD(copysign(i, ld));

                            /*********  Chama: *********/
   IMPRIME( carg(i));       /* carg() em <complex.h>   */
   IMPRIME_C(cproj(f));     /* cprojf() em <complex.h> */
   IMPRIME(creal(d));       /* creal() em <complex.h>  */
   IMPRIME_LD(cimag(ld));   /* cimagl() em <complex.h> */
   IMPRIME(cabs(fc));       /* cabsf() em <complex.h>  */
   IMPRIME( carg(dc));      /* carg() em <complex.h>   */
   IMPRIME_CLD(cproj(ldc)); /* cprojl() em <complex.h> */
                            /***************************/

      /* As chamadas a seguir produzem resultados */
      /* indefinidos (problemas à vista!)        */
   IMPRIME_C(ceil(fc));
   IMPRIME_C(rint(dc));
   IMPRIME_CLD(fmax(ldc, ld));

   return 0;
}

/*

Resultado do programa no Linux:

exp(i) = inf
asinh(f) = -1.086338
sin(d) = 0.000000
atan(ld) = 0.000000
log(fc) = 0.272471 + -3.141571*i
sqrt(dc) = 0.000000 + 0.000000*i
pow(ldc,f) = nan + nan*i
remainder(i, i) = 0.000000
nextafter(d, f) = 0.000000
nexttoward(f, ld) = -1.312976
copysign(i, ld) = 134514136.000000
carg(i) = 0.000000
cproj(f) = -0.964039 + 0.000000*i
creal(d) = 0.000000
cimag(ld) = 0.000000
cabs(fc) = 1.313205
carg(dc) = 0.000000
cproj(ldc) = nan + nan*i
ceil(fc) = -1.000000 + 0.000000*i
rint(dc) = 0.000000 + 0.000000*i
fmax(ldc, ld) = 0.000000 + 0.000000*i

*/

