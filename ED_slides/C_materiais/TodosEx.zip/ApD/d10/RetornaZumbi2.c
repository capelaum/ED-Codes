#include <stdio.h>
#include <stdlib.h>

#define TAMANHO_ZUMBI 5

int *RetornaZumbi2(void)
{
   int i, *zumbi = malloc(TAMANHO_ZUMBI*sizeof(int));

   if (!zumbi)
      return NULL;

   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      zumbi[i] = i + 1;

   printf( "\nConteudo do array zumbi em "
           "RetornaZumbi2():\n" );

   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      printf("\tzumbi[%d] = %d\n", i, zumbi[i]);

   free(zumbi);

   return zumbi;
}

int main(void)
{
   int *pInt, i, *p, soma = 0;

   pInt = RetornaZumbi2();

      /* At� aqui est� tudo bem, pois  */
      /* o heap ainda n�o foi alterado */
      /* e o zumbi continua vivo.      */
   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      soma += pInt[i]; /* Ainda est� OK */

   printf("\nResultado da soma em main(): %d\n", soma);

   p = calloc(50000000, sizeof(int));

   printf("\nConteudo do array zumbi em main():\n");
   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      printf("\tpInt[%d] = %d\n", i, pInt[i]);

   return 0;
}

/*

Resultado do programa no Windows XP:

Conteudo do array zumbi em RetornaZumbi2():
        zumbi[0] = 1
        zumbi[1] = 2
        zumbi[2] = 3
        zumbi[3] = 4
        zumbi[4] = 5

Resultado da soma em main(): 14

Conteudo do array zumbi em main():
        pInt[0] = 0
        pInt[1] = 2
        pInt[2] = 3
        pInt[3] = 4
        pInt[4] = 5

*/
