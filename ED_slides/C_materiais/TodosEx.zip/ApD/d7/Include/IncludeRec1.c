/****
 *
 * Este programa n�o consegue ser compilado
 * devido a inclus�o recursiva de arquivos
 *
 ****/

#include "arquivo1.h"

int main(void)
{
   return 0;
}
