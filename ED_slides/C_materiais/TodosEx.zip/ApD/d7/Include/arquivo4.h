#ifndef _ARQUIVO4_H_
#define _ARQUIVO4_H_

#include "arquivo3.h"

typedef short tInteiroCurto;

#endif
