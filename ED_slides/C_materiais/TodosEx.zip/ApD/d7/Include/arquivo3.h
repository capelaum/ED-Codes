#ifndef _ARQUIVO3_H_
#define _ARQUIVO3_H_

#include "arquivo4.h"

typedef long tInteiroLongo;

#endif
