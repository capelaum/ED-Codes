/****
 *
 * Este programa n�o consegue ser compilado
 * devido a inclus�o recursiva de arquivos
 *
 ****/

#include "arquivo3.h"
#include "arquivo4.h"

int main(void)
{
   tInteiroLongo inteiroLongo;
   tInteiroCurto inteiroCurto;

   return 0;
}
