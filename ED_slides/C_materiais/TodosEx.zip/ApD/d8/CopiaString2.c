/****
 *
 * Este programa demonstra o retorno
 * correto de um ponteiro incrementado
 *
 ****/

#include <stdio.h>
#include <string.h>

/****
 *
 * CopiaString2(): Esta fun��o imita strcpy()
 *
 * Argumento: destino (sa�da) - o array que recebe
 *                              a c�pia
 *            origem (entrada) - o string que � copiado
 *
 * Retorno: string contendo a c�pia
 *
 ****/

char *CopiaString2(char *destino, const char *origem)
{
   char *inicio = destino;

   while (*destino++ = *origem++)
      ; /* Intencionalmente vazio */

   return inicio;
}

int main()
{
   char *p, str[30];

      /* Usar a fun��o CopiaString2() */
      /* como a seguir n�o apresenta */
      /* nenhum problema:            */
   CopiaString2(str, "bola");

   printf("\nString copiado: \"%s\"", str);

      /* Usar a fun��o CopiaString2() */
      /* como a seguir representa    */
      /* um problema:                */
   p = CopiaString2(str, "problema");

   printf("\nString copiado: \"%s\"", p);

      /* O pior ocorre agora: o resultado da   */
      /* concatena��o caberia confortavelmente */
      /* no array str se p apontasse para o    */
      /* inicio do array, mas n�o � o caso     */
   strcat(p, " com Tiranossauro Rex");

   printf("\nString concatenado: \"%s\"\n", p);

   return 0;
}

/*

Resultado do programa no Windows XP:

String copiado: "bola"
String copiado: "problema"
String concatenado: "problema com Tiranossauro Rex"

*/
