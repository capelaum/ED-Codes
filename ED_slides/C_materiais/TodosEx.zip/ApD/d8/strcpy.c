/****
 *
 * Este programa mostra o que ocorre quando
 * strcpy() � chamada com um ponteiro nulo
 *
 ****/

#include <stdio.h>
#include <string.h>

int main(void)
{
   char *p = NULL, ar[10];

   strcpy(ar, p);

   return 0;
}

/***

Resultado do programa no Windows XP:

O programa � abortado.

***/
