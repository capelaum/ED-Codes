/****
 *
 * Este programa demonstra o retorno
 * incorreto de um ponteiro incrementado
 *
 ****/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/****
 *
 * DuplicaString(): Cria um clone de um string
 *
 * Argumento: destino (sa�da) - o array que recebe
 *                              a c�pia
 *            origem (entrada) - o string que � copiado
 *
 * Retorno: ponteiro para o clone ou NULL se for
 *          imposs�vel alocar o espa�o necess�rio
 *
 ****/
char *DuplicaString(const char *origem)
{
   char *destino;

   if ((destino = malloc(strlen(origem) + 1)) == NULL)
      return NULL;

   while (*destino++ = *origem++)
      ; /* Intencionalmente vazio */

   return destino;
}

int main()
{
   char *p;

      /* O ponteiro retornado pela fun��o */
      /* DuplicaString() n�o aponta para  */
      /* o in�cio da duplicata            */
   p = DuplicaString("bola");

      /* Deve imprimir lixo, mas */
      /* n�o aborta o programa   */
   printf("\nString clonado: \"%s\"\n", p);

      /* Desastre total: para liberar    */
      /* um bloco alocado dinamicamente  */
      /* deve-se passar para free() um   */
      /* ponteiro para o in�cio do bloco */
   free(p);

   return 0;
}

/*

Resultado do programa no Windows XP:

String clonado: ""

****************************************

Resultado do programa no Linux:

String clonado: ""
*** glibc detected *** ./DuplicaString: munmap_chunk(): invalid pointer: 0x097f000d ***
======= Backtrace: =========
/lib/tls/i686/cmov/libc.so.6[0xb7e213f4]
./DuplicaString[0x80484fd]
/lib/tls/i686/cmov/libc.so.6(__libc_start_main+0xe5)[0xb7dc8685]
./DuplicaString[0x80483d1]
======= Memory map: ========
08048000-08049000 r-xp 00000000 08:16 204430     /home/ulysses/Testes/DuplicaString
08049000-0804a000 r--p 00000000 08:16 204430     /home/ulysses/Testes/DuplicaString
0804a000-0804b000 rw-p 00001000 08:16 204430     /home/ulysses/Testes/DuplicaString
097f0000-09811000 rw-p 097f0000 00:00 0          [heap]
b7d95000-b7da2000 r-xp 00000000 08:13 594574     /lib/libgcc_s.so.1
b7da2000-b7da3000 r--p 0000c000 08:13 594574     /lib/libgcc_s.so.1
b7da3000-b7da4000 rw-p 0000d000 08:13 594574     /lib/libgcc_s.so.1
b7db1000-b7db2000 rw-p b7db1000 00:00 0
b7db2000-b7f0a000 r-xp 00000000 08:13 611811     /lib/tls/i686/cmov/libc-2.8.90.so
b7f0a000-b7f0c000 r--p 00158000 08:13 611811     /lib/tls/i686/cmov/libc-2.8.90.so
b7f0c000-b7f0d000 rw-p 0015a000 08:13 611811     /lib/tls/i686/cmov/libc-2.8.90.so
b7f0d000-b7f10000 rw-p b7f0d000 00:00 0
b7f1c000-b7f1f000 rw-p b7f1c000 00:00 0
b7f1f000-b7f39000 r-xp 00000000 08:13 594531     /lib/ld-2.8.90.so
b7f39000-b7f3a000 r-xp b7f39000 00:00 0          [vdso]
b7f3a000-b7f3b000 r--p 0001a000 08:13 594531     /lib/ld-2.8.90.so
b7f3b000-b7f3c000 rw-p 0001b000 08:13 594531     /lib/ld-2.8.90.so
bfc27000-bfc3c000 rw-p bffeb000 00:00 0          [stack]
Aborted

*/
