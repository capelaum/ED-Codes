#include <stdio.h>

int main()
{
   int x, y;
   int soma = x + y;

   printf("Digite dois numeros para somar: ");
   scanf("%d %d");
   printf("A soma dos numeros e' igual a: %f\n", soma);

   return 0;
}
