
int main()
{
   int a, b, *p;

   a = b/*p;  /* p aponta para tal e tal valor */

   return 0;
}


