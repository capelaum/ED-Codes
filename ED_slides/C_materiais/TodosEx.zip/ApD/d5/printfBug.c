/****
 *
 * Inst�ncia do famoso bug da fun��o printf()
 *
 ****/

#include <stdio.h>

int main(int argc, char *argv[])
{
   if (2 != argc) {
      printf( "\nEste programa deve ser usado assim:\n"
              " %s <string>\n", argv[0]);
      return 1;
   }

   printf(argv[1]);

   return 0;
}

/*

Resultado do programa no Windows XP:

D:>printfBug "%X %X %X %X %X %X % X %X %X %X"
3E2480 3E2AB8 4012B5 77C1AEAD 1A 0 22FFA8 10 3 22FFB0

*/
