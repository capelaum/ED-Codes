/****
 *
 * Este programa mostra um uso
 * incorreto da fun��o scanf()
 *
 ****/

#include <stdio.h>

int main(void)
{
   int  i;
   char c;

   for (i = 0; i < 5; ++i) {
      fprintf(stderr, "Digite um inteiro: ");
      scanf("%d", &c);
      printf ("Valor de i: %d\n", i);
   }

   return 0;
}

/*

Resultado do programa no Windows XP:

Digite um inteiro: 1
Valor de i: 0
Digite um inteiro: 2
Valor de i: 0
Digite um inteiro: 3
Valor de i: 0
Digite um inteiro: 4
Valor de i: 0
Digite um inteiro: 5
Valor de i: 0
Digite um inteiro: 6
Valor de i: 0
Digite um inteiro: 7
Valor de i: 0
Digite um inteiro: 8
Valor de i: 0
Digite um inteiro: 9
Valor de i: 0
Digite um inteiro: ^C

*/
