/****
 *
 * Este programa demonstra o uso incorreto
 * de uma vari�vel local de dura��o fixa
 *
 ****/

#include <stdio.h>

#define BYTES_POR_INT  8 /* Pode n�o ser o caso */
#define TAM_PREFIXO_OX 2 /* Caracteres em "0x" */
#define TAM_ARRAY     BYTES_POR_INT + TAM_PREFIXO_OX + 1

/****
 *
 * IntEmHex(): Retorna um string correspondente �
 *             representa��o hexadecimal de um int
 *
 * Argumento: valor (entrada) - o valor cuja
 *                              representa��o ser�
 *                              determinada
 *
 * Retorno: string contendo a representa��o
 *          hexadecimal do inteiro; NULL se a
 *          representa��o n�o couber no string
 *
 ****/

char *IntEmHex(int valor)
{
   static char strHexadecimal[TAM_ARRAY];

      /* Verifica se o resultado da */
      /* representa��o hexadecimal  */
      /* caber� no array            */
   if (sizeof(valor) > BYTES_POR_INT)
      return NULL; /* N�o vai caber no array */

      /* Copia a representa��o hexadecimal */
      /* do par�metro no array             */
   sprintf(strHexadecimal, "0x%X", valor);

   return strHexadecimal;
}

int main(void)
{
   printf( "\nRepresentacao hexadecimal de %d: \"%s\"",
           1, IntEmHex(1) );

   printf( "\nRepresentacao hexadecimal de %d: \"%s\"",
           2, IntEmHex(2) );

   return 0;
}

/*

Resultado do programa no Windows XP:

Representacao hexadecimal de 1: "0x1"
Representacao hexadecimal de 2: "0x2"

*/
