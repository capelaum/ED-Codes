/****
 *
 * Este programa n�o termina nunca normalmente
 * (Para termin�-lo digite CTRL-C.)
 *
 ****/

#include <stdio.h>

int i;

void F()
{ 
   printf("\nFuncao F() chamada\n", i);
   
   for (i = 5; i > 0; --i)
      printf("\ti = %d\n", i);
}

int main(void)
{
   for (i = 0; i <= 5; ++i) {
      F();
   }

   return 0;
}

/*

Resultado do programa:

Funcao F() chamada
        i = 5
        i = 4
        i = 3
        i = 2
        i = 1

Funcao F() chamada
        i = 5
        i = 4
        i = 3
        i = 2
        i = 1

Funcao F() chamada
        i = 5
        i = 4
        i = 3
        i = 2
        i = 1

Funcao F() chamada

Funcao F() chamada
^C

*/
