#include <stdio.h>

#define TAMANHO_ZUMBI 5

int *RetornaZumbi(void)
{
   int i, zumbi[TAMANHO_ZUMBI] = {1, 2, 3, 4, 5};

   printf( "\nConteudo do array zumbi em "
           "RetornaZumbi():\n" );

   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      printf("\tzumbi[%d] = %d\n", i, zumbi[i]);

   return zumbi;
}

int main(void)
{
   int *pInt, i, soma = 0;

   pInt = RetornaZumbi();

      /* At� aqui est� tudo bem, pois   */
      /* a pilha ainda n�o foi alterada */
      /* e o zumbi continua vivo.       */
   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      soma += pInt[i]; /* Ainda est� OK */

      /* A chamada da fun��o printf() */
      /* altera o conte�do da pilha   */
   printf("\nResultado da soma em main(): %d\n", soma);

      /* Outra altera��o no conte�do da pilha */
   printf("\nConteudo do array zumbi em main():\n");

      /* Como o conte�do da pilha foi alterado, o  */
      /* zumbi morreu e reencarnou com outro valor */
   for (i = 0; i < TAMANHO_ZUMBI; ++i)
      printf("\tpInt[%d] = %d\n", i, pInt[i]);

   return 0;
}

/*

Resultado do programa no Windows XP:

Conteudo do array zumbi em RetornaZumbi():
        zumbi[0] = 1
        zumbi[1] = 2
        zumbi[2] = 3
        zumbi[3] = 4
        zumbi[4] = 5

Resultado da soma em main(): 15

Conteudo do array zumbi em main():
        pInt[0] = 1
        pInt[1] = 2009332896
        pInt[2] = 2009209023
        pInt[3] = 32
        pInt[4] = 0

*/
