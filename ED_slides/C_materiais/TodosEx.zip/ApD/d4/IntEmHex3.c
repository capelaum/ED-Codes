/****
 *
 * Este programa provavelmente ser� abortado
 *
 ****/

#include <stdio.h>

#define BYTES_POR_INT  8 /* Pode n�o ser o caso */
#define TAM_PREFIXO_OX 2 /* Caracteres em "0x" */
#define TAM_ARRAY     BYTES_POR_INT + TAM_PREFIXO_OX + 1

/****
 *
 * IntEmHex2(): Retorna um string correspondente �
 *              representa��o hexadecimal de um int
 *
 * Argumento: valor (entrada) - o valor cuja
 *                              representa��o ser�
 *                              determinada
 *
 * Retorno: string contendo a representa��o
 *          hexadecimal do inteiro; NULL se a
 *          representa��o n�o couber no string
 *
 ****/

char *IntEmHex2(int valor)
{
   char *strHexadecimal;

      /* Verifica se o resultado da */
      /* representa��o hexadecimal  */
      /* caber� no array            */
   if (sizeof(valor) > BYTES_POR_INT)
      return NULL; /* N�o vai caber no array */

   strHexadecimal = malloc(TAM_ARRAY);

      /* Copia a representa��o hexadecimal */
      /* do par�metro no array             */
   sprintf(strHexadecimal, "0x%X", valor);

   return strHexadecimal;
}

int main(void)
{
   printf("\nRepresentacao hexadecimal de %d: \"%s\""
          "\nRepresentacao hexadecimal de %d: \"%s\"\n",
          1, IntEmHex2(1), 2, IntEmHex2(2));

   return 0;
}
