/****
 *
 * Este programa tem comportamento indefinido
 *
 ****/

#include <stdio.h>

int F(int arg)
{
   if (arg > 0)
      return arg;
}

int main(void)
{
   printf( "\nValor retornado por F(10): %d\n",
           F(10) );
   printf( "Valor retornado por F(-10): %d\n",
           F(-10) );

   return 0;
}

/***

Resultado do programa no Win XP:

Valor retornado por F(10): 10
Valor retornado por F(-10): -1

********************************

Resultado do programa no Linux:

Valor retornado por F(10): 10
Valor retornado por F(-10): 31

***/
