/****
 *
 * Compara��o de express�es de ponto flutante
 *
 * Sugerido em "Notes on Writing Portable Programs in C"
 *
 ****/

#include <stdio.h>
#include <math.h>

   /* O valor da constante LIMITE depende:      */
   /*   - Do tipo de ponto-flutuante utilizado  */
   /*   - Da arquitetura da m�quina utilizada   */
   /*   - Da precis�o utilizada na obten��o dos */
   /*     valores utilizados                    */
   /*                                           */
   /* Aqui, o valor de LIMITE � arbitr�rio, mas */
   /* na pr�tica, ele deve ser determinado      */
   /* experimentalmente.                        */
#define LIMITE 0.001
#define LIMITE2 0.00001

unsigned SaoIguais1(float exp1,float exp2,float limite)
{
   if (fabs(exp1 - exp2) <= limite)
      return 1;

   return 0;
}

unsigned SaoIguais2(float exp1,float exp2,float limite)
{
   float maior, menor;

   maior = (exp1 >= exp2) ? exp1 : exp2;
   menor = (exp1 >= exp2) ? exp2 : exp1;

   if (!maior)
      return SaoIguais1(exp1, exp2, limite);

   if (fabs(fabs(menor/maior) - 1) <= limite)
      return 1;

   return 0;
}

int main(void)
{
   float  x = 2.5556,
          y = 2.555678,
          limite = LIMITE2;

   printf( "\n*** Limiar de erro utilizado: %f ***\n",
           limite );

   if (SaoIguais1(x, y, limite))
      printf("\nDe acordo com SaoIguais1(), "
             "%f e %f sao iguais\n", x, y);
   else
      printf("\nDe acordo com SaoIguais1(), "
             "%f e %f NAO sao iguais\n", x, y);

   if (SaoIguais2(x, y, limite))
      printf("De acordo com SaoIguais2(), "
             "%f e %f sao iguais\n", x, y);
   else
      printf("De acordo com SaoIguais2(), "
             "%f e %f NAO sao iguais\n", x, y);

   return 0;
}

/*

Resultado do programa (Windows XP):

*** Limiar de erro utilizado: 0.001000 ***

De acordo com SaoIguais1(), 2.555600 e 2.555678 sao iguais
De acordo com SaoIguais2(), 2.555600 e 2.555678 sao iguais



*** Limiar de erro utilizado: 0.000010 ***

De acordo com SaoIguais1(), 2.555600 e 2.555678 NAO sao iguais
De acordo com SaoIguais2(), 2.555600 e 2.555678 NAO sao iguais

*/
