/****
 *
 * Teste de opera��es de ponto flutante
 *
 * Sugerido em "Notes on Writing Portable Programs in C"
 *
 * Origalmente em: U. W. Kulish and W. L. Miranker.
 *             "The Arithmetic of the Digital Computer:
 *             A New Approach". SIAM Review, 28(1):1-40,
 *             March 1986.
 *
 ****/

#include <stdio.h>
#include <math.h>

int main(void)
{
   double      x;
   long double y;

      /* O valor atribu�do a x certamente ser� zero */
   x = pow(10, 40) +
       700         -
       pow(10, 40) +
       pow(10, 45) +
       500         -
       pow(10, 45);

   printf( "\nPrimeira expressao:\n\tValor de x "
           "(double) = %f\n", x );

      /* Alterando-se a ordem das parcelas pode-se */
      /* obter o resultado correto. Por exemplo:   */

   x = pow(10, 40) -
       pow(10, 40) +
       pow(10, 45) -
       pow(10, 45) +
       700         +
       500;

   printf( "\nSegunda expressao:\n\tValor de x "
           "(double) = %f\n", x );

      /* Utilizar long double n�o altera o resultado */
   y = powl(10, 40) +
       700          -
       powl(10, 40) +
       powl(10, 45) +
       500          -
       powl(10, 45);

   printf("\nValor de y (long double) = %Lf\n", y);

   return 0;
}

/*

Resultado do programa (Windows XP):

Primeira expressao:
        Valor de x (double) = 0.000000

Segunda expressao:
        Valor de x (double) = 1200.000000

Valor de y (long double) = 0.000000

*/
