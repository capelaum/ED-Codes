/****
 *
 * Este programa mostra overflow de inteiros
 *
 ****/

#include <stdio.h>
#include <limits.h>

int main(void)
{
   int umInt1, umInt2;

   umInt1 = 0x40000000;

   printf("\numInt1 = %d (0x%X)\n", umInt1, umInt1);

   umInt2 = umInt1 + 0xC0000000;
   printf( "umInt1 + 0xC0000000 = %d (0x%X)\n",
           umInt2, umInt2 );

   umInt2 = umInt1 * 0x4;
   printf( "umInt1 * 0x4 = %d (0x%X)\n",
           umInt2, umInt2 );

   umInt2 = umInt1 - (signed)UINT_MAX;
   printf( "umInt1 - (signed)UINT_MAX = %d (0x%X)\n",
           umInt2, umInt2 );

   return 0;
}

/*

Resultado do programa no Windows XP:

umInt1 = 1073741824 (0x40000000)
umInt1 + 0xC0000000 = 0 (0x0)
umInt1 * 0x4 = 0 (0x0)
umInt1 - (signed)UINT_MAX = 1073741825 (0x40000001)

*/
