/****
 *
 * Este programa apresenta um bug de sinal
 *
 ****/

#include <stdio.h>
#include <string.h>

int main(void)
{
   int   i;
   short nBytes;
   char  ar[256];

      /* Para tornar o exemplo mais realista,       */
      /* suponha que o valor 40000 � introduzido    */
      /* por um usu�rio do programa e que este      */
      /* valor n�o cabe numa vari�vel do tipo short */
   nBytes = 40000;
   printf("\nnBytes = %d\n", nBytes);

   if(nBytes > 256) {
      fprintf( stderr, "Numero de bytes a ser alterados"
                       " e' grande demais" );
      return 1;
   }

   printf( "Numero de bytes que serao alterados:"
           " %zu\n", (size_t) nBytes );

   memset(ar, 'X', nBytes);
   ar[nBytes - 1] = '\0';

   printf("%s\n", ar);

   return 0;
}

/*

Resultado do programa no Linux:

nBytes = -25536
Numero de bytes que serao alterados: 4294941760
Segmentation fault

*/
