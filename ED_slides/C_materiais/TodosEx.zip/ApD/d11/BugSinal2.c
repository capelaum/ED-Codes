/****
 *
 * Este programa apresenta um bug de sinal
 *
 ****/

#include <stdio.h>
#include <string.h>

#define TAM_ARRAY 80

char array[TAM_ARRAY];

char* CopiaString(const char *str, int nBytes)
{
   if(nBytes > TAM_ARRAY)
      return NULL;

   return memcpy(array, str, nBytes);
}

int main(void)
{
   char *p, str[TAM_ARRAY] = "Um string";

   p = CopiaString(str, -10);

   if (p)
      printf("\n%s\n", p);
   else
      printf("\nCopiaString() retornou NULL\n");

   return 0;
}

/*

Resultado do programa no Windows XP:

[O programa n�o responde (mas, n�o entra em loop)]

**************************************************

Resultado do programa no Linux:

Segmentation fault

*/
