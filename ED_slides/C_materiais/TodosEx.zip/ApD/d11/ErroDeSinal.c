/****
 *
 * Este programa demonstra mudan�a de sinal
 * decorrente de overflow de inteiros
 *
 ****/

#include <stdio.h>
#include <limits.h>

int main(void)
{
   int umInt = INT_MAX;

   printf( "\numInt = %d (0x%X)\n",
           umInt, umInt );
   printf( "umInt + 1 = %d (0x%X)\n",
           umInt + 1 , umInt + 1);

   return 0;
}

/*

Resultado do programa no Windows XP:

umInt = 2147483647 (0x7FFFFFFF)
umInt + 1 = -2147483648 (0x80000000)

*/
