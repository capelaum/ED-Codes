/****
 *
 * Este programa mostra overflow de
 * n�meros de ponto-flutuante
 *
 ****/

#include <stdio.h>
#include <float.h>
#include <math.h>

int main(void)
{
   double umDouble = 2*DBL_MAX;

   if (umDouble >= HUGE_VAL)
      printf ("\nOcorreu overflow\n");

   printf ("Valor de umDouble: %f\n", umDouble);

   return 0;
}

/*

Resultado do programa no Windows XP:

Ocorreu overflow
Valor de umDouble: 1.#INF00

*/
