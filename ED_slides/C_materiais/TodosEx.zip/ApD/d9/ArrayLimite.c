/****
 *
 * Este programa mostra como o limite superior
 * de um array pode ser acidentalmente ultrapassado
 *
 ****/

#include <stdio.h>

int main(void)
{
   int ar[5], i;

   for (i = 1; i <= 5; ++i) {
      ar[i] = 1;
      printf("\tar[%d] = %d\n", i, ar[i]);
   }

   return 0;
}

/***

Resultado do programa no Linux:

	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
	ar[1] = 1
	ar[2] = 1
	ar[3] = 1
	ar[4] = 1
^C

***/
