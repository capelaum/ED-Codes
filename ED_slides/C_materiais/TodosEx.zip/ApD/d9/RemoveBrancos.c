/****
 *
 * Este programa provavelmente ser� abortado
 *
 ****/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

/****
 *
 * RemoveBrancos(): Remove espa�os em brancos
 *                  no final de um string
 *
 * Argumento: str (sa�da) - o string cujos espa�os
 *                          ser�o removidos
 *
 * Retorno: o string sem espa�os em branco finais
 *
 ****/
char *RemoveBrancos(char *str)
{
   char *p = strchr(str, '\0');

      /* p est� apontando para o      */
      /* caractere terminal do string */

      /* Faz p apontar para o �ltimo caractere */
   p--;

      /* Substitui cada caractere considerado */
      /* espa�o em branco por '\0'            */
   while(isspace(*p))
      *p-- = '\0';

   return str;
}

int main(void)
{
   char s1[] = "bola      ";
   char s2[] = "          ";
   char s3[] = "";

   printf("String \"%s\" sem espacos finais: ", s1);
   printf("\"%s\"\n", RemoveBrancos(s1) );

   printf("String \"%s\" sem espacos finais: ", s2);
   printf("\"%s\"\n", RemoveBrancos(s2) );

      /* O programa ser� certamente abortado */
      /* antes de chegar aqui.               */

   printf("String \"%s\" sem espacos finais: ", s3);
   printf("\"%s\"\n", RemoveBrancos(s3) );

   return 0;
}

/***

Resultado do programa:

String "bola      " sem espacos finais: "bola"
String "          " sem espacos finais: ""
String "" sem espacos finais: ""

***/
