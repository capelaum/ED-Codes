/****
 *
 * Este programa mostra como usar
 * incorretamente a fun��o strncpy()
 *
 ****/

#include <stdio.h>
#include <string.h>

#define TAMANHO  12

int main()
{
   char str[TAMANHO];

   strncpy(str, "Um string grande", TAMANHO);

   printf( "String apos chamada de strncpy():"
           "\n\t \"%s\"\n", str );

   return 0;
}

/***

Resultado do programa no Windows XP:

String apos chamada de strncpy():
         "Um string gr��""

***/
