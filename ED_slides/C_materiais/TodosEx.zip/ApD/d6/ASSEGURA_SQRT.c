/****
 *
 * Este programa demonstra a defini��o
 * e uso da macro ASSEGURA_SQRT()
 *
 ****/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define ASSEGURA_SQRT(y, x, msg) \
                 do { \
                    errno = 0; \
                    y = sqrt(x); \
                    if (errno) {\
                       fprintf(stderr, msg);\
                       exit(1); \
                    } \
                 } while (0)

int main()
{
   double      raiz, x = 1, y = -1;
   const char* msgErro = "Ocorreu um erro ao calcular "
                         "uma raiz em main()\n";

      /* Em vez de usar as   */
      /* instru��es a seguir: */
   errno = 0;
   raiz = sqrt(x);

   if (errno) {
      fprintf(stderr, msgErro);
      return 1;
   }

   printf("\nRaiz de %f = %f\n", x, raiz);

      /* Use a macro ASSEGURA_SQRT: */
   ASSEGURA_SQRT( raiz, y, msgErro);

   printf("Raiz de %f = %f\n", y, raiz);

   return 0;
}
