/****
 *
 * Este programa demonstra a defini��o
 * e uso da macro ASSEGURA_MALLOC()
 *
 ****/

#include <stdio.h>
#include <stdlib.h>

#define ASSEGURA_MALLOC(p, tam, msg) \
           if (!(p = malloc(tam))) {\
              fprintf(stderr, msg);\
              exit(1); \
           }

int main()
{
   int *p;

      /* Em vez de usar as    */
      /* instru��es a seguir: */
   p = malloc(1000*sizeof(int));

   if (!p) {
      printf( "\nNao foi possivel alocar "
              "memoria em main()" );
      exit(1);
   }

   *p = 10;

   printf("\n*p = %d\n", *p);

      /* Use a macro ASSEGURA_MALLOC: */
   ASSEGURA_MALLOC( p, 1000*sizeof(int),
                    "\nNao foi possivel alocar "
                    "memoria em main()" );

   *p = 100;

   printf("\n*p = %d\n", *p);

   return 0;
}
