/****
 *
 * Este programa demonstra o efeito da ordem de
 * empilhamento de par�metros numa chamada de fun��o
 *
 ****/

#include <stdio.h>
#include <string.h>

void ImprimeInts(int x, int y)
{
   printf("\n\tPrimeiro valor: %d", x);
   printf("\n\tSegundo valor: %d", y);
}

int main(void)
{
   int  x = 10;

   ImprimeInts( x, ++x );
   putchar('\n');

   return 0;
}

/*

************* Resultado do programa *************

Empilhando par�metros da direita para a esquerda:

        Primeiro valor: 11
        Segundo valor: 11

Empilhando par�metros da esquerda para a direita:

        Primeiro valor: 10
        Segundo valor: 11

*/
