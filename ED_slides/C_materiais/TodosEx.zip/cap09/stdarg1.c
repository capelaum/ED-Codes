#include <stdio.h>
#include <stdarg.h>

extern double Media(int, ...); /* Alus�o */

int main()
{
   double arReal[4] = {22.5, 3.5, 7.1, -9.12};

   printf( "\nMedia dos valores %f, %f, %f e %f: %f\n",
           arReal[1], arReal[2], arReal[3], arReal[4],
           Media(4, arReal[1], arReal[2], arReal[3],
           arReal[4]) );

   return 0;
}

/****
 *
 * Fun��o Media(): calcula a m�dia de um n�mero
 *                 indefinido de valores double
 *
 * Argumentos: n (entrada) - n�mero de valores
 *             ... (entrada) - valores cuja m�dia
 *                             ser� calculada
 *
 * Retorno: a m�dia dos valores recebido como argumentos
 *
 ****/

double Media(int n, ...)
{
   double  total = 0;
   va_list argumentos;
   int     i;

   va_start( argumentos, n );

   for ( i = 1; i <= n; i++ )
      total += va_arg( argumentos, double );

   va_end( argumentos );

   return total/n;
}
