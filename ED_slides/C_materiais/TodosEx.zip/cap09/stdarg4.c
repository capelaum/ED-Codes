#include <stdio.h>
#include <stdarg.h>

/****
 *
 * Fun��o MultiInt(): calcula o produto de um n�mero
 *                    indefinido de termos do tipo int
 *
 * Argumentos: nTermos (entrada) - n�mero de termos que
                                   ser�o multiplicados
 *             ... (entrada) - os termos que ser�o
 *                             multiplicados
 *
 * Retorno: o produto dos termos
 *
 ****/
int MultiInt(int nTermos, ...)
{
   va_list  listaArgs;
   int      i, produto = 1;

   va_start(listaArgs, nTermos);

   for (i = 0; i < nTermos; ++i)
      produto *= va_arg(listaArgs, int);

   va_end(listaArgs);

   return produto;
}

int main(void)
{
   int d1 = 1;
   int d2 = 2;
   int d3 = 3;
   int d4 = 4;

   printf( "\nArgumentos: %d, %d, %d e %d\n",
           d1, d2, d3, d4 );
   printf("Produto: %d\n", MultiInt(4, d1, d2, d3, d4));

   return 0;
}
