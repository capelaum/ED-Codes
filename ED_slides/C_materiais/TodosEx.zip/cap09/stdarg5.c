#include <stdio.h>
#include <stdarg.h>

/****
 *
 * Fun��o MultiInt2(): calcula o produto de um n�mero
 *                    indefinido de termos do tipo int
 *
 * Argumentos: nTermos (entrada) - n�mero de termos que
 *                                 ser�o multiplicados
 *             termos (entrada) - os termos que ser�o
 *                                multiplicados
 *
 * Retorno: o produto dos termos
 *
 ****/
int MultiInt2(int nTermos, va_list termos)
{
   int i, produto = 1;

   for (i = 0; i < nTermos; i++)
      produto *= va_arg(termos, int);

   return produto;
}

/****
 *
 * Fun��o ApresentaProduto(): calcula e apresenta o
 *                            produto de um n�mero
 *                            indefinido de termos
 *                            do tipo int
 *
 * Argumentos: nTermos (entrada) - n�mero de termos que
 *                                 ser�o multiplicados
 *             ... (entrada) - os termos que ser�o
 *                             multiplicados
 *
 * Retorno: Nada
 *
 ****/
void ApresentaProduto(int nTermos, ...)
{
   va_list listaArgs;
   int     i, produto;

   va_start(listaArgs, nTermos);

   printf("\nNumeros: ");

      /* Imprime os termos */
   for (i = 0; i < nTermos; i++)
      printf("%d ", va_arg(listaArgs, int));

      /* Para processar a lista de argumentos    */
      /* novamente, � necess�rio reinici�-la.    */
      /* Mas, antes � necess�rio chamar a macro  */
      /* va_end para encerrar o uso iniciado com */
      /* a �ltima chamada de va_start:           */
   va_end(listaArgs);

      /* Evidentemente, esta pr�pria fun��o poderia   */
      /* calcular e apresentar o produto dos n�meros. */
      /* Mas, a t�tulo de ilustra��o, esta tarefa     */
      /* ser� delegada para a fun��o MultiInt2().     */

      /* Reinicia a lista de argumentos */
   va_start(listaArgs, nTermos);

   produto = MultiInt2(nTermos, listaArgs);

   printf("\nProduto dos numeros: %d\n", produto);

   va_end(listaArgs);
}

int main(void)
{
   int i1 = 1, i2 = 2, i3 = 3, i4 = 4;

   ApresentaProduto(4, i1, i2, i3, i4);

   return 0;
}

/*

Resultado do programa:

Numeros: 1 2 3 4
Produto dos numeros: 24

*/
