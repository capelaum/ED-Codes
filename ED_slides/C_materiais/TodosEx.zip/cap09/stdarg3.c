#include <stdio.h>
#include <stdarg.h>
#include <float.h>
#include <math.h>

/****
 *
 * Fun��o SomaDouble(): calcula a soma de um n�mero
 *                      indefinido de parcelas do
 *                      tipo double
 *
 * Argumentos: nTermos (entrada) - n�mero de parcelas
 *                                 que ser�o somados
 *             ... (entrada) - as parcelas que ser�o
 *                             somadas
 *
 * Retorno: a soma das parcelas ou infinito se o
 *          resultado parcial da soma atingir um
 *          valor muito grande
 *
 ****/
double SomaDouble(int nTermos, ...)
{
   va_list args;
   double  umArgumento, soma = 0.0;
   int     i;

   va_start (args, nTermos);

   for (i = 0; i < nTermos; i++){
      umArgumento = va_arg(args, double);
      soma += umArgumento;
         /* Encerra, se o resultado   */
         /* atingir um valor infinito */
      if (!isfinite(soma))
         break;
   }

   va_end (args);

   return soma;
}

int main(void)
{
   double d1 = 1.5, d2 = DBL_MAX, d3 = DBL_MAX,
          d4 = 4.5;
   double resultado;

   printf( "Parcelas: %e, %e, %e e %e\n",
           d1, d2, d3, d4 );

   resultado = SomaDouble(4, d1, d2, d3, d4);

   if (isfinite(resultado))
      printf("Soma: %e\n", resultado);
   else
      printf("O resultado da soma e' infinito\n");

   return 0;
}
