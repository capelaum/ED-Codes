/*******************************************/
/* Exemplo de uso do tipo va_list e das    */
/* macros definidas no arquivo <stdarg.h>: */
/*                                         */
/*       * va_start                        */
/*       * va_copy                         */
/*       * va_end                          */
/*******************************************/

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>

/***
 *
 * Fun��o ConcatenaStrings(): concatena um n�mero
 *                            arbitr�rio de strings
 *
 * Par�metros: strings (no m�nimo um), sendo
 *             que o �ltimo string deve ser NULL
 *
 * Retorno: um string que representa o resultado
 *          da concatena��o ou NULL se n�o for
 *          poss�vel alocar o espa�o necess�rio
 *
 ***/
char* ConcatenaStrings(const char *str, ...)
{
   va_list     lista1, lista2;
   size_t      tamanho = 1;
   const char  *s;
   char        *concatenacao;

   va_start(lista1, str);

   va_copy(lista2, lista1);

      /* Determina a quantidade de espa�o necess�rio */
      /* para conter a concatena��o, que � igual �   */
      /* soma dos tamanhos de todos os strings de    */
      /* entrada mais 1.                             */
   for ( s = str; s != NULL;
          s = va_arg(lista1, const char *) )
      tamanho += strlen(s);

   va_end(lista1);

   concatenacao = malloc(tamanho);

   if (!concatenacao) /* N�o foi poss�vel alocar */
      return NULL;    /*o espa�o necess�rio      */

      /* Transforma num string vazio */
   *concatenacao = '\0';

         /* Concatena os strings */
   for ( s = str; s != NULL;
         s = va_arg(lista2, const char *) )
      strcat(concatenacao, s);

   va_end(lista2);

   return concatenacao;
}

int main()
{
   const char *str1 = "Primeiro string",
              *str2 = "Segundo string",
              *str3 = "Terceiro string",
              *str4 = "Quarto string",
              *str5 = " ",
              *resultado;

   printf( "Strings originais:\n"
           "\t\"%s\" \n\t\"%s\" \n\t\"%s\" "
           "\n\t\"%s\" \n\t\"%s\"",
           str1, str2, str3, str4, str5 );

   resultado = ConcatenaStrings( str1, str5, str2,
                                 str5, str3, str5,
                                 str4, NULL );

   printf( "\n\nResultado da concatenacao: \n\t\"%s\"",
           resultado );

   return 0;
}
