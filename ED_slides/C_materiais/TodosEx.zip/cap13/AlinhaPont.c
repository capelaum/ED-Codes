/****
 *
 * Exemplo de alinhamento de ponteiros
 *
 ****/

#include <stdio.h>
#include <string.h>

int ConverteStrEmInt(const char* s, int n)
{
   const char* aux = s + n;

      /* Convers�o n�o-port�vel que pode causar o    */
      /* aborto do programa dependendo da plataforma */
   return *(int *) aux;
}

int main(void)
{
   const char str[] = "ABCDEFGHIJLMN";
   int        i, n, comprimento;

   comprimento = strlen(str);

      /* Dependendo da plataforma, o programa ser�  */
      /* abortado antes de encerrar o la�o a seguir */
   for (i = 0; i < comprimento; ++i) {
      n = ConverteStrEmInt(str, i);
      printf("i = %d\n", i);
   }

   return 0;
}

