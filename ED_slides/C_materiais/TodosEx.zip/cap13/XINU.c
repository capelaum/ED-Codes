#include <stdio.h>

/****
 *
 * Determina se uma dada representa��o �
 * little-endian ou big-endian.
 *
 * NB: Este programa assume o uso de ASCII e
 *     portanto n�o � port�vel.
 *
 ****/

int main(void)
{
   long int str[2] = {0x554E4958, 0x0};

      /* O primeiro elemento do array str cont�m */
      /* os valores hexadecimais dos caracteres  */
      /* de 'UNIX' em ASCII                      */

      /* Imprime o array str como */
      /* se ele fosse um string   */
   printf ("%s\n", (char *)str);

   printf( "\n\tSe voce ler \"XINU\" acima, a "
           "representacao e' little-endian."
           "\n\tSe voce ler \"UNIX\", a "
           "representacao e' big-endian.\n" );

   return 0;
}

