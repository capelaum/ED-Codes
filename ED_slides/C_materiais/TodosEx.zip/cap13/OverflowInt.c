/****
 *
 * Este programa mostra overflow de inteiros.
 *
 ****/

#include <stdio.h>
#include <limits.h>

int main(void)
{
   unsigned umInt = UINT_MAX + 25;

      /* O resultado deve ser 25 - 1 = 24 */
   printf ("\numInt = %u\n", umInt);

   return 0;
}

/***

Resultado do programa:

umInt = 24

***/
