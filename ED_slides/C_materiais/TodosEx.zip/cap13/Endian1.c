#include <stdio.h>

int main(void)
{
   int x = 1;
   char primeiroByte;

   primeiroByte = *(char *)&x == 1;

#ifdef TESTE
   printf( "Valor do primeiro byte = %d\n",
           (int) primeiroByte );
#endif

   if(primeiroByte)
      printf("Representacao em little endian\n");
   else
      printf("Representacao em big endian\n");

   return 0;
}
