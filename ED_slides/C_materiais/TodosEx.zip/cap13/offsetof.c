/****
 *
 * Exemplo de uso da macro offsetof
 *
 ****/

#include <stdio.h>
#include <stddef.h>

#pragma option -a2

typedef  struct   {
       	  char   c1;
       	  short  s;
       	  char   c2;
       	  float  f;
	   } tEstrutura1;

typedef  struct   {
       	  float  f;
       	  short  s;
       	  char   c1;
       	  char   c2;
	   } tEstrutura2;

int main(void)
{
   printf("\nTamanho de estruturas do tipo tEstrutura1:"
          " %u", sizeof(tEstrutura1));
   printf("\nDeslocamento de membros de tEstrutura1:");
   printf( "\n\tDeslocamento de c1: %u",
           offsetof(tEstrutura1, c1) );
   printf( "\n\tDeslocamento de s:  %u",
           offsetof(tEstrutura1, s) );
   printf( "\n\tDeslocamento de c2: %u",
           offsetof(tEstrutura1, c2) );
   printf( "\n\tDeslocamento de f:  %u",
           offsetof(tEstrutura1, f) );

   printf( "\n\nTamanho de estruturas do tipo "
           "tEstrutura2: %u", sizeof(tEstrutura2) );
   printf("\nDeslocamento de membros de tEstrutura2:");
   printf( "\n\tDeslocamento de f:  %u",
           offsetof(tEstrutura2, f) );
   printf( "\n\tDeslocamento de s:  %u",
           offsetof(tEstrutura2, s) );
   printf( "\n\tDeslocamento de c1: %u",
           offsetof(tEstrutura2, c1) );
   printf( "\n\tDeslocamento de c2: %u\n",
           offsetof(tEstrutura2, c2) );

   return 0;
}

/***
 *
 * Resultado do programa quando compilado com Borland C++ 5.0
 *    com alinhamento em endere�os pares (#pragma option -a2):
 *
 *    Tamanho de estruturas do tipo tEstrutura1: 10
 *    Deslocamento de membros de tEstrutura1:
 *        Deslocamento de c1: 0
 *        Deslocamento de s:  2
 *        Deslocamento de c2: 4
 *        Deslocamento de f:  6
 *
 *    Tamanho de estruturas do tipo tEstrutura2: 8
 *    Deslocamento de membros de tEstrutura2:
 *        Deslocamento de f:  0
 *        Deslocamento de s:  4
 *        Deslocamento de c1: 6
 *        Deslocamento de c2: 7
 *
 ***/

/***

Resultado do programa usando gcc/Ubuntu 8.10

Tamanho de estruturas do tipo tEstrutura1: 12
Deslocamento de membros de tEstrutura1:
	Deslocamento de c1: 0
	Deslocamento de s:  2
	Deslocamento de c2: 4
	Deslocamento de f:  8

Tamanho de estruturas do tipo tEstrutura2: 8
Deslocamento de membros de tEstrutura2:
	Deslocamento de f:  0
	Deslocamento de s:  4
	Deslocamento de c1: 6
	Deslocamento de c2: 7

Resultado do programa usando gcc/Ubuntu 8.10 com a op��o -fpack-struct

Tamanho de estruturas do tipo tEstrutura1: 8
Deslocamento de membros de tEstrutura1:
	Deslocamento de c1: 0
	Deslocamento de s:  1
	Deslocamento de c2: 3
	Deslocamento de f:  4

Tamanho de estruturas do tipo tEstrutura2: 8
Deslocamento de membros de tEstrutura2:
	Deslocamento de f:  0
	Deslocamento de s:  4
	Deslocamento de c1: 6
	Deslocamento de c2: 7

 ***/
