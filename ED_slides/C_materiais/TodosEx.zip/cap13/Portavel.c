/****
 *
 * Este programa � 100% port�vel
 *
 ****/

#include <stdio.h>
#include <limits.h>

int main(void)
{
   (void) printf( "\nMenor valor do tipo long long: "
                  "%lld\n", LLONG_MIN );

   return 0;
}
