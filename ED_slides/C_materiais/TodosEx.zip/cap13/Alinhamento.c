/****
 *
 * Exemplo de preenchimento de estruturas
 *
 ****/

#include <stdio.h>

    /* Diretiva pragma do compilador Borland C++ 5.0  */
    /* que define alinhamento:                        */
    /*   -a1: nenhum alinhamento                      */
    /*   -a2: alinhamento em endere�os pares          */
    /*   -a4: alinhamento em endere�os m�ltiplos de 4 */
    /*   -a8: alinhamento em endere�os m�ltiplos de 8 */
#pragma option -a8

typedef  struct   {
       	  char   c1;
       	  short  s;
       	  char   c2;
       	  float  f;
	   } tEstrutura1;

typedef  struct   {
       	  float  f;
       	  short  s;
       	  char   c1;
       	  char   c2;
	   } tEstrutura2;

int main(void)
{
   printf( "Tamanho da estrutura tEstrutura1: %u",
           sizeof(tEstrutura1) );
   printf( "\nTamanho da estrutura tEstrutura2: %u",
           sizeof(tEstrutura2) );

   return 0;
}

/***
 *
 * Resultado do programa quando compilado com Borland C++ 5.0
 *    (SEM alinhamento):
 *
 *    Tamanho da estrutura tEstrutura1: 8
 *    Tamanho da estrutura tEstrutura2: 8
 *
 * Resultado do programa quando compilado com Borland C++ 5.0
 *    (COM alinhamento em endere�os pares):
 *
 *    Tamanho da estrutura tEstrutura1: 10
 *    Tamanho da estrutura tEstrutura2: 8
 *
 * Resultado do programa quando compilado com Borland C++ 5.0
 *    (COM alinhamento em endere�os m�ltiplos de 4):
 *
 *    Tamanho da estrutura tEstrutura1: 12
 *    Tamanho da estrutura tEstrutura2: 8
 *
 * Resultado do programa quando compilado com Borland C++ 5.0
 *    (COM alinhamento em endere�os m�ltiplos de 8):
 *
 *    Tamanho da estrutura tEstrutura1: 12
 *    Tamanho da estrutura tEstrutura2: 8
 *
 * Resultado do programa quando compilado com gcc 3.2 (COM alinhamento):
 *
 * Tamanho da estrutura tEstrutura1: 12
 * Tamanho da estrutura tEstrutura2: 8
 *
 ***/

