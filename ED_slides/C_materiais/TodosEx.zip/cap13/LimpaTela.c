/****
 *
 * Este programa mostra como isolar um
 * aspecto dependente de plataforma
 *
 ****/

#include <stdio.h>
#include <stdlib.h>

/** As depend�ncias devem ser isoladas num m�dulo **/

#ifdef LINUX
#define LIMPA_TELA system("clear") /* Linux */
#else
#define LIMPA_TELA system("cls") /* DOS */
#endif

/*** Final do m�dulo contendo as depend�ncias ***/

int main(void)
{
   int i;

   for (i = 1; i < 80; ++i)
      printf("\nIsto e' um teste");

   printf("\n\nDigite [ENTER] para limpar a tela");

   getchar();

   LIMPA_TELA;

   return 0;
}
