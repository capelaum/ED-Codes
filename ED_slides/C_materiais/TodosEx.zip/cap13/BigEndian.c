#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef enum {BIG_ENDIAN, LITTLE_ENDIAN} tOrdenacao;

/****
 *
 * Fun��o OrdenacaoDeBytes()
 *
 * Descri��o: Verifica se o sistema corrente �
 *            big ou little-endian
 *
 * Par�metros: Nenhum
 *
 * Retorno: Valor indicando se o sistema corrente �
 *          big ou little-endian.
 *
 ****/

tOrdenacao OrdenacaoDeBytes(void)
{
   int  x = 1;
   char primeiroByte;

   primeiroByte = *(char *)&x == 1;

   return primeiroByte ? LITTLE_ENDIAN : BIG_ENDIAN;
}

/****
 *
 * Fun��o EscreveBigEndian()
 *
 * Descri��o: Esta fun��o � semelhante a fwrite(), mas
 *            escreve sempre em big-endian.
 *
 * Par�metros:
 *      array (entrada): ponteiro para um array no qual
 *                       os bytes ser�o lidos
 *      tamanhoElemento (entrada): tamanho de cada
 *                                 elemento do array
 *      nElementos (entrada): n�mero de itens do array
 *                            a ser escritos
 *      stream(entrada): onde ser� feita a escrita
 *
 * Retorno: n�mero de itens (n�o � o n�mero de bytes!)
 *          que foram realmente escritos no stream.
 *
 ****/

size_t EscreveBigEndian(const void *array,
                        size_t tamanhoElemento,
                        size_t nElementos, FILE *stream)
{
   size_t i, j, retorno = 0;
   char   *copia, *buffer;

      /* Se a ordena��o j� � big-endian, basta chamar */
      /* a fun��o fwrite() para realizar a tarefa.    */
      /* Se a ordena��o de bytes desejada for little- */
      /* endian,  esta � a �nica instru��o que        */
      /* precisa ser alterada.                        */
   if (OrdenacaoDeBytes() == BIG_ENDIAN)
      return fwrite( array, tamanhoElemento, nElementos,
                     stream );

         /* O bloco apontado por copia conter�       */
         /* uma c�pia de cada elemento do array.     */
         /* Este bloco n�o � essencial, mas facilita */
   copia = calloc(1, tamanhoElemento);

         /* O bloco apontado por buffer     */
         /* conter� uma c�pia de cada       */
         /* elemento do array em big-endian */
   buffer = calloc(1, tamanhoElemento);

      /* Se n�o for poss�vel alocar os dois   */
      /* blocos, desiste, mas essa estrat�gia */
      /* pode ser melhorada.                  */
   if (!copia || !buffer)
      return 0;

         /* Escreve um a um cada elemento do */
         /* array com os bytes ordenados em  */
         /* formato big-endian               */
   for (i = 0; i < nElementos; ++i) {
         /* Primeiro faz um c�pia de cada elemento. */
         /* Este passo n�o � essencial, mas ajuda.  */
      memmove(copia, (char *)array + i*tamanhoElemento,
               tamanhoElemento);

         /* Armazena cada byte de cada elemento */
         /* do array original em ordena��o big- */
         /* endian no array buffer.             */
      for (j = 0; j < tamanhoElemento; ++j)
         buffer[tamanhoElemento - j - 1] = copia[j];

         /* A fun��o fwrite() escreve os bytes no     */
         /* arquivo na ordem em que eles se encontram */
         /* em mem�ria. Como o bloco buffer cont�m os */
         /* bytes do elemento corrente do array em    */
         /* ordena��o big-endian assim ser�o escrito  */
         /* os bytes no arquivo.                      */
      retorno += fwrite( buffer, tamanhoElemento, 1,
                         stream );

         /* Se ocorrer algum erro de escrita retorna */
         /* o n�mero de bytes escritos at� ent�o.    */
      if (ferror(stream))
         goto tchau; /* Um goto desses n�o faz mal */
   }

tchau:
   free(copia);
   free(buffer);

     /* Se n�o ocorreu nenhum erro, o valor retornado */
     /* neste ponto dever� ser igual a nElementos     */
   return retorno;
}

/****
 *
 * Fun��o LeBigEndian()
 *
 * Descri��o: Esta fun��o � semelhante a fread(), mas
 *            l� sempre em big-endian.
 *
 * Par�metros:
 *      array (entrada): ponteiro para um array no qual
 *                      os bytes lidos ser�o depositados
 *      tamanhoElemento (entrada): tamanho de cada
 *                                 elemento lido
 *      nElementos (entrada): n�mero de itens do array
 *                            que ser�o lidos
 *      stream(entrada): onde a leitura ser� feita
 *
 * Retorno: n�mero de itens (n�o � o n�mero de bytes!)
 *          que foram realmente lidos no stream.
 *
 * OBSERVA��O: � assumido que a ordena��o do arquivo
 *             � big-endian. N�o h� como esta fun��o
 *             verificar se isto � verdadeiro ou n�o
 *
 ****/

size_t LeBigEndian( void *array, size_t tamanhoElemento,
                    size_t nElementos, FILE *stream)
{
   size_t i, j, retorno = 0;
   char   *copia, *buffer;

      /* Se a ordena��o j� � big-endian, basta chamar */
      /* a fun��o fread() para realizar a tarefa.     */
      /* Se a ordena��o de bytes desejada for little  */
      /* -endian, esta � a �nica instru��o que        */
      /* precisa ser alterada.                        */
   if (OrdenacaoDeBytes() == BIG_ENDIAN)
      return fread( array, tamanhoElemento, nElementos,
                    stream );

         /* O bloco apontado por copia conter�       */
         /* uma c�pia de cada elemento do array.     */
         /* Este bloco n�o � essencial, mas facilita */
   copia = calloc(1, tamanhoElemento);

         /* O bloco apontado por buffer        */
         /* conter� uma c�pia de cada elemento */
         /* do array em big-endian             */
   buffer = calloc(1, tamanhoElemento);

      /* Se n�o for poss�vel alocar os  */
      /* dois blocos, desiste, mas isso */
      /* pode ser melhorado.            */
   if (!copia || !buffer)
      return 0;


         /* L� um a um cada elemento do array e   */
         /* ordena os bytes em formato big-endian */
   for (i = 0; i < nElementos; ++i) {
         /* L� cada elemento no bloco copia. */
      retorno += fread( copia, tamanhoElemento, 1,
                        stream );

         /* Se ocorrer algum erro de leitura retorna */
         /* o n�mero de bytes escritos at� ent�o     */
      if (ferror(stream)) {
         free(copia);
         free(buffer);
         return retorno;
      }

         /* Armazena cada byte de cada elemento */
         /* do array original em ordena��o big- */
         /* endian no array buffer.             */
      for (j = 0; j < tamanhoElemento; ++j)
         buffer[tamanhoElemento - j - 1] = copia[j];

      memmove( (char *)array + i*tamanhoElemento,
               buffer, tamanhoElemento );
   }

   free(copia);
   free(buffer);

      /* Se n�o ocorreu nenhum erro, o */
      /* valor retornado neste ponto   */
      /* dever� ser igual a nElementos */
   return retorno;
}

int main(void)
{
   double x = 2.54, y = 0, z = 0;
   FILE   *stream = fopen("Arq.dat", "wb");

   if (!stream) {
      printf("Erro ao abrir arquivo para escrita\n");
      return 1;
   }

   if (1 != EscreveBigEndian(&x, sizeof(x), 1, stream)){
      printf("Ocorreu um erro de escrita no arquivo\n");
      return 1;
   }

   fclose(stream);

   stream = fopen("Arq.dat", "rb");

   if (!stream) {
      printf("Erro ao abrir arquivo para leitura\n");
      return 1;
   }

   if (1 != fread(&y, sizeof(y), 1, stream)) {
      printf("Ocorreu um erro de leitura no arquivo\n");
      return 1;
   }

      /* � preciso retorna ao in�cio do arquivo */
   rewind(stream);

   if (1 != LeBigEndian(&z, sizeof(z), 1, stream)) {
      printf("Ocorreu um erro de leitura no arquivo\n");
      return 1;
   }

   printf("Valor original:               %4.2lE\n", x);
   printf("Valor lido com fread():       %4.2lE\n", y);
   printf("Valor lido com LeBigEndian(): %4.2lE\n", z);

   return 0;
}

/*****************************************

Resultado do program:

Valor original:               2.54E+000
Valor lido com fread():       3.07E+090
Valor lido com LeBigEndian(): 2.54E+000

*****************************************/
