/****
 *
 * Apesar da apar�ncia ing�nua, este
 * programa n�o � port�vel
 *
 ****/

#include <stdio.h>
#include <limits.h>

int main(void)
{
   (void) printf( "\nMenor valor do tipo int: "
                  "%d\n", INT_MIN );

   return 0;
}
